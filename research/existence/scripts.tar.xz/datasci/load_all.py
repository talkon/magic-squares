import sys, json, collections
sys.path.insert(0, "/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/analytic")
from load import load
s, q = load()
print(len(s), "sum records", len(q), "square records")
# distinct by grid regardless of P/S key differences
grids = {}
for k, r in q.items():
    g = tuple(sorted(sum(r["grid"], []))) if isinstance(r["grid"][0], list) else tuple(sorted(r["grid"]))
    grids.setdefault(g, r)
print("distinct by entry multiset:", len(grids))
S_ = sum(r.get("s_count",0) for r in grids.values()); P_ = sum(r.get("p_count",0) for r in grids.values()); SP_ = sum(r.get("sp_count",0) for r in grids.values())
print("S P SP traversals over distinct:", S_, P_, SP_, "per-trav rates 1 in", 720*len(grids)/S_, 720*len(grids)/P_, 720*len(grids)/max(SP_,1))
# squares by sum records
tot = sum(r["squares"] for r in s.values())
print("squares by sum records:", tot)
bins = [0,1000,2000,3000,5000,8000,12000,1e9]
c = collections.Counter(); n = collections.Counter()
for (P,S), r in s.items():
    N = r["nvecs_raw"]
    for i in range(len(bins)-1):
        if bins[i] <= N < bins[i+1]:
            c[i] += r["squares"]; n[i] += 1
for i in range(len(bins)-1): print(bins[i], bins[i+1], n[i], c[i])
