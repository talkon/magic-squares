import sys, os, json, math, numpy as np, collections
sys.path.insert(0, os.getcwd())
from model import assemble
from gmodel import lK
c = json.load(open("calib3.json"))
rows=[]
for r in c:
    a = assemble(r["comp"], edge=False)
    lE = a["logEsemi"] + lK(r["comp"]["ld_n2"], 6, "lin")
    rows.append((tuple(r["P"]), r["N"], r["S"]/r["smin"], r["sq"], lE))
Ps=sorted(set(x[0] for x in rows)); idx={p:i for i,p in enumerate(Ps)}
y=np.array([x[3] for x in rows],float); lE=np.array([x[4] for x in rows]); lN=np.log(np.array([x[1] for x in rows],float)/1500.); lx=np.log(np.array([x[2] for x in rows]))
g=np.array([idx[x[0]] for x in rows])
keep=(lE>-25)&np.isfinite(lN)
y,lE,lN,lx,g=y[keep],lE[keep],lN[keep],lx[keep],g[keep]
# only P with >=1 square (FE identifiable)
tot=collections.Counter(); 
for gi,yi in zip(g,y): tot[gi]+=yi
m=np.array([tot[gi]>0 for gi in g]); y,lE,lN,lx,g=y[m],lE[m],lN[m],lx[m],g[m]
for lab,X in (("ln N",lN),("ln(S/Smin)",lx)):
    b=0.0
    for it in range(50):
        # profile out per-P FE: alpha_P = log(sum y / sum mu*exp(bX))
        mu0=np.exp(lE+b*X); A=collections.defaultdict(float); B=collections.defaultdict(float)
        for gi,yi,mi in zip(g,y,mu0): A[gi]+=yi; B[gi]+=mi
        al=np.array([math.log(A[gi]/B[gi]) for gi in g]); mu=mu0*np.exp(al)
        # score / info for b (profile; approx)
        sc=((y-mu)*X).sum()
        # within-group centered info
        Xbar=collections.defaultdict(float); W=collections.defaultdict(float)
        for gi,mi,xi in zip(g,mu,X): Xbar[gi]+=mi*xi; W[gi]+=mi
        xc=X-np.array([Xbar[gi]/W[gi] for gi in g])
        info=(mu*xc*xc).sum(); b+=sc/info
    phi=((y-mu)**2/mu).sum()/(len(y)-len(set(g))-1)
    print(f"within-P slope of obs/pred on {lab}: {b:.3f} +- {math.sqrt(max(phi,1)/info):.3f} (phi {phi:.2f}, sums {len(y)}, P {len(set(g))})")
