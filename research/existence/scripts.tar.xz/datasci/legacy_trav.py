import json, math, collections
R = json.load(open("../analytic/legacy_an.json"))
cal="n6_lin"
def tot(rr):
    o=sum(r["sols"] for r in rr); E=sum(r["E_"+cal] for r in rr)
    s=sum(r["nS"] for r in rr); p=sum(r["nP"] for r in rr); sp=sum(r["nSP"] for r in rr)
    eS=sum(r["lpS_"+cal] for r in rr); eP=sum(r["lpP_"+cal] for r in rr); eSP=sum(r["lpSP_"+cal] for r in rr)
    # model traversal predictions are per predicted square; rescale to observed squares
    f=o/E if E>0 else 0
    return o,E,s,eS*f,p,eP*f,sp,eSP*f
o,E,s,eS,p,eP,sp,eSP=tot(R)
print(f"legacy all: squares {o} pred {E:.0f} | S {s}/{eS:.0f}={s/eS:.2f}  P {p}/{eP:.0f}={p/eP:.2f}  SP {sp}/{eSP:.0f}={sp/eSP:.2f}  SP/(rS rP)={sp/eSP/(s/eS*p/eP):.2f}")
for lo,hi in [(0,300),(300,500),(500,700),(700,1000),(1000,2000)]:
    rr=[r for r in R if lo<=r["smin"]<hi]
    o,E,s,eS,p,eP,sp,eSP=tot(rr)
    if o==0: continue
    print(f" smin [{lo},{hi}): P {len(rr):4d} sq {o:7d} obs/pred {o/E:.2f} | S {s/eS:.2f}  P {p/eP:.2f}  SP {sp:3d}/{eSP:6.1f}={sp/eSP:.2f}")
