import json, math, numpy as np, sys, collections
sys.path.insert(0, "/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/analytic")
rows = json.load(open("trav_rows.json"))
# add the two new sampled sums (synth/runs)
from batch2 import batch
SP="/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/synth/runs/"
import subprocess
for f, smin_ in [("p8000.jsonl", None), ("q6015.jsonl", None)]:
    sq=[json.loads(l) for l in open(SP+f)]; sq=[r for r in sq if r["type"]=="square"]
    if not sq: continue
    P=tuple(sq[0]["P"]); S=sq[0]["S"]
    o=batch(P, np.array([float(S)]), 6, want_dist=False)
    s0=int(subprocess.run(["/home/user/magic-squares/bin/enumerate","--print-min-sum"]+[str(e) for e in P],capture_output=True,text=True).stdout.split()[0])
    n=len(sq)
    rows.append(dict(P=P,S=S,N=44732 if S==8000 else 39309,x=math.log(S/s0),n=n,s=sum(r["s_count"] for r in sq),p=sum(r["p_count"] for r in sq),sp=sum(r["sp_count"] for r in sq),
        eS=n*720*math.exp(o["lpS"][0]),eP=n*720*math.exp(o["lpP"][0]),eSP=n*720*math.exp(o["lpSP"][0])))
    print("added", P, S, n, rows[-1]["s"], rows[-1]["p"], round(rows[-1]["eS"],1), round(rows[-1]["eP"],2))
def agg(rr):
    n=sum(r["n"] for r in rr); s=sum(r["s"] for r in rr); p=sum(r["p"] for r in rr); sp=sum(r["sp"] for r in rr)
    eS=sum(r["eS"] for r in rr); eP=sum(r["eP"] for r in rr); eSP=sum(r["eSP"] for r in rr)
    return n,s,eS,p,eP,sp,eSP
def show(lab, rr):
    n,s,eS,p,eP,sp,eSP=agg(rr)
    if n==0: return
    # ratio of (S ratio x P ratio) relative to global 0.87 x 0.64, with Poisson se on log
    rS=s/eS; rP=p/eP; se=math.sqrt(1/max(s,1)+1/max(p,1))
    rel=(rS*rP)/(0.866*0.640)
    print(f"{lab:22s} sq {n:5d}  S {s:5d}/{eS:7.1f}={rS:.2f}  P {p:4d}/{eP:6.1f}={rP:.2f}  SP {sp:2d}/{eSP:5.2f}   (rS*rP)/global {rel:.2f} [x/÷{math.exp(se):.2f}]  -> pair (sq) {rel**2:.2f}")
N = lambda r: r["N"] or 20000
show("all", rows)
for lo,hi in [(0,1000),(1000,1500),(1500,2000),(2000,3000),(3000,6000),(6000,9000),(12000,50000)]:
    show(f"N [{lo},{hi})", [r for r in rows if lo<=N(r)<hi])
# trend: Poisson regression of s on log eS + a + b ln N, clustered by sum (quasi)
def trend(key_o, key_e):
    o=np.array([r[key_o] for r in rows],float); e=np.array([r[key_e] for r in rows]); l=np.log(np.array([N(r) for r in rows])/3000.)
    a=b=0.
    for it in range(60):
        lam=e*np.exp(a+b*l); g=np.array([(o-lam).sum(),((o-lam)*l).sum()]); H=np.array([[lam.sum(),(lam*l).sum()],[(lam*l).sum(),(lam*l*l).sum()]])
        st=np.linalg.solve(H,g); a+=st[0]; b+=st[1]
    lam=e*np.exp(a+b*l); phi=((o-lam)**2/np.maximum(lam,1e-9)).sum()/(len(o)-2)
    cov=np.linalg.inv(H)*max(phi,1)
    return a,b,math.sqrt(cov[1,1]),phi
for ko,ke in (("s","eS"),("p","eP")):
    a,b,sb,phi=trend(ko,ke); print(f"{ko}: obs/model = exp({a:.3f} + {b:.3f} ln(N/3000)), slope se {sb:.3f}, phi {phi:.2f}")
json.dump(rows, open("trav_rows2.json","w"), default=list)
