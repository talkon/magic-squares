import json, math, numpy as np
d = json.load(open("../synth/bigN_an.json"))
rows = [(r['N'], r['y'], r['an']*r['f'], r['hc']*r['f'], tuple(r['P'])) for r in d]
# two new sums (existence.md 3.3): analytic in-sample 3.85, 4.37; obs 1, 7
rows += [(44732, 1, 3.85, None, (14,8,5,3,2,1,1)), (39309, 7, 4.37, None, (13,7,5,3,2,1,1))]
N = np.array([r[0] for r in rows], float); y = np.array([r[1] for r in rows], float); mu = np.array([r[2] for r in rows])
ln = np.log(N/1e4)
def fit(sel):
    a=b=0.0
    for it in range(100):
        lam = mu[sel]*np.exp(a+b*ln[sel]); g=np.array([(y[sel]-lam).sum(), ((y[sel]-lam)*ln[sel]).sum()])
        H=np.array([[lam.sum(),(lam*ln[sel]).sum()],[(lam*ln[sel]).sum(),(lam*ln[sel]**2).sum()]])
        st=np.linalg.solve(H,g); a+=st[0]; b+=st[1]
    lam = mu[sel]*np.exp(a+b*ln[sel]); k=sel.sum()
    phi=((y[sel]-lam)**2/lam).sum()/(k-2); cov=np.linalg.inv(H)*max(phi,1)
    return a,b,math.sqrt(cov[0,0]),math.sqrt(cov[1,1]),phi
allm = np.ones(len(y),bool)
for lab, sel in [("17 sums (as in existence.md)", np.arange(len(y))<17), ("19 sums (+2 new)", allm)]:
    a,b,sa,sb,phi = fit(sel)
    print(f"{lab}: obs/an = exp({a:.3f} + {b:.3f} ln(N/1e4)), se a {sa:.3f} se b {sb:.3f}, phi {phi:.1f}")
    for Nx in (4.5e4, 1e5, 3e5):
        L=math.log(Nx/1e4); m=a+b*L; s=math.sqrt(sa**2+(L*sb)**2)  # ignoring cov for rough
        print(f"   extrapolated obs/an at N={Nx:.0e}: {math.exp(m):.2f}  (1-sigma {math.exp(m-s):.2f}-{math.exp(m+s):.2f})")
# level only, by group, with overdispersion
for lab, sel in [("full 3.4-8.9k", N<12000), ("sampled 15-45k", N>=12000)]:
    o=y[sel].sum(); p=mu[sel].sum(); lam=mu[sel]*o/p; k=sel.sum()
    phi=max(((y[sel]-lam)**2/lam).sum()/(k-1),1)
    se=math.sqrt(phi/o) if o>0 else float('nan')
    print(f"{lab}: obs {o:.0f} pred {p:.1f} ratio {o/p:.2f}; phi {phi:.1f}; 1-sigma range {o/p*math.exp(-se):.2f}-{o/p*math.exp(se):.2f}")
# lognormal random-effect view: per-sum log ratios for sampled (use (y+0.5)/(mu+0.5) shrink)
for r in rows:
    print(f"  N {r[0]:6d} obs {r[1]:4d} an {r[2]:7.2f} ratio {r[1]/r[2]:.2f}  P {r[4]}")
