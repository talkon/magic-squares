"""Share of the analytic (lin) N_magic(X) coming from sums with N in each band, at fixed X (sorted universe, no perm mult)."""
import os, sys, json, math, random, collections
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
A="/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/analytic"
sys.path.insert(0, A); os.chdir(A)
import numpy as np, gmodel, maxent
frac = float(sys.argv[1])
g = json.load(open("gs3_n6.json")); st = g["strata"]
by = collections.defaultdict(list)
for r in g["res"]: by["|".join(map(str, r["st"]))].append(tuple(r["P"]))
random.seed(5)
XS=[1500,2000,3000,4000,6000,1e4,5e4]
bands=[0,4000,8000,16000,32000,45000,64000,128000,1e12]
acc=np.zeros((len(XS),len(bands)-1)); accx=np.zeros((len(XS),10)); nP=0
out=[]
for key, Nst in st.items():
    v = by.get(key)
    if not v: continue
    m = max(1, int(round(frac * len(v)))); sub = random.sample(v, min(m, len(v)))
    w = Nst / len(sub)
    for P in sub:
        o = gmodel.eval_P(P, 6, 5e4, fmax=4.0, npts=26); nP += 1
        maxent._div_cache.clear()
        if o is None: continue
        S=np.array(o["S"],float); lm=np.array(o["lEm_lin"]); N=np.exp(np.array(o["lN"]))
        x=np.log(S/S[0]) if False else None
        for k in range(1,len(S)):
            Nm=math.sqrt(N[k-1]*N[k]); j=min(max(int(np.searchsorted(bands,Nm,side="right")-1),0),len(bands)-2) if np.isfinite(Nm) else 0
            for i,X in enumerate(XS):
                if X<=S[k-1]: continue
                acc[i,j]+=w*gmodel.cum(S[k-1:k+1], lm[k-1:k+1], X)
                xs=math.log(0.5*(S[k-1]+S[k])/S[0]); jx=min(int(xs/0.05),9)
                accx[i,jx]+=w*gmodel.cum(S[k-1:k+1], lm[k-1:k+1], X)
        out.append((P,w))
print("P evaluated", nP, file=sys.stderr)
json.dump(dict(XS=XS,bands=bands,acc=acc.tolist()), open("/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/datasci/nshare.json","w"))
for i,X in enumerate(XS):
    t=acc[i].sum()
    tx=accx[i].sum(); print("   x-bins of 0.05:", " ".join(f"{accx[i,j]/tx:.2f}" for j in range(10)))
    print(f"X {X:7g} total(sorted, no mult) {t:.3f} | " + "  ".join(f"[{bands[j]/1e3:.0f}k,{bands[j+1]/1e3:.0f}k): {acc[i,j]/t:.2f}" for j in range(len(bands)-1)))
