export const meta = {
  name: 'existence-heuristics-finish',
  description: 'Finish the existence study: analytic heuristic (model-based and literature parts are done), synthesis, two skeptical reviews, revision',
  phases: [
    { title: 'Investigate', detail: 'analytic heuristic, model-based existence estimate, literature/calibration data' },
    { title: 'Synthesize', detail: 'reconcile the three into one estimate and write-up' },
    { title: 'Review', detail: 'two skeptics (mathematics, data) challenge the synthesis' },
    { title: 'Revise', detail: 'fix what the skeptics found' },
  ],
}

const SP = '/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad'
const CONTEXT = `
Project: search for 6x6 additive-multiplicative magic squares: 36 distinct positive integers in a 6x6 grid such that all 6 rows, 6 cols and both diagonals have the same sum S and the same product P. None is known for order 6 (nor 5). Repo: /home/user/magic-squares (branch claude/magic-search-speedups): read README.md, research/forecast.md, research/ideas.md (sections "Diagonal-first search (second look)" and the forecast notes), and section 7 of the report (\`pdftotext /home/user/magic-squares/project-report.pdf -\`). The search enumerates, for chosen (P, S), all "vectors" (6-sets of distinct divisors of P with product P and sum S; N = their number, bin/enumerate counts them, e.g. \`bin/enumerate --print-min-sum --window 1.8 10 4 3 2\` or \`bin/enumerate --counts --min-sum A --max-sum B <exps>\`; see src/c/README.md), finds all semi-magic squares (rows and cols only), and checks diagonals. P is given by its exponents over 2,3,5,7,11,... (e.g. 10 4 3 2 = 2^10 3^4 5^3 7^2). S_min(P) = smallest possible line sum.

Data available:
- Semi-magic squares we found: JSON lines in ${SP}/forecast/state/units/*.jsonl ("square" records: P, S, s_count, p_count, sp_count = numbers of the 720 traversals with the magic sum / product / both, best_score, grid; "sum" records: P, S, nvecs_raw = N, squares, time). 5821 squares from 76 P near S_min, plus the verifiers' extra runs in ${SP}/verify-forecast/*/ms_*.jsonl and *.jsonl.
- The first search's per-P totals: /home/user/magic-squares/stats/stats_short.txt (758,949 semi-magic squares over ~1100 P, larger S; traversal totals: S-type 1 in 830, P-type 1 in 2600, SP 1 in 1.05M).
- The scheduler's fitted model (scripts/scheduler.py: Model.squares/p_s/p_p/p_magic; ${SP}/forecast/state/model_6.json) and the forecast + its independent checks: ${SP}/forecast/forecast.md, ${SP}/verify-forecast/ (recompute/, model-form/, region-pool/): P(magic | semi-magic square) ~ 5400 (rho p_S p_P)^2, ~1 in 20-90 million near S_min; within a P, P(magic) falls ~S^-7..-9 near S_min; squares per sum grow like N^4-5 near S_min, ~N^2-2.5 at N 6-8k; time per sum ~N^3.5-5.5.
Known smallest 6x6 semi-magic additive-multiplicative example: Morgenstern's, P = 2^10 3^4 5^3 7^2, S = 327.

Rules: do not modify the repo; work in ${SP}/existence/<your-lens>/. The machine has 4 cores shared with benchmarking agents: at most one heavy process at a time, total CPU for enumeration/searching under ~1 CPU-hour. Be quantitative and explicit about every assumption and approximation; prefer checking a heuristic against data over trusting it.`

const ANALYTIC = `Lens: ANALYTIC NUMBER-THEORY HEURISTIC. Derive, as rigorously as a heuristic can be, the expected number of n x n additive-multiplicative magic squares (and, for calibration, semi-magic squares: rows and cols only) with magic sum S <= X (also consider max entry <= X), for n = 5, 6, 7, 8, and its growth rate in X (power of X and log factors), the convergence/divergence of the total, and the X at which the expected count reaches 1 (the expected size of the smallest example). Suggested route (improve it if you see a better one):
1. Multiplicative structure: for a given P = prod p^{a_p}, a grid is multiplicatively (semi-)magic iff for every prime p its exponent matrix is a nonnegative integer (semi-)magic matrix with line sum a_p. Their numbers are Ehrhart (quasi-)polynomials: H_n(a) for semi-magic (Birkhoff polytope, degree (n-1)^2) and the magic-square count (rows, cols, both diagonals; degree n^2-2n-1). Get them or good approximations (leading coefficients = relative volumes; Canfield-McKay asymptotics for contingency tables; Monte Carlo or exact counts for small a where needed; verify numerically for n = 6 at small a).
2. Additive constraints: given the multiplicative structure (which fixes the entries), estimate the probability that all line sums equal S, via a local-limit / Gaussian heuristic for the line-sum differences (2n-1 independent equalities for semi-magic with S fixed, 2n+1 for magic), with the entries' size distribution induced by the exponent structure, plus arithmetic (congruence) local factors if they matter. Account for distinct entries and for symmetries (count squares up to the symmetry group consistently with how the data count them).
3. Combine and sum over P and S <= X (which P dominate?), giving N_semi(X), N_magic(X); the ratio per (P, S) should reduce to something like C / (S^2 prod a_p^2) -- compare it with the empirical P(magic | semi) = 5400 (rho p_S p_P)^2 and the fitted dependence on S and tau(P).
4. CALIBRATE against data: predicted semi-magic counts for specific (P, S) we searched (sum records with their observed squares) and for the first search's per-P totals; report predicted/observed. If the heuristic is off by a factor, find out why (e.g. near S_min the entries are constrained, so the Gaussian approximation fails) and correct it.
5. Output: N_magic(X) for n = 6 with uncertainty, the growth exponent, the expected smallest S (X where N = 1), and the same for n = 5, 7, 8 (for later comparison with known examples). Write a self-contained markdown derivation to ${SP}/existence/analytic/analytic.md (with formulas and numbers) and return the key results.

NOTE: a previous run of exactly this task was interrupted by a container restart after ~1.7 hours, before writing analytic.md. Its scripts and intermediate results are in ${SP}/existence/analytic/ (e.g. calib*.json, legacy_an.json / legacy_pred.json, gs5_sel.json, gs6_pilot.json, cand6_12000.json, compare_n*.json, runs/, model.py, maxent.py, fdmodel.py, globalsum.py, gsum.py, strat*.py, and queue.sh, which was about to run stratified global estimates for n = 7, 8, 5 after a stratified n = 6 run -- those runs were killed). Read and check that work first and reuse what is sound rather than redoing it; then finish the remaining computations (keeping CPU modest) and write analytic.md.`

const MODEL = `Lens: MODEL-BASED EXISTENCE ESTIMATE. Using the scheduler's fitted model with the corrections that survived checking (fresh-P squares factor ~0.35, rho ~2.6, clamped tau; large-N squares/time growth measured by the region verifier, ${SP}/verify-forecast/region-pool/), estimate the expected TOTAL number of 6x6 magic squares that exist (not found within a budget), and how it grows with the maximum magic sum S <= X:
1. For a sample of P across sizes (tau from ~500 to ~30,000+, different numbers of primes, including the families the search uses and others), compute the expected number of magic squares per sum, E(P, S) = squares(P, S) * P(magic | square), over as much of the S range as is meaningful: near S_min the model is calibrated; further out use the measured growth and an explicit model of how p_S, p_P behave at large S (e.g. p_S ~ c/S once the entries are far from the minimum -- check against the first search's traversal rates at larger S). Remember that for fixed P the number of vectors is finite (6-subsets of divisors with product P), so N(S) rises then falls; bin/enumerate can count vectors over wide S ranges (watch the CPU and memory; sample sums if needed).
2. Sum over S per P, study how the per-P total scales with tau(P), log P, S_min(P); then sum over all P with S_min(P) <= X (estimate the number of P by size class) to get the cumulative expected count N_magic(X) and the X where it reaches 1, and whether the total diverges.
3. Report where (which P, which S/S_min, which N) the expected squares are, and how expensive finding them would be with the current search (time per sum ~ N^3.5-5.5; ~1 s per semi-magic square at large N).
Write ${SP}/existence/model/model.md and return the key results with uncertainties.`

const LIT = `Lens: LITERATURE AND CALIBRATION DATA. Using web search (load the WebSearch / WebFetch tools via ToolSearch) and your knowledge, collect the facts needed to calibrate a heuristic for additive-multiplicative magic squares: (1) for each order n (3..12 or so): is an additive-multiplicative magic square known, who found it and when, the smallest known magic sum S and product P, how many are known, and any impossibility proofs (e.g. n = 3, 4?); likewise for semi-magic ones (5x5, 6x6: smallest known S, e.g. Morgenstern's 6x6 semi-magic squares) and for "SP+S"/"SP+P" partial results. Christian Boyer's site multimagie.com is the main reference ("additive-multiplicative magic squares"); also OEIS, MathWorld, arXiv. (2) Any published heuristic or counting argument for the number of such squares or the expected size of the smallest one, and any results on counting multiplicative magic squares (exponent matrices, Ehrhart polynomials of the Birkhoff and magic-square polytopes, Canfield-McKay). (3) Known constructions (e.g. via orthogonal Latin squares; the role of Euler's 36 officers problem for order 6). Give exact citations/URLs and quote the numbers. Write ${SP}/existence/literature/literature.md and return a structured summary.`

const REPORT = {
  type: 'object',
  properties: {
    lens: { type: 'string' },
    key_results: { type: 'string', description: 'main numbers and conclusions, with uncertainties' },
    growth_rate: { type: 'string', description: 'how the expected number of 6x6 magic squares grows with max S (or max entry), if estimated' },
    smallest_expected: { type: 'string', description: 'expected size of the smallest 6x6 magic square (S), if estimated; and for other n' },
    calibration: { type: 'string', description: 'how the estimate compares with data / known examples' },
    caveats: { type: 'string' },
    file: { type: 'string', description: 'path of your markdown write-up' },
  },
  required: ['lens', 'key_results', 'calibration', 'caveats', 'file'],
}

phase('Investigate')
const analytic = await agent(`${CONTEXT}\n\n${ANALYTIC}`, { label: 'analytic', phase: 'Investigate', schema: REPORT })
const model = args.model, lit = args.literature
const inv = { analytic, model, literature: lit }
log('investigation done: ' + Object.entries(inv).map(([k, v]) => `${k}: ${v ? 'ok' : 'FAILED'}`).join(', '))

phase('Synthesize')
const SYN = {
  type: 'object',
  properties: {
    summary: { type: 'string', description: 'the answer for the user: growth rate of # magic 6x6 squares vs max S, expected smallest S, whether infinitely many are expected, how this squares with the search results, with uncertainty ranges' },
    file: { type: 'string' },
  },
  required: ['summary', 'file'],
}
const synth = await agent(`${CONTEXT}\n\nYou are the SYNTHESIZER. Three investigations were done (their write-ups are in ${SP}/existence/{analytic,model,literature}/; read them and check their key computations where cheap):\n${JSON.stringify(inv, null, 1)}\n\nReconcile them into one estimate: (1) how the expected number of 6x6 additive-multiplicative magic squares grows with the maximum magic sum S (and/or entry size), (2) whether infinitely many are expected under the heuristic, (3) the expected size of the smallest one, (4) calibration: does the same heuristic predict the known examples for other orders (n = 7, 8, ...: existence and smallest known S) and the observed 6x6 semi-magic counts? If the analytic and model-based estimates disagree, find out why and decide which to trust where. (5) What this implies for the search (is the smallest expected square within reach of the current search and scheduler? at what cost?), and what would test the heuristic. Write ${SP}/existence/existence.md: concise, with formulas, tables and explicit assumptions, suitable for research/existence.md in the repo. Return a summary.`, { label: 'synthesize', phase: 'Synthesize', schema: SYN })

phase('Review')
const CRIT = {
  type: 'object',
  properties: {
    lens: { type: 'string' },
    verdict: { type: 'string', description: 'does the synthesis hold? what is wrong, with corrected numbers' },
    issues: { type: 'array', items: { type: 'object', properties: { issue: { type: 'string' }, severity: { type: 'string', enum: ['major', 'minor'] }, fix: { type: 'string' } }, required: ['issue', 'severity', 'fix'] } },
  },
  required: ['lens', 'verdict', 'issues'],
}
const critics = await parallel([
  () => agent(`${CONTEXT}\n\nYou are a skeptical MATHEMATICIAN reviewing ${SP}/existence/existence.md (and the analytic write-up it relies on, ${SP}/existence/analytic/analytic.md). Check every step of the heuristic: Ehrhart degrees and leading constants for the semi-magic and magic exponent-matrix counts (verify numerically where possible), the number of independent additive constraints, the Gaussian/local-limit densities and their covariance, arithmetic local factors, symmetry and distinctness factors, the sum over P and S (which P dominate; is the asymptotic regime reached at the X that matter?), and the growth exponent and expected smallest S. Try to find errors that change the conclusions (e.g. whether the count diverges, or the smallest S by orders of magnitude). Report issues with corrected numbers.`, { label: 'critic:math', phase: 'Review', schema: CRIT }),
  () => agent(`${CONTEXT}\n\nYou are a skeptical DATA SCIENTIST reviewing ${SP}/existence/existence.md and the write-ups it relies on (${SP}/existence/{analytic,model,literature}/). Check the calibration claims against the actual data (our sum and square records, the first search's per-P totals, the known examples for other orders): recompute the predicted/observed ratios yourself on a sample, check the extrapolations (which regimes have data, which do not), and whether the conclusions (growth rate, smallest expected S, implications for the search) follow from the evidence with the stated uncertainty. Report issues with corrected numbers.`, { label: 'critic:data', phase: 'Review', schema: CRIT }),
])

phase('Revise')
const final = await agent(`${CONTEXT}\n\nYou are revising ${SP}/existence/existence.md in light of two reviews:\n${JSON.stringify(critics.filter(Boolean), null, 1)}\n\nFix every major issue (recompute numbers as needed), address the minor ones, and update the file in place. Keep it concise and honest about uncertainty. Return the final summary for the user (growth rate vs max S, whether infinitely many are expected, expected smallest S, calibration on other orders and on our semi-magic counts, implications for the search) and list what changed after review.`, { label: 'revise', phase: 'Revise', schema: SYN })
return { investigations: inv, synthesis: synth, critics: critics.filter(Boolean), final }