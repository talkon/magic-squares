"""Smallest-S distribution and P(exists) for the revised analytic curve (rev.py), the old central curve and
the model lens, with an X-dependent, upward-skewed lognormal model error on N_magic:
ln lambda = z sigma_hi(X) for z > 0, z sigma_lo(X) for z < 0 (z standard normal, the same z at every X)."""
import json, math, sys, numpy as np
D = "/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/"
cv = json.load(open(D + "synth/rev/curve_central.json"))["curve"]
Xc = np.array([c[0] for c in cv[:-1]]); Nc = np.array([c[1] for c in cv[:-1]]); Ninf = cv[-1][1]
def Nrev(X): return Ninf if X >= 1e8 else math.exp(np.interp(math.log(X), np.log(Xc), np.log(Nc)))
ft = json.load(open(D + "analytic/final_tables.json"))["6"]["rows"]
Xa = np.array([r["X"] for r in ft], float); Na = np.array([r["Nm"] for r in ft])
RX = np.array([1000, 1500, 2000, 3000, 4000, 6000, 10000, 20000, 1e9]); RR = np.array([1.14, 1.33, 1.39, 1.44, 1.53, 1.52, 1.62, 1.62, 1.62])
def Nold(X):
    X = min(X, 5e4); return math.exp(np.interp(math.log(X), np.log(Xa), np.log(Na))) * float(np.interp(math.log(X), np.log(RX), RR))
Xm = np.array([1000, 1500, 2000, 2500, 3000, 4000, 5000, 7000, 1e4, 2e4, 3e4]); Nm = np.array([0.0065, 0.058, 0.22, 0.54, 1.2, 3.2, 6.2, 18, 62, 400, 990])
def Nml(X): return math.exp(np.interp(math.log(min(X, 3e4)), np.log(Xm), np.log(Nm)))
SLO = (0.7, 0.75); SHI = (0.7, float(sys.argv[1]) if len(sys.argv) > 1 else 1.0)
def sig(X, s):
    t = np.clip((math.log(X) - math.log(4000)) / (math.log(2e4) - math.log(4000)), 0, 1)
    return s[0] + t * (s[1] - s[0])
z = np.random.default_rng(7).normal(size=40000)
def F(Nf, X, err=True):
    if not err: return 1 - math.exp(-Nf(X))
    lam = np.where(z > 0, np.exp(z * sig(X, SHI)), np.exp(z * sig(X, SLO)))
    return float(np.mean(1 - np.exp(-lam * Nf(X))))
grid = np.exp(np.linspace(math.log(700), math.log(5e4), 500))
def report(name, Nf, err, top=1e9):
    Fs = np.array([F(Nf, x, err) for x in grid])
    q = lambda p: ("%.0f" % grid[np.searchsorted(Fs, p)]) if Fs[-1] >= p else "none by 5e4"
    N1 = grid[np.searchsorted([Nf(x) for x in grid], 1.0)]
    print("| %s | %.0f | %s | %s | %s | %s | %s | %.3f |" % (name, N1, q(.1), q(.25), q(.5), q(.75), q(.9), F(Nf, top, err)))
    return Fs
print("| curve | X(N=1) | 10% | 25% | median | 75% | 90% | P(exists) |")
report("old central, no error", Nold, False, 5e4)
report("revised analytic, no error", Nrev, False)
Fa = report("revised analytic, sigma 0.7 (X<=4k) -> %.2f/%.2f" % (SLO[1], SHI[1]), Nrev, True)
Fm = report("model lens, sigma 0.7", Nml, True, 3e4)
mix = 0.5 * (Fa + Fm)
q = lambda p: grid[np.searchsorted(mix, p)]
print("50/50 mixture analytic/model lens: 10%% %.0f 25%% %.0f median %.0f 75%% %.0f 90%% %.0f" % (q(.1), q(.25), q(.5), q(.75), q(.9)))
print("\nrevised N_magic(X) with 68%/90% band:")
for X in (1000, 1500, 2000, 2500, 3000, 4000, 6000, 1e4, 2e4, 5e4, 1e9):
    n = Nrev(X); lo, hi = sig(X, SLO), sig(X, SHI)
    print("  X %-6g N %.3g  68%% %.2g-%.2g  90%% %.2g-%.2g   P(S_min<=X) no-error %.2f, with error %.2f   g %.1f" % (
        X, n, n * math.exp(-lo), n * math.exp(hi), n * math.exp(-1.645 * lo), n * math.exp(1.645 * hi), 1 - math.exp(-n), F(Nrev, X),
        (math.log(Nrev(X * 1.15)) - math.log(Nrev(X / 1.15))) / math.log(1.15 ** 2) if X < 4e4 else float('nan')))
lam = np.where(z > 0, np.exp(z * SHI[1]), np.exp(z * SLO[1]))
pe = 1 - np.exp(-lam * Ninf)
print("P(exists): mean %.3f; at 16/50/84%% of the error distribution %.2f / %.2f / %.2f; at 5%%: %.2f" % (pe.mean(), *np.percentile(pe, [16, 50, 84]), np.percentile(pe, 5)))
