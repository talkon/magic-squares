"""Revised central curve after review (existence.md v2).
Starts from the analytic lens's sorted-universe sample (segs.json, full S-profiles) and applies, per segment
(N = vectors of the sum, x = ln S/S_min, k = number of primes):
  sq(N)      squares per sum x SQ12 for N >= 12k (9 sampled sums at N 15-45k: obs/an 1.23, 1-sigma 0.99-1.53)
  diag       PAIR (ladder pair factor 1.0-1.2 vs the model's 1.23-1.27) x NTR for N >= 3k (S,P traversal
             ratios rise with N; rS*rP x1.17 at N >= 3k -> pair x1.37 if SP ~ rS*rP)
             x K7 for k >= 7 (no traversal data; P ratio drifts 0.66/0.64/0.61 for k = 4/5/6)
             x X01 for x < 0.1 (S 0.66-0.83, P 0.52-0.57 there)
  primes >= 53 (never in universe or R): yield rho(S_min) of the base P, placed at S x C53, k+1
  coverage R(X) x (1 + tail beyond assignment scale 1.35)
  universe tail beyond scale 5e4 (geometric extrapolation of the per-half-octave yield)
The ratio corrected/plain (sorted units) multiplies the published analytic N_magic(X) x R(X)."""
import json, math, sys, numpy as np
D = "/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/"
sys.path.insert(0, D + "analytic")
VAR = dict(SQ12=1.23, PAIR=0.87, NTR=1.35, K7=0.85, X01=0.92, C53=2.0)
for a in sys.argv[1:]:
    k, v = a.split("="); VAR[k] = float(v)
d = json.load(open(D + "synth/rev/segs.json")); recs = d["recs"]
# ---- per-segment arrays
W, E, Nmid, X, K, Slo, Shi, SM, H, PIDX = [], [], [], [], [], [], [], [], [], []
for j, r in enumerate(recs):
    S = np.array(r["S"], float); lm = np.array(r["lEm"]); lN = np.array(r["lN"])
    lm = np.where(np.isfinite(lm), lm, -1e9)
    h = np.diff(S); dv = np.diff(lm); ea, eb = np.exp(lm[:-1]), np.exp(lm[1:])
    with np.errstate(divide="ignore", invalid="ignore"):
        seg = np.where(np.abs(dv) < 1e-9, h * ea, h * (eb - ea) / dv)
    n = len(seg)
    W += [r["w"]] * n; E += list(seg); Nmid += list(np.exp(0.5 * (lN[:-1] + lN[1:])))
    X += list(np.log(0.5 * (S[:-1] + S[1:]) / r["smin"])); K += [r["k"]] * n
    Slo += list(S[:-1]); Shi += list(S[1:]); SM += [r["smin"]] * n
    sc = 6 * math.exp(sum(a * math.log(p) for a, p in zip(r["P"], [2,3,5,7,11,13,17,19,23,29,31,37,41,43,47])) / 6)
    H += [int(2 * math.log2(sc))] * n; PIDX += [j] * n
W, E, Nmid, X, K, Slo, Shi, SM, H = map(np.array, (W, E, Nmid, X, K, Slo, Shi, SM, H))
E = np.where(np.isfinite(E), E, 0.0)
def fac(N, k, x, sq=True, diag=True):
    f = np.ones_like(N)
    if sq: f = f * np.where(N >= 12000, VAR["SQ12"], 1.0)
    if diag:
        f = f * VAR["PAIR"] * np.where(N >= 3000, VAR["NTR"], 1.0) * np.where(k >= 7, VAR["K7"], 1.0) * np.where(x < 0.1, VAR["X01"], 1.0)
    return f
# primes >= 53: fit rho vs ln S_min of the base P on the skeptic's PPS sample
ap = json.load(open(D + "skeptic/addprime_40.json"))
cf = np.polyfit(np.log([o["smin"] for o in ap]), [o["rho_ge53"] for o in ap], 1)
rho53 = np.clip(np.polyval(cf, np.log(SM)), 0, None)
def upto(Xc, lo, hi, e):
    """contribution of segments [lo,hi] with S <= Xc (log-linear partial ~ linear in S within a segment)"""
    t = np.clip((Xc - lo) / (hi - lo), 0, 1)
    return e * t
def total(Xc, which="corr", parts=False):
    base = W * E
    if which == "plain": main = base; extra = 0 * base
    else:
        main = base * fac(Nmid, K, X)
        extra = base * rho53 * fac(Nmid, K + 1, X - 0.05)    # P*p: same N at the yield peak (n53.py), k+1, slightly lower x
    m = upto(Xc, Slo, Shi, main).sum(); ex = upto(Xc, VAR["C53"] * Slo, VAR["C53"] * Shi, extra).sum()
    return (m, ex) if parts else m + ex
# ---- check against the published sorted estimate (no perm multiplier) at a few X
from gs3_est import est
g = json.load(open(D + "analytic/gs3_n6.json"))
XG, tot0, _, mult, _ = est(g, "lEm_lin", perm=False)
print("check plain sorted vs gs3 est (X: mine / published):", "  ".join("%g: %.3g/%.3g" % (x, total(x, "plain"), np.interp(x, XG, tot0)) for x in (1500, 3000, 1e4, 5e4)))
# ---- per half-octave of scale: plain yield, untruncated, and the tail beyond the universe (scale <= 5e4)
print("\nper half-octave of scale (sorted units, untruncated S): scale, plain, corrected")
hb = {}
for h in sorted(set(H)):
    m = H == h
    pl = (W * E)[m].sum(); co = (W * E * fac(Nmid, K, X))[m].sum()
    hb[h] = (pl, co)
    if pl > 1e-4: print("  %6.0f  %.4f  %.4f" % (2 ** (h / 2), pl, co))
hs = [h for h in (26, 27, 28, 29, 30)]
r_pl = math.exp(np.polyfit(hs, np.log([hb[h][0] for h in hs]), 1)[0])
r_co = math.exp(np.polyfit(hs, np.log([hb[h][1] for h in hs]), 1)[0])
def tail(idx, r):
    T30 = hb[30][idx]; T31 = hb.get(31, (0, 0))[idx]
    return max(T30 * r - T31, 0) + T30 * r * r / (1 - r)
tail_pl, tail_co = tail(0, r_pl), tail(1, r_co)
print("decay per half-octave (fit 8k-46k): plain %.2f, corrected %.2f; tail beyond scale 5e4: plain %.3f, corrected %.3f (sorted)" % (r_pl, r_co, tail_pl, tail_co))
# ---- published curve x R, revised curve
ft = json.load(open(D + "analytic/final_tables.json"))["6"]["rows"]
Xa = np.array([r["X"] for r in ft], float); Na = np.array([r["Nm"] for r in ft])
RX = np.array([1000, 1500, 2000, 3000, 4000, 6000, 10000, 20000, 1e9]); RR = np.array([1.14, 1.33, 1.39, 1.44, 1.53, 1.52, 1.62, 1.62, 1.62])
DX = np.array([1000, 3000, 6000, 1e4, 2e4, 1e9]); DD = np.array([0.005, 0.015, 0.03, 0.045, 0.05, 0.05])
R = lambda x: float(np.interp(math.log(x), np.log(RX), RR, left=1.14))
dR = lambda x: float(np.interp(math.log(x), np.log(DX), DD, left=0.005))
Nan = lambda x: math.exp(np.interp(math.log(x), np.log(Xa), np.log(np.maximum(Na, 1e-30))))
INF = 1e9
def old(x): return Nan(min(x, 5e4)) * R(x)
pl50 = total(5e4, "plain")
def new(x, parts=False):
    if x <= 5e4:
        ratio = total(x) / total(x, "plain"); base = Nan(x)
    else:
        ratio = (total(x) + (tail_co * (1 + total(INF, parts=True)[1] / total(INF, parts=True)[0]) if x >= INF else 0)) / pl50; base = Nan(5e4)
    return base * R(x) * (1 + dR(x)) * ratio
XS = [1000, 1500, 2000, 2500, 3000, 4000, 6000, 1e4, 2e4, 5e4, INF]
print("\n| X | old central | revised | factor | of which: squares N>=12k | diagonals | primes>=53 | coverage tail | universe tail |")
for x in XS:
    xc = min(x, 5e4) if x < INF else INF
    pl = total(xc, "plain")
    sq = (upto(xc, Slo, Shi, W * E * fac(Nmid, K, X, sq=True, diag=False)).sum()) / pl
    dg = (upto(xc, Slo, Shi, W * E * fac(Nmid, K, X)).sum()) / (upto(xc, Slo, Shi, W * E * fac(Nmid, K, X, diag=False)).sum())
    m, ex = total(xc, parts=True)
    ut = 1.0
    if x >= INF: ut = (m + ex + tail_co * (1 + ex / m)) / (m + ex)
    o = old(x) if x < INF else old(5e4) * 1.0
    print("| %g | %.3g | %.3g | %.2f | %.2f | %.2f | %.3f | %.3f | %.3f |" % (x, o, new(x), new(x) / o, sq, dg, 1 + ex / m, 1 + dR(x), ut))
json.dump(dict(VAR=VAR, curve=[[x, new(x)] for x in list(np.geomspace(700, 5e4, 120)) + [INF]], decay=[r_pl, r_co], tail=[tail_pl, tail_co]),
          open(D + "synth/rev/curve_%s.json" % ("_".join("%s%g" % kv for kv in sorted(VAR.items()) if kv[0] != "C53") if len(sys.argv) > 1 else "central"), "w"))
# ---- where the revised total sits, by N band, at several X (sorted units, corrected, main part only)
print("\nshare of revised N_magic(X) by N band (main part):")
bands = [0, 3000, 12000, 32000, 45000, 1e5, 1e12]
for x in (2000, 3000, 4000, 6000, 1e4, 5e4, INF):
    xc = x
    c = upto(xc, Slo, Shi, W * E * fac(Nmid, K, X)); t = c.sum()
    print("  X %-6g " % x + "  ".join("[%gk,%gk): %.2f" % (bands[i] / 1e3, bands[i + 1] / 1e3, c[(Nmid >= bands[i]) & (Nmid < bands[i + 1])].sum() / t) for i in range(len(bands) - 1))
          + "   k>=7: %.2f  x<0.1: %.2f" % (c[K >= 7].sum() / t, c[X < 0.1].sum() / t))
print("\nplain sorted: total(5e4) %.4f  total(inf, within universe) %.4f" % (total(5e4, "plain"), total(INF, "plain")))
