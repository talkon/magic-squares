"""Re-evaluate every P of the analytic lens's stratified sample (gs3_n6.json, sorted universe, scale <= 5e4)
with the full S-profile (no S <= 5e4 cap; S <= 4 S_min), keeping N, x, k per grid point so that
N-, k- and x-dependent corrections can be applied (rev.py)."""
import os, sys, json, math, collections
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
A = "/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/analytic"
sys.path.insert(0, A); os.chdir(A)
import numpy as np, gmodel, maxent
g = json.load(open("gs3_n6.json")); st = g["strata"]
by = collections.defaultdict(list)
for r in g["res"]: by["|".join(map(str, r["st"]))].append(tuple(r["P"]))
out = []
for key, Nst in st.items():
    v = by.get(key)
    if not v: continue
    w = Nst / len(v)
    for P in v:
        o = gmodel.eval_P(P, 6, 1e12, fmax=4.0, npts=34)
        maxent._div_cache.clear()
        if o is None: continue
        out.append(dict(P=list(P), st=key, w=w, smin=o["smin"], k=sum(1 for a in P if a > 0),
                        S=o["S"], lEm=[float(x) for x in o["lEm_lin"]], lEs=[float(x) for x in o["lEs_lin"]],
                        lN=[float(x) for x in o["lN"]]))
json.dump(dict(XG=g["XG"], recs=out), open("/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/synth/rev/segs.json", "w"))
print("P", len(out))
