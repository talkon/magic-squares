"""N and S-profile of P*p (p >= 53) vs P under the analytic model: how the added-prime yield is placed."""
import os, sys, math
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
sys.path.insert(0, "/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/analytic")
import numpy as np, maxent, gmodel
def primes(n):
    s=[True]*(n+1); s[0]=s[1]=False
    for i in range(2,int(n**.5)+1):
        if s[i]: s[i*i::i]=[False]*len(s[i*i::i])
    return [i for i in range(n+1) if s[i]]
PL=primes(400); maxent.PRIMES=PL; gmodel.PR=PL
for P in [(13,7,4,3,1,1),(13,6,5,2,1,1),(14,8,5,3,2,1,1),(12,7,3,3,2,0,1,1)]:
    for extra in (None, 53, 67):
        Q=list(P)
        if extra:
            idx=PL.index(extra); Q=Q+[0]*(idx+1-len(Q)); Q[idx]=1
        r=gmodel.eval_P(tuple(Q),6,1e12,fmax=3.0,npts=30,exact_smin=False)
        maxent._div_cache.clear()
        S=np.array(r["S"],float); lm=np.array(r["lEm_lin"]); lN=np.array(r["lN"])
        w=np.exp(lm-lm.max()); w/=w.sum()
        print(P, extra, "smin %.0f"%r["smin"], "E %.3g"%gmodel.cum(S,lm,1e12), "yield-weighted lnN %.2f (N %.0f)"%((w*lN).sum(), math.exp((w*lN).sum())), "x_w %.3f"%(w*np.log(S/r["smin"])).sum())
