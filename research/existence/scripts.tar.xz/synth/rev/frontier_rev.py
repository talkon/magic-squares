"""Ideal-scheduler frontier E(C) with the revised per-segment E (rev.py factors), sums with S <= 2 S_min.
Same time models as synth/frontier_rec.py. Reports E at fixed budgets with the model-error band, the CPU for
E = 1 at several constant factors F on E, and F-independent ratios between time models."""
import json, math, sys, numpy as np
D = "/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/"
sys.path.insert(0, "/home/user/magic-squares/scripts")
import scheduler as sch
VAR = dict(SQ12=1.23, PAIR=0.87, NTR=1.35, K7=0.85, X01=0.92, C53=2.0, MULT=2.7)
for a in sys.argv[1:]:
    k, v = a.split("="); VAR[k] = float(v)
recs = json.load(open(D + "synth/rev/segs.json"))["recs"]
ap = json.load(open(D + "skeptic/addprime_40.json"))
cf = np.polyfit(np.log([o["smin"] for o in ap]), [o["rho_ge53"] for o in ap], 1)
def fac(N, k, x):
    return (np.where(N >= 12000, VAR["SQ12"], 1.0) * VAR["PAIR"] * np.where(N >= 3000, VAR["NTR"], 1.0)
            * np.where(k >= 7, VAR["K7"], 1.0) * np.where(x < 0.1, VAR["X01"], 1.0))
w, Em, ns, N, PART = [], [], [], [], []
for r in recs:
    S = np.array(r["S"], float); lm = np.array(r["lEm"]); lN = np.array(r["lN"]); lm = np.where(np.isfinite(lm), lm, -1e9)
    keep = S <= 2 * r["smin"] + 1
    S, lm, lN = S[keep], lm[keep], lN[keep]
    if len(S) < 2: continue
    h = np.diff(S); dv = np.diff(lm); ea, eb = np.exp(lm[:-1]), np.exp(lm[1:])
    with np.errstate(divide="ignore", invalid="ignore"):
        seg = np.where(np.abs(dv) < 1e-9, h * ea, h * (eb - ea) / dv)
    seg = np.where(np.isfinite(seg), seg, 0.0)
    Nm = np.exp(0.5 * (lN[:-1] + lN[1:])); x = np.log(0.5 * (S[:-1] + S[1:]) / r["smin"])
    rho = max(np.polyval(cf, math.log(r["smin"])), 0.0)
    # base P, then P*p in three prime classes: (share of the p >= 53 yield, number of primes, sum-range stretch)
    for part, mult_ns, kk, xx, rr in (("main", 1.0, r["k"], x, 1.0), ("53", 1.94 * 1, r["k"] + 1, x - 0.05, 0.22 * rho),
                                      ("59-71", 2.0 * 4, r["k"] + 1, x - 0.05, 0.45 * rho), (">=73", 2.1 * 50, r["k"] + 1, x - 0.05, 0.33 * rho)):
        e = seg * rr * fac(Nm, kk, xx)
        w += [r["w"]] * len(e); Em += list(e); ns += list(h * mult_ns); N += list(Nm / 1.05); PART += [part] * len(e)
w, Em, ns, N, PART = map(np.array, (w, Em, ns, N, PART))
M = sch.Model.load(D.replace("existence/", "") + "forecast/state/model_6.json")
ts = np.array([M.sum_time(v) for v in np.minimum(N, 4000)])
def t_meas(a2=5.2):
    t = np.where(N <= 4000, ts, 51.3 * (N / 4000.0) ** 3.92)
    return np.where(N > 2e4, 51.3 * 5.0 ** 3.92 * (N / 2e4) ** a2, t)
def t_alpha(alpha, N0=4000.):
    base = 51.3 * (N0 / 4000.0) ** 3.92 if N0 >= 4000 else M.sum_time(N0)
    return np.where(N <= N0, t_meas(), base * (N / N0) ** alpha)
models = [("current build (measured)", t_meas()), ("t ~ N^3 beyond N = 4,000", t_alpha(3.0)), ("t ~ N^2 beyond N = 4,000", t_alpha(2.0)),
          ("2x faster at all N", t_meas() / 2), ("10x faster at all N", t_meas() / 10), ("100x faster at all N", t_meas() / 100)]
Cs = np.array([1, 10, 100, 1000, 1e4])
MU = VAR["MULT"]
def curve(t):
    T = w * ns * t / 3600.0 / 8766; E = w * Em
    o = np.argsort(-(Em / (ns * t))); cT = np.cumsum(T[o]) * MU; cE = np.cumsum(E[o]) * MU
    return cT, cE
print("total E (S <= 2 S_min, all assignments): %.2f" % (MU * (w * Em).sum()))
res = {}
print("| time model | " + " | ".join("%g CPU-yr" % c for c in Cs) + " | CPU-yr for E=1 at F = 1/2, 1, 2 |")
for name, t in models:
    cT, cE = curve(t)
    vals = np.interp(Cs, cT, cE)
    def cfor(F):
        if cE[-1] * F < 1: return "> all (max %.2f)" % (cE[-1] * F)
        return "%.3g" % np.interp(1.0 / F, cE, cT)
    res[name] = vals
    print("| %s | " % name + " | ".join("%.3g" % v for v in vals) + " | %s / %s / %s |" % (cfor(0.5), cfor(1), cfor(2)))
base = res[models[0][0]]
print("\nratios E(model)/E(current) at fixed CPU (independent of a constant factor on E):")
for name, _ in models[1:]:
    print("  %-28s " % name + "  ".join("%.2f" % (v / b) for v, b in zip(res[name], base)))
cT, cE = curve(t_meas())
print("\nCPU-yr for E = 1 with a constant factor F on E (current build):")
for F in (0.25, 0.3, 1 / 3.2, 0.35, 0.4, 0.5, 1 / 1.5, 1.0, 1.5, 2.0, 3.2, 4.0):
    print("  F %.2f: %s" % (F, ("%.3g" % np.interp(1.0 / F, cE, cT)) if cE[-1] * F >= 1 else "beyond S <= 2 S_min (max E %.2f)" % (cE[-1] * F)))
print("  slope dE/dlog10 C at 1-1000 CPU-yr: " + " ".join("%.2f" % (b - a) for a, b in zip(base[:-1], base[1:])))
t = t_meas()
print("\nby N band (current build, base assignments x MULT, without the P*p part): E available / CPU-yr to search all / CPU-yr per expected magic square")
for lo, hi in ((0, 2000), (2000, 4000), (4000, 8000), (8000, 16000), (16000, 32000), (32000, 64000), (64000, 1e12)):
    m = (N >= lo) & (N < hi) & (PART == "main")
    Eb = MU * (w * Em)[m].sum(); Tb = MU * (w * ns * t)[m].sum() / 3600 / 8766
    print("  N [%g,%g): %.3g  %.3g  %.3g" % (lo, hi, Eb, Tb, Tb / max(Eb, 1e-30)))
