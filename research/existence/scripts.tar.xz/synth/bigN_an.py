import sys, math, json, numpy as np
A="/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/analytic"
sys.path.insert(0, A)
from batch2 import batch
from gmodel import lK, KAPPA
from model import ndiag_pairs
rows = json.load(open("/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/model/sample/bigN_rows.json"))
def hc(N): return 0.64*(N/1e4)**-0.27 if N>=3000 else 0.8
out=[]
print("P                       S      N   Nan    obs_est  an_pred   Hcorr   y   Ey_an  Ey_Hc  1/pmag_an 1/pmag_mod")
for r in rows:
    P = tuple(r['P']); S=r['S']
    o = batch(P, np.array([float(S)]), 6)
    sa = math.exp(o["logEsemi"][0] + lK(o["ld_n2"][0], 6, "lin"))
    pa = math.exp(math.log(ndiag_pairs(6)) + o["lpair"][0] + math.log(KAPPA))
    # scale analytic to actual N? report raw
    f = r['y']/r['est'] if r['est']>0 else r['f']
    if r['y']==0: f=r['f']
    hcv = r['H_raw']*hc(r['N'])
    out.append(dict(P=P,S=S,N=r['N'],Nan=math.exp(o['logN'][0]),y=r['y'],f=f,an=sa,hc=hcv,pa=pa,pm=r['p_magic'],src=r['src'],t=r['t']))
    print("%-22s %5d %6d %6.0f %8.0f %8.0f %8.0f %4d %6.1f %6.1f %9.3g %9.3g" % (",".join(map(str,P)),S,r['N'],out[-1]['Nan'],r['est'],sa,hcv,r['y'],sa*f,hcv*f,1/pa,1/r['p_magic']))
for lab, sel in [("all 17", lambda d: True), ("N<12k full", lambda d: d['N']<12000), ("N>=12k sampled", lambda d: d['N']>=12000)]:
    ds=[d for d in out if sel(d)]
    y=sum(d['y'] for d in ds); ea=sum(d['an']*d['f'] for d in ds); eh=sum(d['hc']*d['f'] for d in ds)
    print(lab, "obs", y, "analytic %.1f (obs/pred %.2f)" % (ea, y/ea), "Hcorr %.1f (%.2f)" % (eh, y/eh))
# slope of log(obs/an) vs log N, Poisson-weighted
import numpy as np
ln = np.array([math.log(d['N']/1e4) for d in out]); y=np.array([d['y'] for d in out],float); mu=np.array([d['an']*d['f'] for d in out])
# poisson glm: y ~ mu*exp(a+b ln)
a=b=0.0
for it in range(50):
    lam = mu*np.exp(a+b*ln); g=np.array([(y-lam).sum(), ((y-lam)*ln).sum()]); H=np.array([[lam.sum(),(lam*ln).sum()],[(lam*ln).sum(),(lam*ln*ln).sum()]])
    st=np.linalg.solve(H,g); a+=st[0]; b+=st[1]
lam=mu*np.exp(a+b*ln); phi=((y-lam)**2/lam).sum()/(len(y)-2); cov=np.linalg.inv(H)*phi
print("obs/analytic = exp(%.3f + %.3f ln(N/1e4)); se %.3f %.3f (phi %.1f)" % (a,b,math.sqrt(cov[0,0]),math.sqrt(cov[1,1]),phi))
# the same for Hcorr
mu2=np.array([d['hc']*d['f'] for d in out]); a=b=0.0
for it in range(50):
    lam = mu2*np.exp(a+b*ln); g=np.array([(y-lam).sum(), ((y-lam)*ln).sum()]); H=np.array([[lam.sum(),(lam*ln).sum()],[(lam*ln).sum(),(lam*ln*ln).sum()]])
    st=np.linalg.solve(H,g); a+=st[0]; b+=st[1]
lam=mu2*np.exp(a+b*ln); phi=((y-lam)**2/lam).sum()/(len(y)-2); cov=np.linalg.inv(H)*phi
print("obs/Hcorr = exp(%.3f + %.3f ln(N/1e4)); se %.3f %.3f (phi %.1f)" % (a,b,math.sqrt(cov[0,0]),math.sqrt(cov[1,1]),phi))
json.dump(out, open("bigN_an.json","w"), default=list)
