import sys, math, json, numpy as np
A="/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/analytic"
M="/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/model"
sys.path.insert(0, A); sys.path.insert(0, M)
from batch2 import batch
from gmodel import lK, KAPPA
from model import ndiag_pairs
import epop
from mlib import trav, pmagic
from legcheck import sq_H
def hcorr(N): return np.where(N>=3000, 0.64*(N/1e4)**-0.27, 0.8)
for P in [tuple(int(x) for x in a.split(",")) for a in sys.argv[1:]]:
    Sg, Ng, s0 = epop.profile(P)
    xs = np.array([0.05,0.1,0.2,0.3,0.4,0.5,0.7,1.0])
    S = np.round(s0*np.exp(xs))
    o = batch(P, S, 6)
    Nm = np.interp(np.log(S/s0), epop.XG, Ng)
    sqm = sq_H(P, S, Nm, s0)*hcorr(Nm)
    pm = pmagic(trav(P,S,s0,'s',clampP=False), trav(P,S,s0,'p',clampP=False), 2.6)
    print(P, "smin_model %.0f" % s0)
    print("   x     S     N_an    N_mod    sq_an     sq_mod   r_sq   1/pm_an   1/pm_mod  r_pm   Em_an/sum  Em_mod/sum")
    for i,s in enumerate(S):
        les = o["logEsemi"][i] + lK(o["ld_n2"][i], 6, "lin")
        pa = math.exp(math.log(ndiag_pairs(6)) + o["lpair"][i] + math.log(KAPPA))
        sa = math.exp(les)
        print("  %.2f %6.0f %8.3g %8.3g %9.3g %9.3g %6.2f %9.3g %9.3g %6.2f %9.3g %9.3g" % (xs[i], s, math.exp(o["logN"][i]), Nm[i], sa, sqm[i], sqm[i]/sa, 1/pa, 1/pm[i], pm[i]/pa, sa*pa, sqm[i]*pm[i]))
