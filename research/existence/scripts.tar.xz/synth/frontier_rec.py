import json, math, numpy as np, sys
sys.path.insert(0, "/home/user/magic-squares/scripts")
import scheduler as sch
A_=json.load(open("/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/analytic/frontier_segs.json")); A=np.array(A_["segs"])
w, Em, Es, ns, N = A.T
M = sch.Model.load("/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/forecast/state/model_6.json")
ts = np.array([M.sum_time(x) for x in np.minimum(N, 4000)])
def t_meas(N, a2=None):
    t = np.where(N <= 4000, ts, 51.3 * (N / 4000.0) ** 3.92)
    if a2: t = np.where(N > 2e4, 51.3 * 5.0 ** 3.92 * (N / 2e4) ** a2, t)
    return t
def t_alpha(alpha, N0):   # measured up to N0, then N^alpha
    base = t_meas(np.minimum(N, N0), 5.2)
    return np.where(N <= N0, t_meas(N, 5.2), base * (N / N0) ** alpha)
models = [("measured: 51 s (N/4000)^3.92", t_meas(N)), ("measured, slope 5.2 above 2x10^4", t_meas(N, 5.2)),
          ("10x faster than measured (all N)", t_meas(N, 5.2) / 10), ("N^3 beyond 4,000", t_alpha(3.0, 4000.)),
          ("N^2 beyond 4,000", t_alpha(2.0, 4000.)), ("100x faster than measured", t_meas(N, 5.2) / 100)]
Cs = [8766, 87660, 876600, 8766000, 87660000]
for MULT in (1.77, 2.6):
    print("MULT", MULT, "E total S<=2Smin: %.2f" % (MULT * (w * Em).sum()))
    print("| time model | 1 CPU-yr | 10 | 100 | 1,000 | 10^4 | CPU-yr for E = 0.5 | E = 1 |")
    for name, t in models:
        T = w * ns * t / 3600.0; E = w * Em
        o = np.argsort(-(Em / (ns * t))); cT = np.cumsum(T[o]) * MULT; cE = np.cumsum(E[o]) * MULT
        vals = [np.interp(C, cT, cE) for C in Cs]
        def cfor(e):
            if cE[-1] < e: return "never (max %.2f)" % cE[-1]
            return "%.3g" % (np.interp(e, cE, cT) / 8766)
        print(f"| {name} | " + " | ".join(f"{v:.3g}" for v in vals) + f" | {cfor(0.5)} | {cfor(1.0)} |")
    print()
# E and CPU by N band (measured steep)
t = t_meas(N, 5.2); MULT=2.6
for lo, hi in ((0, 2000), (2000, 4000), (4000, 8000), (8000, 16000), (16000, 32000), (32000, 64000), (64000, 1e9)):
    m = (N >= lo) & (N < hi)
    Eb = MULT * (w * Em)[m].sum(); Tb = MULT * (w * ns * t)[m].sum() / 3600 / 8766
    print(f"  N [{lo},{hi:.0f}): E_magic {Eb:.3g}  CPU-yr to search all {Tb:.3g}  CPU-yr per magic {Tb/max(Eb,1e-30):.3g}")
