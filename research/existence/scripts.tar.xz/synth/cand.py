import subprocess, sys, math, os
E="/home/user/magic-squares/bin/enumerate"
for P in [(15,6,4,3,2,1,1),(16,8,4,3,2,1),(12,8,4,3,2,1,1),(13,7,5,3,2,1,1),(10,6,4,3,2,1,1,1),(14,7,4,3,2,2,1)]:
    ps=[str(e) for e in P]
    s0=int(subprocess.run([E,"--print-min-sum"]+ps,capture_output=True,text=True).stdout.split()[0])
    f="tmpc.txt"
    subprocess.run(["bash","-c",f"ulimit -v 4000000; {E} --counts --reduce none --min-sum {s0} --max-sum {int(s0*1.15)} --file {f} "+" ".join(ps)],capture_output=True)
    cnt={}
    for l in open(f):
        a,b=l.split(); cnt[int(a)]=int(b)
    os.remove(f)
    S=min((s for s in cnt if cnt[s]>=38000), default=None)
    if S is None: print(P, s0, "max N", max(cnt.values())); continue
    N=cnt[S]
    a=subprocess.run(["python3","../analytic/predS.py",",".join(ps),str(S)],capture_output=True,text=True).stdout.strip()
    m=subprocess.run(["python3","../model/sample/predict.py",str(S),str(N),str(s0),"0"]+ps,capture_output=True,text=True).stdout
    H=[float(l.split()[1]) for l in m.splitlines() if l.startswith("H_raw ")][0]
    print(P, "smin",s0,"S",S,"x %.3f"%math.log(S/s0),"N",N, "| Hcorr %.0f" % (H*0.64*(N/1e4)**-0.27), "|", a.split(")")[1])
