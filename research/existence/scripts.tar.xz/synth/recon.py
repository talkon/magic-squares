import json, math, numpy as np
# analytic (lin) N_magic(X) incl. its own perm multiplier and grid bias (final_tables.json), x coverage factor R(X)
ft=json.load(open("/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/analytic/final_tables.json"))["6"]["rows"]
Xa=np.array([r["X"] for r in ft],float); Na=np.array([r["Nm"] for r in ft])
RX=np.array([1000,1500,2000,3000,4000,6000,10000,20000,1e9]); RR=np.array([1.14,1.33,1.39,1.44,1.53,1.52,1.62,1.62,1.62])
def R(X): return np.interp(math.log(X), np.log(RX), RR, left=1.14)
def Nan(X): return math.exp(np.interp(math.log(X), np.log(Xa), np.log(np.maximum(Na,1e-30))))*R(X)
# model lens central (all P) and its N<=32k-only variant (model.md section 1)
Xm=np.array([1000,1500,2000,2500,3000,4000,5000,7000,1e4,2e4,3e4]); Nm=np.array([0.0065,0.058,0.22,0.54,1.2,3.2,6.2,18,62,400,990])
def Nmod(X): return math.exp(np.interp(math.log(X), np.log(Xm), np.log(Nm)))
XS=[500,700,1000,1500,2000,2500,3000,4000,5000,6000,8000,1e4,2e4,3e4,5e4]
print("| X | analytic (lens) | analytic x coverage R(X) | g | model lens | g | ratio model/analytic-corr |")
for X in XS:
    a=Nan(X); g=(math.log(Nan(X*1.15))-math.log(Nan(X/1.15)))/math.log(1.15**2)
    if 1000<=X<=3e4:
        m=Nmod(X); gm=(math.log(Nmod(min(X*1.15,3e4)))-math.log(Nmod(max(X/1.15,1000))))/math.log(min(X*1.15,3e4)/max(X/1.15,1000))
        ms="%.3g | %.1f | %.2f" % (m, gm, m/a)
    else: ms="- | - | -"
    print("| %g | %.3g | %.3g | %.1f | %s |" % (X, a/R(X), a, g, ms))
# smallest-S distribution with lognormal model error sigma on E
rng=np.random.default_rng(1); 
def quant(Nf, sigma, Xgrid):
    lam=np.exp(rng.normal(0,sigma,20000))
    F=np.array([np.mean(1-np.exp(-lam*Nf(X))) for X in Xgrid])
    return F
Xg=np.exp(np.linspace(math.log(800),math.log(5e4),400))
for name,Nf,lo,hi in [("analytic x R",Nan,800,5e4),("model lens",Nmod,1000,3e4)]:
    xg=Xg[(Xg>=lo)&(Xg<=hi)]
    for sig in (0.0,0.9):
        F=quant(Nf,sig,xg)
        q=lambda p: (xg[np.searchsorted(F,p)] if F[-1]>=p else float('nan'))
        cross=xg[np.searchsorted([Nf(x) for x in xg],1.0)] if Nf(xg[-1])>=1 else float('nan')
        print("%-14s sigma %.1f: X(N=1) %.0f  P(min<=X): 10%% %.0f  25%% %.0f  50%% %.0f  75%% %.0f  90%% %.0f   P(exists within grid) %.3f" % (name,sig,cross,q(.1),q(.25),q(.5),q(.75),q(.9),F[-1]))
# 50/50 mixture of the two curves (model lens capped at 3e4 -> treat beyond as 1e3)
def mix(X): return None
