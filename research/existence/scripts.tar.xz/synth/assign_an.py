"""Analytic model: E(S<=X) summed over ALL assignments of an exponent multiset to the first 16 primes
(scale <= FAC x sorted), vs the subset the analytic lens's gs3 procedure covers (gen2 universe = sorted with
<= 1 zero gap at index >= 4, plus permutations within len(u) positions with scale <= 1.3x)."""
import sys, math, json, time, itertools, collections
A="/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/analytic"
sys.path.insert(0, A)
import numpy as np
from gmodel import eval_P, cum
import gs3, maxent
from smin import save
PR=[2,3,5,7,11,13,17,19,23,29,31,37,41,43,47]
LP=[math.log(p) for p in PR]
XS=[1000,1500,2000,3000,4000,6000,10000,20000,1e9]
FAC=float(sys.argv[1]); ms=[tuple(int(x) for x in a.split(",")) for a in sys.argv[2:]]
def lp(q): return sum(a*LP[i] for i,a in enumerate(q))
def assignments(mult, lmax):
    vals=sorted(mult, reverse=True); out=set()
    def rec(j, used, q, l):
        if j==len(vals):
            t=list(q)
            while t and t[-1]==0: t.pop()
            out.add(tuple(t)); return
        v=vals[j]
        for i in range(15):
            if i in used: continue
            nl=l+v*LP[i]
            # lower bound for the rest: remaining values on the smallest free primes
            free=[k for k in range(15) if k not in used and k!=i]
            rest=sum(w*LP[k] for w,k in zip(vals[j+1:], free))
            if nl+rest>lmax+1e-9: continue
            q[i]=v; used.add(i); rec(j+1, used, q, nl); used.discard(i); q[i]=0
    rec(0,set(),[0]*15,0.0)
    return out
res={}
for m in ms:
    t0=time.time()
    srt=tuple(sorted(m, reverse=True)); l0=lp(srt)
    allq=assignments(m, l0+6*math.log(FAC))
    # analytic-lens coverage
    gs3.UNIV["Xlo"],gs3.UNIV["Xhi"]=0,1e300
    U=[q for q in allq if gs3.in_universe(q,6)]
    cov=set(U)
    for u in U:
        for q in gs3.bounded_perms(u,6,lp(u)+6*math.log(1.3)):
            gapped = 0 in u
            if gapped and q[-1]==0: continue
            t=list(q)
            while t and t[-1]==0: t.pop()
            cov.add(tuple(t))
    rows=[]
    for q in sorted(allq, key=lp):
        r=eval_P(q,6,1e9,npts=22)
        if r is None: continue
        E=[cum(r["S"], r["lEm_lin"], X) for X in XS]
        rows.append(dict(q=q, smin=r["smin"], scale=math.exp((lp(q)-l0)/6), E=E, inU=q in U, cov=q in cov))
        maxent._div_cache.clear()
    save()
    tot=np.array([r["E"] for r in rows]).sum(0); s0=np.array([r["E"] for r in rows if r["q"]==srt][0])
    tU=np.array([r["E"] for r in rows if r["inU"]]).sum(0); tC=np.array([r["E"] for r in rows if r["cov"]]).sum(0)
    print(m, "assignments", len(rows), "in U", len(U), "covered", sum(r["cov"] for r in rows), "time %.0fs"%(time.time()-t0), flush=True)
    for i,X in enumerate(XS):
        print("   X %7g: sorted %.3g  all/sorted %.2f  U/sorted %.2f  covered/sorted %.2f  all/covered %.2f" % (X, s0[i], tot[i]/max(s0[i],1e-300), tU[i]/max(s0[i],1e-300), tC[i]/max(s0[i],1e-300), tot[i]/max(tC[i],1e-300)))
    for lo,hi in [(1,1.05),(1.05,1.1),(1.1,1.2),(1.2,1.3),(1.3,2)]:
        sel=[r for r in rows if lo<=r["scale"]<hi]
        print("     scale [%.2f,%.2f): %4d assignments, E(inf) share of sorted %.2f" % (lo,hi,len(sel), sum(r["E"][-1] for r in sel)/s0[-1]))
    res[",".join(map(str,m))]=dict(rows=rows, XS=XS)
json.dump(res, open("assign_an_%s.json"%int(time.time()),"w"), default=str)
