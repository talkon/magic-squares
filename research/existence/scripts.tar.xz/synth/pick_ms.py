import json, collections, random, numpy as np
d=json.load(open("/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/analytic/gs3_n6.json"))
XG=np.array(d["XG"]); st=d["strata"]
by=collections.defaultdict(list)
for r in d["res"]: by["|".join(map(str,r["st"]))].append(r)
items=[]
for key,rs in by.items():
    w=st[key]/len(rs)
    for r in rs:
        F=np.array(r["lEm_lin"]); items.append((tuple(r["P"]), w, F))
i6=np.argmin(abs(XG-6000)); i3=np.argmin(abs(XG-3000))
c=np.array([w*F[i6] for P,w,F in items]); tot=c.sum()
print("sorted-universe total at 6000 (no perm mult): %.3f; at 3000: %.3f" % (tot, sum(w*F[i3] for P,w,F in items)))
rs=random.Random(7); pick=set()
idx=list(range(len(items)))
while len(pick)<24:
    i=rs.choices(idx, weights=c)[0]
    ms=tuple(sorted([a for a in items[i][0] if a>0], reverse=True)); pick.add(ms)
print(" ".join(",".join(map(str,m)) for m in sorted(pick)))
# share of E by k
kk=collections.Counter()
for (P,w,F),ci in zip(items,c): kk[sum(1 for a in P if a)]+=ci
print({k:round(v/tot,3) for k,v in sorted(kk.items())})
