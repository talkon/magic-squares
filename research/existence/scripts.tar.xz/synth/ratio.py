import json, glob, numpy as np
fs=sorted(glob.glob("assign_an_*.json")); d=json.load(open(fs[-1]))
XS=[1000,1500,2000,3000,4000,6000,10000,20000,1e9]; i6=XS.index(6000)
num=np.zeros(len(XS)); den=np.zeros(len(XS)); num2=np.zeros(len(XS)); den2=np.zeros(len(XS)); rs=[]
for k,v in d.items():
    rows=v["rows"]
    E=np.array([[float(x) for x in r["E"]] for r in rows])
    inU=np.array([r["inU"] in (True,"True") for r in rows]); cov=np.array([r["cov"] in (True,"True") for r in rows])
    U=E[inU].sum(0); C=E[cov].sum(0); A=E.sum(0)
    p=U[i6]
    num+=A/p; den+=C/p; num2+=A/p; den2+=U/p
    rs.append((k, A[-1]/C[-1]))
for i,X in enumerate(XS): print("X %7g  all/covered %.2f   all/U %.2f" % (X, num[i]/den[i], num2[i]/den2[i]))
r=np.array([x[1] for x in rs]); print("per-multiset all/covered at inf: median %.2f, range %.2f-%.2f" % (np.median(r), r.min(), r.max()))
