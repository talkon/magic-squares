import sys, math
sys.path.insert(0,'../analytic')
from ehrpoly import poly
import numpy as np
H=poly(6)
Mex={0:1,1:96,2:14763,3:957936,4:33177456,5:718506720}
def M(a):
    if a in Mex: return float(Mex[a])
    return float(H(a))*1.18/(a+2.1)**2
def Hf(a): return float(H(a))
def primes(n):
    s=bytearray([1])*(n+1); s[0]=s[1]=0
    for i in range(2,int(n**.5)+1):
        if s[i]: s[i*i::i]=bytearray(len(s[i*i::i]))
    return [i for i in range(n+1) if s[i]]
PL=primes(200000)
def analyse(f, s, label, amax=80):
    # distribution of L = log P under weight prod f(a_p) p^{-s a}; build density on a grid of L via convolution for small primes, moments for the rest
    logD=0.0; mean=0.0; var=0.0
    grid=np.zeros(4000); dx=0.05; grid[0]=1.0   # L in [0,200)
    for p in PL:
        lp=math.log(p)
        w=[]
        for a in range(amax+1):
            v=f(a)*math.exp(-s*a*lp) if a>0 else 1.0
            w.append(v)
            if a>3 and v<1e-12*max(w): break
        Z=sum(w); logD+=math.log(Z)
        if p<1000:
            new=np.zeros_like(grid)
            for a,v in enumerate(w):
                sh=int(round(a*lp/dx))
                if sh<len(grid): new[sh:]+=grid[:len(grid)-sh]*v/Z
            grid=new
        else:
            m=sum(a*lp*v for a,v in enumerate(w))/Z; m2=sum((a*lp)**2*v for a,v in enumerate(w))/Z
            mean+=m; var+=m2-m*m
    L=np.arange(len(grid))*dx
    g=grid/grid.sum(); mu=(g*L).sum()+mean; sd=math.sqrt((g*(L-(g*L).sum())**2).sum()+var)
    # per half-octave of scale 6P^(1/6): Delta L = 6*ln(sqrt2)
    S=6*np.exp((L+mean)/6)
    print(f"{label}: log10 D = {logD/math.log(10):.1f}; mean log P = {mu:.1f} (sd {sd:.1f}) -> scale 6P^(1/6) at mean: {6*math.exp(mu/6):.3g}")
    cdf=np.cumsum(g)
    for q in (0.1,0.5,0.9):
        i=np.searchsorted(cdf,q); print(f"   {q:.0%} quantile of scale: {S[i]:.3g}")
    # mass per half-octave of scale around the peak
    hb=6*math.log(math.sqrt(2)); 
    edges=np.arange(0,L[-1],hb); 
    mass=[g[(L>=e)&(L<e+hb)].sum() for e in edges]
    pk=int(np.argmax(mass))
    print("   per-half-octave mass ratios after peak:", [round(mass[i+1]/mass[i],2) for i in range(pk,min(pk+8,len(mass)-1)) if mass[i]>0])
analyse(M, 2.0, "magic bound sum f^M(P) P^-2")
analyse(Hf, 2-2/6, "semi bound sum f(P) P^-(5/3)")
