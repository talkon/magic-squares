"""Missing-universe test: yield of P*p for primes p >= 53 (never in the analytic universe or R coverage),
relative to P, for a PPS sample of the analytic n=6 sample (prob ~ stratum weight x magic yield)."""
import os, sys, json, math, random, collections
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
sys.path.insert(0, '../analytic')
import numpy as np
import maxent, gmodel
def primes(n):
    s=[True]*(n+1); s[0]=s[1]=False
    for i in range(2,int(n**.5)+1):
        if s[i]: s[i*i::i]=[False]*len(s[i*i::i])
    return [i for i in range(n+1) if s[i]]
PL = primes(2000)
maxent.PRIMES = PL; gmodel.PR = PL
d = json.load(open('../analytic/gs3_n6.json'))
st = d['strata']; by = collections.defaultdict(list)
for r in d['res']: by["|".join(map(str, r['st']))].append(r)
items = []
for key, Nst in st.items():
    v = by.get(key)
    if not v: continue
    w = Nst / len(v)
    for r in v:
        e = r['lEm_lin'][-1]
        if e > 0: items.append((w * e, tuple(r['P']), r['smin'], w))
tot = sum(x[0] for x in items)
random.seed(int(sys.argv[2]) if len(sys.argv) > 2 else 7)
K = int(sys.argv[1]) if len(sys.argv) > 1 else 40
wts = [x[0] for x in items]
pick = random.choices(range(len(items)), weights=wts, k=K)
def Etot(P):
    r = gmodel.eval_P(P, 6, 1e12, exact_smin=False)
    if r is None: return 0.0, None
    return gmodel.cum(r['S'], r['lEm_lin'], 1e12), r['smin']
out = []
for i in pick:
    _, P, sm, w = items[i]
    E0, s0 = Etot(P)
    rho = {}
    L = len(P)
    for p in PL[:]:
        idx = PL.index(p)
        if idx < L and P[idx] > 0: continue
        if p < 37: continue
        Q = list(P) + [0] * max(0, idx + 1 - L); Q[idx] = 1
        E1, s1 = Etot(tuple(Q))
        rho[p] = E1 / E0 if E0 > 0 else 0.0
        maxent._div_cache.clear()
        if p > 60 and rho[p] < 1e-4 * max(rho.values()): break
    big = sum(v for p, v in rho.items() if p >= 53)
    small = sum(v for p, v in rho.items() if p < 53)
    pmax = max(rho)
    out.append(dict(P=P, smin=s0, E0=E0, rho_ge53=big, rho_37_47=small, pmax=pmax, rho=rho))
    print(P, round(s0), f"E0 {E0:.3g}  sum rho(p>=53) {big:.3f}  sum rho(37-47 not in P) {small:.3f}  p_last {pmax}", flush=True)
    maxent._div_cache.clear()
json.dump(out, open(f'addprime_{K}.json', 'w'))
a = np.array([o['rho_ge53'] for o in out]); b = np.array([o['rho_37_47'] for o in out])
print('PPS mean sum rho(p>=53): %.3f (se %.3f); mean rho(37-47): %.3f' % (a.mean(), a.std(ddof=1)/math.sqrt(len(a)), b.mean()))
