import json, math, collections, numpy as np, sys
d=json.load(open('../analytic/gs3_n6.json'))
st=d['strata']; XG=np.array(d['XG'])
by=collections.defaultdict(list)
for r in d['res']: by["|".join(map(str,r['st']))].append(r)
# per half-octave, composition by k, ones, last prime index, max exponent
comp=collections.defaultdict(lambda: collections.defaultdict(float))
tot=collections.defaultdict(float)
for key,Nst in st.items():
    h=int(key.split('|')[0]); v=by.get(key)
    if not v: continue
    w=Nst/len(v)
    for r in v:
        fm=r['lEm_lin'][-1]
        P=[a for a in r['P']]
        k=sum(1 for a in P if a); ones=sum(1 for a in P if a==1); last=len(P)
        tot[h]+=w*fm
        comp[h][('k',k)]+=w*fm; comp[h][('ones',ones)]+=w*fm; comp[h][('L',last)]+=w*fm
for h in sorted(tot):
    if tot[h]<=0: continue
    c=comp[h]
    ks={kk[1]:round(v/tot[h],3) for kk,v in sorted(c.items()) if kk[0]=='k' and v/tot[h]>0.005}
    on={kk[1]:round(v/tot[h],3) for kk,v in sorted(c.items()) if kk[0]=='ones' and v/tot[h]>0.005}
    L={kk[1]:round(v/tot[h],3) for kk,v in sorted(c.items()) if kk[0]=='L' and v/tot[h]>0.005}
    print(round(2**(h/2)), f"{tot[h]:.3g}", 'k',ks,'ones',on,'len',L)
