import sys, json, math, numpy as np
sys.path.insert(0,'../analytic')
from batch2 import batch
from model import ndiag_pairs
tot=np.zeros(4); obs=np.zeros(3)
for line in open('../analytic/runs5/squares5_le700.jsonl'):
    r=json.loads(line); P=tuple(r['P']); S=r['S']
    o=batch(P,np.array([float(S)]),5)
    pS=math.exp(o['lpS'][0]); pP=math.exp(o['lpP'][0]); pSP=math.exp(o['lpSP'][0]); pm=ndiag_pairs(5)*math.exp(o['lpair'][0])*0.57
    tot+=np.array([120*pS,120*pP,120*pSP,pm]); obs+=np.array([r['s_count'],r['p_count'],r['sp_count']])
    print(P,S,r['s_count'],r['p_count'],r['sp_count'],' model per square: S %.2f P %.3f SP %.4f magic %.2g'%(120*pS,120*pP,120*pSP,pm))
print('obs S/P/SP',obs,' model',tot[:3],' magic',tot[3])
