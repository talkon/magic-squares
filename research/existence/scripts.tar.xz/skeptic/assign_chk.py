import sys, math, itertools, collections
sys.path.insert(0,'../analytic')
import gmodel, maxent
PR=gmodel.PR[:15]; LP=[math.log(p) for p in PR]
def assignments(ms, lmax):
    ms=sorted(ms, reverse=True); out=set()
    cnt=collections.Counter(ms)
    def rec(i, cur, lp, rem):
        if sum(rem.values())==0:
            t=list(cur)
            while t and t[-1]==0: t.pop()
            out.add(tuple(t)); return
        if i==len(PR): return
        # remaining values must fit: lower bound by placing largest remaining on next primes
        vals=sorted(rem.elements(), reverse=True)
        lb=sum(v*LP[i+j] for j,v in enumerate(vals) if i+j<len(PR))
        if i+len(vals)>len(PR) or lp+lb>lmax+1e-9: return
        rec(i+1, cur+[0], lp, rem)
        for v in list(rem):
            if rem[v]==0: continue
            rem[v]-=1; rec(i+1, cur+[v], lp+v*LP[i], rem); rem[v]+=1
    rec(0, [], 0.0, cnt)
    return sorted(out)
for ms in [(13,7,4,3,1,1),(11,6,4,3,2,1),(15,6,4,3,2,1)]:
    l0=sum(a*LP[i] for i,a in enumerate(ms))
    A=assignments(ms, l0+6*math.log(1.35))
    def E(P):
        r=gmodel.eval_P(P,6,1e12,exact_smin=False); maxent._div_cache.clear()
        return gmodel.cum(r['S'],r['lEm_lin'],1e12) if r else 0.0
    e0=E(ms); tot=0.0; tot3k=0.0
    for P in A: tot+=E(P)
    print(ms, 'assignments within 1.35x scale:', len(A), ' all/sorted = %.2f'%(tot/e0))
