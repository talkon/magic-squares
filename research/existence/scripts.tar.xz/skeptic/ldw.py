import json, math, collections, numpy as np
d=json.load(open('../analytic/gs3_n6.json'))
st=d['strata']
by=collections.defaultdict(list)
for r in d['res']: by["|".join(map(str,r['st']))].append(r)
acc=collections.defaultdict(lambda: np.zeros(3))
for key,Nst in st.items():
    h=int(key.split('|')[0]); v=by.get(key)
    if not v: continue
    w=Nst/len(v)
    for r in v:
        fm=r['lEm_lin'][-1]
        if fm<=0: continue
        acc[h]+=w*fm*np.array([1,r['ld_w'],r['lN_w']])
T=sum(a[0] for a in acc.values())
for h in sorted(acc):
    a=acc[h]
    print(round(2**(h/2)), f"share {a[0]/T:.3f} ld_w {a[1]/a[0]:.2f}  lnN_w {a[2]/a[0]:.2f} (N~{math.exp(a[2]/a[0]):.0f})")
tot=sum(a for a in acc.values()); print('overall ld_w',tot[1]/tot[0],'N',math.exp(tot[2]/tot[0]))
