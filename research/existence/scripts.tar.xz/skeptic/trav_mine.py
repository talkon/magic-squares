"""Analytic per-traversal p_S, p_P (x the analytic lens's calibrations 0.86 / 0.64) and pair P(magic) vs observed
S/P/SP traversal counts, for every square in sums with N >= 3000 (full + sampled), and by x bin near S_min."""
import sys, glob, json, math, collections, numpy as np
A="/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/analytic"
SP="/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad"
sys.path.insert(0, A)
from batch2 import batch
paths = (glob.glob(SP+'/forecast/state/units/*.jsonl') + glob.glob(SP+'/verify-forecast/*/ms*.jsonl') + glob.glob(SP+'/verify-forecast/*/hx*.jsonl')
         + glob.glob(SP+'/existence/model/runs/*.jsonl') + glob.glob(SP+'/existence/model/sample/t*.jsonl') + glob.glob(SP+'/existence/model/sample/*2650_137*.jsonl'))
seen=set(); by=collections.defaultdict(list); nv={}
for p in paths:
    for l in open(p):
        try: r=json.loads(l)
        except Exception: continue
        if r.get("type")=="square":
            h=r.get("hash") or json.dumps(r["grid"])
            if h in seen: continue
            seen.add(h); by[(tuple(r["P"]), r["S"])].append(r)
        elif r.get("type")=="sum":
            nv[(tuple(r["P"]), r["S"])]=r.get("nvecs_raw")
print("squares", len(seen), "sums with squares", len(by))
smin_cache={}
import subprocess
def smin(P):
    if P not in smin_cache:
        smin_cache[P]=int(subprocess.run(["/home/user/magic-squares/bin/enumerate","--print-min-sum"]+[str(e) for e in P],capture_output=True,text=True).stdout.split()[0])
    return smin_cache[P]
rows=[]
byP=collections.defaultdict(list)
for (P,S),sq in by.items(): byP[P].append(S)
for P,Ss in byP.items():
    Ss=sorted(set(Ss)); o=batch(P, np.array(Ss,float), 6, want_dist=False)
    s0=smin(P)
    for i,S in enumerate(Ss):
        sq=by[(P,S)]; N=nv.get((P,S))
        pS=math.exp(o["lpS"][i]); pP=math.exp(o["lpP"][i]); pSP=math.exp(o["lpSP"][i])
        rows.append(dict(P=P,S=S,N=N,x=math.log(S/s0),n=len(sq),s=sum(r["s_count"] for r in sq),p=sum(r["p_count"] for r in sq),sp=sum(r["sp_count"] for r in sq),
                         eS=len(sq)*720*pS,eP=len(sq)*720*pP,eSP=len(sq)*720*pSP))
def show(lab, rr):
    n=sum(r["n"] for r in rr); 
    if n==0: return
    s=sum(r["s"] for r in rr); p=sum(r["p"] for r in rr); sp=sum(r["sp"] for r in rr)
    eS=sum(r["eS"] for r in rr); eP=sum(r["eP"] for r in rr); eSP=sum(r["eSP"] for r in rr)
    print("%-28s squares %5d  S %5d/%7.1f=%.2f  P %4d/%6.1f=%.2f  SP %3d/%5.1f=%.2f" % (lab,n,s,eS,s/eS,p,eP,p/eP,sp,eSP,sp/max(eSP,1e-9)))
import pickle; pickle.dump(rows, open("trav_rows.pkl","wb"))
show("all", rows)
for lo,hi in [(0,0.05),(0.05,0.1),(0.1,0.15),(0.15,0.2),(0.2,0.3),(0.3,0.5),(0.5,2)]:
    show("x [%.2f,%.2f)"%(lo,hi), [r for r in rows if lo<=r["x"]<hi])
show("N>=3000", [r for r in rows if r["N"] and r["N"]>=3000])
show("N>=12000", [r for r in rows if r["N"] and r["N"]>=12000] + [r for r in rows if r["N"] is None])
print("--- by N")
for lo,hi in [(0,1000),(1000,2000),(2000,3000),(3000,5000),(5000,8000),(8000,12000),(12000,1e9)]:
    show("N [%d,%d)"%(lo,hi), [r for r in rows if r["N"] and lo<=r["N"]<hi])
show("N unknown (sampled)", [r for r in rows if not r["N"]])
