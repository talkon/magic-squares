"""Generate exponent tuples P over the first NPR primes with 6 P^(1/6) <= XMAX and tau >= TMIN."""
import math, sys
from mlib import PRIMES
def gen(xmax, tmin=500, npr=12, monotone=False):
    lmax = 6 * math.log(xmax / 6)
    lp = [math.log(p) for p in PRIMES[:npr]]
    out = []
    def rec(i, cur, lP, t, emax):
        # prune: remaining primes can multiply tau by at most ... (no bound used; just size)
        if i == npr:
            if t >= tmin: out.append(tuple(cur))
            return
        e = 0
        while lP + e * lp[i] <= lmax + 1e-9 and (not monotone or e <= emax):
            cur.append(e)
            rec(i + 1, cur, lP + e * lp[i], t * (e + 1), e if monotone else emax)
            cur.pop(); e += 1
    rec(0, [], 0.0, 1, 10 ** 9)
    return out
if __name__ == '__main__':
    import time
    for xmax in (1000, 3000, 10000):
        for mono in (True, False):
            t0 = time.time(); g = gen(xmax, 500, 12, mono)
            print(xmax, 'monotone' if mono else 'all', len(g), '%.1fs' % (time.time() - t0), flush=True)
