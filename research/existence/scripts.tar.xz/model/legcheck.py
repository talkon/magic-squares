"""Out-of-sample check on the first search's per-P totals (1137 P, 758,949 squares):
predicted squares over each P's searched range, from analytic N(S) (and L(S)), for the scheduler model and the H-model."""
import json, math, sys
import numpy as np
from epop import *
import hmodel as hm
from lmodel import labels
HC = json.load(open(HERE + '/hcoef.json'))['coef']
leg = json.load(open(SP + '/forecast/state/legacy.json'))
LCW = json.load(open(HERE + '/lcal.json'))['cw']
def sq_H(P, S, N, smin):
    xp = np.log(S / 6) - lnP(P) / 6
    Lp = labels(P, S, LCW * np.sqrt(np.maximum(xp, 1e-6)))
    x = np.log(S / smin)
    Lh = hm.Lhat(Lp, N, x)
    lH = hm.logH(N, Lh)
    return np.where((lH > -299) & (N >= 300), np.exp(HC[0] + HC[1] * lH + HC[2] * x + HC[3] * np.log(np.maximum(N, 1))), 0.0)
if __name__ == '__main__':
    rows = []
    for r in leg:
        P = norm(r['P'])
        if len(P) == 0: continue
        S, N, s0 = profile(P)
        hi = r['maxS'] if r['maxS'] < 10 ** 9 else S[-1]
        m = S <= hi
        if m.sum() < 3: continue
        dS = S * np.gradient(XG)
        a = (sq_model(P, S, N, s0) * dS)[m].sum()
        b = (sq_H(P, S, N, s0) * dS)[m].sum()
        rows.append((P, tau(P), s0, hi / s0, r['sols'], a, b, r['maxS'] >= 10 ** 9))
    A = np.array([[t, s0, q, o, a, b, ex] for P, t, s0, q, o, a, b, ex in rows])
    print('legacy P', len(rows), 'obs', A[:, 3].sum(), 'sched model %.0f' % A[:, 4].sum(), 'H-model %.0f' % A[:, 5].sum())
    for nm, col, edges in (('tau', 0, [0, 1000, 1500, 2000, 3000, 4000, 6500, 1e5]), ('S_min', 1, [0, 300, 400, 500, 700, 1000, 1e5]), ('range maxS/Smin', 2, [0, 1.2, 1.5, 2, 3, 1e9])):
        print(' by', nm)
        for lo, hi in zip(edges[:-1], edges[1:]):
            m = (A[:, col] >= lo) & (A[:, col] < hi)
            if m.sum(): print(f'   {lo:7g}-{hi:<7g} P {m.sum():4d} obs {A[m,3].sum():8.0f}  sched {A[m,3].sum()/A[m,4].sum():5.2f}  H {A[m,3].sum()/A[m,5].sum():5.2f}')
    m = A[:, 3] >= 5
    print(' per-P log(obs/pred) sd (P with >=5 squares): sched %.2f, H %.2f' % (np.log(A[m, 3] / A[m, 4]).std(), np.log(A[m, 3] / A[m, 5]).std()))
    json.dump([dict(P=P, tau=t, smin=s0, q=q, obs=o, sched=a, H=b, exh=bool(ex)) for P, t, s0, q, o, a, b, ex in rows], open('legcheck.json', 'w'))
