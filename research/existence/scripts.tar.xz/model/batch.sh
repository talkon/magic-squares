#!/bin/bash
cd /tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/model
for v in nogrowth H samex base nogrowth_cap10k H_cap10k nogrowth_travclamp H_travclamp; do
  python3 runpop.py --xmax 30000 --npr 14 --variant $v > logs_pop_$v.txt 2>&1
done
echo ALLDONE > batch.done
