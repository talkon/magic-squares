import json, sys, glob, collections, math
for f in sys.argv[1:]:
    sums=[]; sq=[]
    for line in open(f):
        try: r=json.loads(line)
        except: continue
        if r.get('type')=='sum': sums.append(r)
        elif r.get('type')=='square': sq.append(r)
    if not sums: continue
    P=sums[0]['P']
    Ss=[r['S'] for r in sums]; Ns=[r['nvecs_raw'] for r in sums]
    nsq=sum(r['squares'] for r in sums); t=sum(r['time']+r['setup_time'] for r in sums)
    print(f.split('/')[-1], P, 'S %d-%d'%(min(Ss),max(Ss)), 'nsums',len(sums),'N %d-%d'%(min(Ns),max(Ns)), 'squares',nsq,'time %.0f'%t,
          'sS',sum(q['s_count'] for q in sq),'sP',sum(q['p_count'] for q in sq),'SP',sum(q['sp_count'] for q in sq))
