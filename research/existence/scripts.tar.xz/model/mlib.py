"""Model evaluation for the existence estimate (vectorized; independent of scheduler.py,
but uses the same fitted coefficients, forecast/state/model_6.json)."""
import json, math, os, glob, subprocess
import numpy as np

SP = '/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad'
HERE = SP + '/existence/model'
M = json.load(open(SP + '/forecast/state/model_6.json'))
PRIMES = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79]
KNOTS = np.log([700., 1300., 2000., 3000.])
CL = {k: tuple(v) for k, v in M['clamp'].items()}
ENUM = '/home/user/magic-squares/bin/enumerate'

def norm(P):
    P = list(P)
    while P and P[-1] == 0: P.pop()
    return tuple(P)

def tau(P):
    t = 1
    for e in P: t *= e + 1
    return t

def pval(P):
    v = 1
    for p, e in zip(PRIMES, P): v *= p ** e
    return v

def lnP(P):
    return sum(e * math.log(p) for p, e in zip(PRIMES, P))

def pfeat(P, clamp=True):
    lt = math.log(tau(P)); k = float(sum(1 for e in P if e)); lp = math.log(PRIMES[len(norm(P)) - 1])
    if clamp:
        lt = min(max(lt, CL['lt'][0]), CL['lt'][1]); k = min(max(k, CL['k'][0]), CL['k'][1])
        lp = min(max(lp, CL['lp'][0]), CL['lp'][1])
    return lt, k, lp

def sq_model(P, S, N, smin, clampN=True, clampP=True, clampx=True):
    """scheduler's expected semi-magic squares per sum (no corrections)"""
    c = M['squares']
    N = np.asarray(N, float); S = np.asarray(S, float)
    lN = np.log(np.maximum(N, 1))
    if clampN: lN = np.clip(lN, *CL['lN'])
    x = np.log(S / smin)
    if clampx: x = np.clip(x, *CL['x'])
    lt, k, lp = pfeat(P, clampP)
    h = [np.maximum(0.0, lN - kn) for kn in KNOTS]
    lin = (c[0] + c[1] * lN + c[2] * h[0] + c[3] * h[1] + c[4] * h[2] + c[5] * h[3] + c[6] * x
           + c[7] * lt + c[8] * k + c[9] * lp + c[10] * k * h[1] + c[11] * k * h[2] + c[12] * k * x)
    return np.where(N >= M['min_n'], np.exp(np.minimum(lin, 30)), 0.0)

def trav(P, S, smin, which, clampx=True, clampP=True):
    c = M['ps'] if which == 's' else M['pp']
    S = np.asarray(S, float)
    x = np.log(S / smin)
    if clampx: x = np.clip(x, *CL['x'])
    lt, k, lp = pfeat(P, clampP)
    return np.minimum(1.0, np.exp(c[0] + c[1] * np.log(S) + c[2] * x + c[3] * lt + c[4] * k + c[5] * lp))

def pmagic(ps, pp, rho):
    return 5400.0 * (rho * ps * pp) ** 2

def sum_time(N):
    """scheduler's CPU-s per sum (current build), power-law beyond fitted range"""
    c = M['time']; lo, hi = M['time_range']
    N = np.asarray(N, float); lN = np.log(np.maximum(N, 1)); lc = np.clip(lN, lo, hi)
    lt = c[0] + c[1] * lc + c[2] * lc * lc
    slope = max(3.0, c[1] + 2 * c[2] * hi)
    lt = lt + np.where(lN > hi, slope * (lN - hi), 0.0)
    return np.exp(lt + M['time_sd'] ** 2 / 2)

def smin_of(P):
    return int(subprocess.run([ENUM, '--print-min-sum'] + [str(e) for e in P], capture_output=True, text=True).stdout.split()[0])

def counts(P, lo, hi, tmpname=None):
    """vector counts (raw) per sum in [lo, hi]"""
    tmp = tmpname or f'{HERE}/tmp_counts_{os.getpid()}.txt'
    subprocess.run(['bash', '-c', f'ulimit -v 3000000; exec {ENUM} --reduce none --counts --min-sum {lo} --max-sum {hi} --file {tmp} ' + ' '.join(map(str, P))],
                   check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    out = {}
    for l in open(tmp):
        a, b = l.split(); out[int(a)] = int(b)
    os.remove(tmp)
    return out

def load_jsonl(paths):
    sums, sqs = [], []
    for f in paths:
        for line in open(f):
            try: r = json.loads(line)
            except Exception: continue
            if r.get('type') == 'sum': sums.append(r)
            elif r.get('type') == 'square': sqs.append(r)
    return sums, sqs
