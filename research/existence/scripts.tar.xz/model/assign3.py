"""As assign.py, but accumulates cumulative E(S <= X) on the X grid for (a) the top monotone P of each S_min class and
(b) all their assignments, so the multiplicity correction is applied at the right X. Writes assign2_<variant>.json."""
import json, math, sys, itertools, argparse
import numpy as np
from epop import *
from variants import VAR
ap = argparse.ArgumentParser()
ap.add_argument('pop'); ap.add_argument('--variant', default='H'); ap.add_argument('--npr', type=int, default=16)
ap.add_argument('--slack', type=float, default=6 * math.log(2.0)); ap.add_argument('--ntop', type=int, default=20)
ap.add_argument('--xmax', type=float, default=30000)
ap.add_argument('--seed', type=int, default=7)
a = ap.parse_args()
o = VAR[a.variant]
d = json.load(open(a.pop)); rows = d['rows']; XGR = np.array(d['XGRID'])
lp = [math.log(p) for p in PRIMES[:a.npr]]
def assignments(P, lmax):
    exps = sorted([e for e in P if e], reverse=True)
    vals = sorted(set(exps), reverse=True); mult = [exps.count(v) for v in vals]
    out = []
    def rec(i, used, cur, lP):
        if i == len(vals):
            t = [0] * a.npr
            for pi, e in cur: t[pi] = e
            out.append(tuple(t)); return
        free = [j for j in range(a.npr) if j not in used]
        for comb in itertools.combinations(free, mult[i]):
            add = vals[i] * sum(lp[j] for j in comb)
            if lP + add > lmax + 1e-9: continue
            rec(i + 1, used | set(comb), cur + [(j, vals[i]) for j in comb], lP + add)
    rec(0, set(), [], 0.0)
    return out
edges = [150, 300, 500, 700, 1000, 1500, 2000, 3000, 5000, 7000, 10000, 15000, 20000, 30000]
out = {'XGRID': XGR.tolist(), 'classes': []}
lPmax = 6 * math.log(a.xmax / 6)
for lo, hi in zip(edges[:-1], edges[1:]):
    cls = [r for r in rows if lo <= r['smin'] < hi]
    if not cls: continue
    # importance sample of multisets, probability proportional to E(sorted P)
    rng = np.random.default_rng(a.seed + lo)
    Ecls = np.array([r['E'] for r in cls]); pr = Ecls / Ecls.sum()
    pick = rng.choice(len(cls), size=a.ntop, replace=True, p=pr)
    top = [cls[i] for i in pick]
    cs = np.zeros(len(XGR)); ca = np.zeros(len(XGR)); nas = 0; shift = 0.0; wsum = 0.0
    for r in top:
        P = tuple(r['P'])
        cs += np.array(r['cX']) / r['E'] * Ecls.sum() / a.ntop       # unbiased estimate of the class's monotone cX
        ca_i = np.zeros(len(XGR)); e_i = 0.0
        for Q in assignments(P, min(r['lP'] + a.slack, lPmax)):
            Q = norm(Q)
            S, N, sq, pm, e, dS, s0 = E_of(Q, o)
            ca_i += np.interp(XGR, S, np.cumsum(e), left=0.0, right=e.sum()); nas += 1
            shift += e.sum() * math.log(s0 / r['smin']) / r['E']; wsum += e.sum() / r['E']
        ca += ca_i / r['E'] * Ecls.sum() / a.ntop
    cX = np.sum([r['cX'] for r in cls], axis=0)
    out['classes'].append(dict(lo=lo, hi=hi, n=len(cls), top_share=0.0,
                               cs=cs.tolist(), ca=ca.tolist(), cX=cX.tolist(), nassign=nas / len(top)))
    print(f'  S_min {lo:5d}-{hi:<5d}: {len(cls)} P; IS estimate of total E incl. assignments / monotone {ca[-1]/cX[-1]:6.2f} (check: IS monotone / exact {cs[-1]/cX[-1]:.2f}); E-weighted S_min shift x{math.exp(shift/max(wsum,1e-300)):.2f}; {nas/len(top):.0f} assignments each', flush=True)
json.dump(out, open(f'assign2_{a.variant}.json', 'w'))
# corrected N_magic(X): each class's cX scaled by the X-dependent ratio from its top P (ratio applied where cs > 0)
tot_m = np.zeros(len(XGR)); tot_c = np.zeros(len(XGR))
for c in out['classes']:
    cX = np.array(c['cX']); cs = np.array(c['cs']); ca = np.array(c['ca'])
    # ratio of cumulative curves; where cs ~ 0 use the final ratio applied to a shifted curve
    tot_m += cX; tot_c += ca
for X in (1000, 2000, 3000, 4000, 5000, 7000, 10000, 20000, 30000):
    print(f'   X {X:6d}: monotone {np.interp(X, XGR, tot_m):.4g}  with assignments {np.interp(X, XGR, tot_c):.4g}  (x{np.interp(X, XGR, tot_c)/max(np.interp(X, XGR, tot_m),1e-300):.1f})')
