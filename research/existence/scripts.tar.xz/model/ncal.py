import json, math, random
import numpy as np
from nmodel import *
from mlib import lnP, tau, SP
pin = json.load(open(SP + '/verify-forecast/region-pool/state/pinfo_6.json'))
ext = json.load(open(SP + '/verify-forecast/region-pool/ext_counts.json'))
rows = []
random.seed(1)
keys = [k for k in pin if pin[k].get('smin')]
print(len(keys), 'P in pinfo')
for k in random.sample(keys, min(3000, len(keys))):
    P = tuple(int(t) for t in k[2:].split('_')); d = pin[k]; smin = d['smin']
    c = {int(s): n for s, n in d['counts'].items()}
    if k[2:] in ext: c.update({int(s): n for s, n in ext[k[2:]]['counts'].items()})
    top = max(c) if c else smin
    for x in (0.05, 0.1, 0.2, 0.3, 0.5, 0.7, 0.9):
        s = smin * math.exp(x)
        if s * 1.03 > top: break
        Ss = np.arange(int(s * 0.97), int(s * 1.03) + 1)
        nobs = sum(c.get(int(t), 0) for t in Ss)
        npred = n_of_S(P, Ss).sum()
        if npred > 50:
            rows.append((P, x, nobs, npred, tau(P), sum(1 for e in P if e), s2_of(P), len(P)))
print(len(rows), 'rows')
r = np.array([[x, math.log(max(no, 0.5) / npd), t, kk, s2, lp, npd] for P, x, no, npd, t, kk, s2, lp in rows])
x, lr, t, kk, s2, lp, npd = r.T
print('overall median ratio %.3f, sd log %.3f' % (np.exp(np.median(lr)), lr.std()))
for nm, by, edges in (('x', x, [0, .07, .15, .25, .4, .6, .8, 1]), ('tau', t, [0, 1000, 2000, 4000, 8000, 16000, 1e6]), ('k', kk, [3.5, 4.5, 5.5, 6.5, 7.5, 9]), ('s2', s2, [0, 6, 8, 10, 12, 16, 30])):
    print('by', nm)
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (by >= lo) & (by < hi)
        if m.sum(): print(f'   {lo:7g}-{hi:<7g} n {m.sum():5d} median ratio {np.exp(np.median(lr[m])):.3f}  sd {lr[m].std():.3f}')
# linear fit of log ratio
X = np.column_stack([np.ones(len(x)), x, np.log(t), kk, np.log(s2)])
b, *_ = np.linalg.lstsq(X, lr, rcond=None)
res = lr - X @ b
print('fit log ratio = %s ; resid sd %.3f' % (np.round(b, 3), res.std()))
json.dump({'coef': list(b), 'cols': ['1', 'x', 'ln tau', 'k', 'ln s2'], 'resid_sd': float(res.std())}, open('ncal.json', 'w'))
