import json, math, numpy as np
from epop import *
ext = json.load(open(SP + '/verify-forecast/region-pool/ext_counts.json'))
res = []
for o_name, o in (('base', DEF), ('nogrowth', dict(DEF, growth=None))):
    rs = []
    for k, v in ext.items():
        P = tuple(int(t) for t in k.split('_')); s0 = v['smin']
        hi = min(v['to'], int(s0 * math.exp(1.2)))
        Sx = np.arange(s0, hi + 1); c = {int(a): b for a, b in v['counts'].items()}
        Nx = np.array([c.get(int(s), 0) for s in Sx], float)
        sq2, pm2 = per_sum(P, Sx.astype(float), Nx, s0, o)
        S, N, sq, pm, e, dS, sa = E_of(P, o, smin=s0)
        m = S <= hi
        Ea, En = (sq2 * pm2).sum(), e[m].sum()
        # N ratio at x 0.1-0.5
        mm = (Sx >= s0 * 1.1) & (Sx <= s0 * 1.6)
        nr = Nx[mm].sum() / np.interp(Sx[mm], S, N).sum() if mm.sum() else np.nan
        rs.append((k, tau(P), Ea, En, nr, (sq2).sum(), (sq * dS)[m].sum()))
    a = np.array([[r[1], r[2], r[3], r[4], r[5], r[6]] for r in rs])
    ok = a[:, 2] > 0
    lr = np.log(a[ok, 1] / a[ok, 2])
    print(o_name, 'n', ok.sum(), 'E_actual/E_analytic: median %.2f, mean-of-ratio %.2f, ratio-of-sums %.2f, sd log %.2f;  N ratio median %.3f;  squares ratio-of-sums %.2f' % (
        np.exp(np.median(lr)), np.mean(a[ok, 1] / a[ok, 2]), a[ok, 1].sum() / a[ok, 2].sum(), lr.std(), np.nanmedian(a[:, 3]), a[:, 4].sum() / a[:, 5].sum()))
    for lo, hi in ((0, 2500), (2500, 4000), (4000, 6500), (6500, 1e6)):
        m = ok & (a[:, 0] >= lo) & (a[:, 0] < hi)
        if m.sum(): print('   tau %5d-%-7d n %3d ratio-of-sums E %.2f  squares %.2f' % (lo, hi, m.sum(), a[m, 1].sum() / a[m, 2].sum(), a[m, 4].sum() / a[m, 5].sum()))
