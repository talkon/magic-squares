"""Analytic vector-count model: N(S) for any P.
Ordered 6-tuples of divisors with product P: per prime a uniform composition of e_i into 6 parts.
Log-sizes u_j: Gaussian with var s2 = sum (ln p)^2 5e(e+6)/252, corr -1/5. x' = ln(S / (6 P^(1/6))) = ln mean e^{v_j}.
F(x'; s2) = Pr(x'(v) <= x') by Monte Carlo, tabulated; N(S) = V/720 * dF/dS, V = prod C(e+5,5)."""
import math, os
import numpy as np
from mlib import PRIMES, norm
TAB = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'Ftab.npz')
XG = np.linspace(0, 2.0, 401)
S2G = np.exp(np.linspace(math.log(0.5), math.log(400), 60))
def build(nmc=4_000_000, seed=1):
    rng = np.random.default_rng(seed)
    # isotropic 5-dim gaussian in the sum-zero subspace of R^6, unit variance per coordinate of u (corr -1/5)
    z = rng.standard_normal((nmc, 6)); z -= z.mean(1, keepdims=True)   # var per coord 5/6, cov -1/6 -> scale by sqrt(6/5)
    z *= math.sqrt(6 / 5)
    F = np.zeros((len(S2G), len(XG)))
    for i, s2 in enumerate(S2G):
        v = z * math.sqrt(s2)
        m = v.max(1, keepdims=True)
        xp = (m[:, 0] + np.log(np.exp(v - m).mean(1)))
        xs = np.sort(xp)
        F[i] = np.searchsorted(xs, XG, side='right') / nmc
    # small-x analytic tail (MC is noisy where F < ~1e-5): F ~ (5x/s2)^2.5/Gamma(3.5) * (1 + a x) -> use exact small-x form below 
    np.savez(TAB, F=F, XG=XG, S2G=S2G)
def load():
    if not os.path.exists(TAB): build()
    d = np.load(TAB); return d['F'], d['XG'], d['S2G']
F_, XG_, S2G_ = None, None, None
def s2_of(P):
    return sum((math.log(p) ** 2) * 5 * e * (e + 6) / 252 for p, e in zip(PRIMES, P))
def V_of(P):
    v = 1
    for e in P: v *= math.comb(e + 5, 5)
    return v
def cdf(xp, s2):
    """F(x'; s2), with the small-x asymptotic form where the MC is sparse"""
    global F_, XG_, S2G_
    if F_ is None: F_, XG_, S2G_ = load()
    xp = np.asarray(xp, float)
    ls = math.log(s2); j = np.searchsorted(np.log(S2G_), ls); j = min(max(j, 1), len(S2G_) - 1)
    w = (ls - math.log(S2G_[j - 1])) / (math.log(S2G_[j]) - math.log(S2G_[j - 1])); w = min(max(w, 0), 1)
    Fr = (1 - w) * F_[j - 1] + w * F_[j]
    Fi = np.interp(np.clip(xp, 0, XG_[-1]), XG_, Fr)
    asym = (5 * np.maximum(xp, 0) / s2) ** 2.5 / math.gamma(3.5)
    # use the asymptotic form where it is below 2e-4 (MC rel. error ~ 1/sqrt(4e6*2e-4) = 3.5%), matched multiplicatively
    return np.where(asym < 2e-4, asym * _match(s2), Fi)
_mcache = {}
def _match(s2):
    """ratio MC/asymptotic at F ~ 2e-4..1e-3 to splice continuously"""
    key = round(math.log(s2), 3)
    if key in _mcache: return _mcache[key]
    global F_, XG_, S2G_
    if F_ is None: F_, XG_, S2G_ = load()
    xs = np.linspace(1e-4, 0.5, 2000)
    asym = (5 * xs / s2) ** 2.5 / math.gamma(3.5)
    ls = math.log(s2); j = np.searchsorted(np.log(S2G_), ls); j = min(max(j, 1), len(S2G_) - 1)
    w = (ls - math.log(S2G_[j - 1])) / (math.log(S2G_[j]) - math.log(S2G_[j - 1])); w = min(max(w, 0), 1)
    Fi = np.interp(xs, XG_, (1 - w) * F_[j - 1] + w * F_[j])
    m = (asym > 2e-4) & (asym < 1e-3)
    r = float(np.median(Fi[m] / asym[m])) if m.sum() else 1.0
    _mcache[key] = r
    return r
def n_of_S(P, S, corr=1.0):
    """predicted vectors (unordered, distinct) at each integer sum S"""
    P = norm(P)
    lP = sum(e * math.log(p) for p, e in zip(PRIMES, P))
    S = np.asarray(S, float)
    s2 = s2_of(P); V = V_of(P) / 720.0
    xp_hi = np.log((S + 0.5) / 6) - lP / 6; xp_lo = np.log((S - 0.5) / 6) - lP / 6
    return corr * V * (cdf(xp_hi, s2) - cdf(xp_lo, s2))
if __name__ == '__main__':
    build()
    print('built', TAB)
