"""Expected magic squares among the semi-magic squares already found (legacy totals + our squares)."""
import json, glob, math
import numpy as np
from epop import *
from legcheck import sq_H
leg = json.load(open(SP + '/forecast/state/legacy.json'))
pin = json.load(open(SP + '/forecast/state/pinfo_6.json'))
for cp in (False, True):
    E = Eh = 0.0; n = 0
    for r in leg:
        P = norm(r['P'])
        if not P or r['sols'] == 0: continue
        S, N, s0 = profile(P)
        hi = r['maxS'] if r['maxS'] < 10 ** 9 else S[-1]
        m = S <= hi
        dS = S * np.gradient(XG)
        pm = pmagic(trav(P, S, s0, 's', clampP=cp), trav(P, S, s0, 'p', clampP=cp), 2.6)
        for model, acc in ((sq_model(P, S, N, s0), 'E'), (sq_H(P, S, N, s0), 'Eh')):
            w = (model * dS)[m]
            if w.sum() <= 0: continue
            val = r['sols'] * (w * pm[m]).sum() / w.sum()
            if acc == 'E': E += val
            else: Eh += val
        n += r['sols']
    # our squares (units + verifier + mine), deduplicated
    paths = glob.glob(SP + '/forecast/state/units/*.jsonl') + glob.glob(SP + '/verify-forecast/*/ms*.jsonl') + glob.glob(SP + '/verify-forecast/*/hx*.jsonl') + glob.glob(HERE + '/runs/*.jsonl')
    _, sqs = load_jsonl(paths); seen = set(); Eo = 0.0; no = 0
    legP = {norm(r['P']) for r in leg if r['maxS'] >= 10 ** 9}
    for q in sqs:
        P = norm(q['P']); key = (P, q['S'], q.get('hash'))
        if key in seen or P in legP: continue
        seen.add(key); k_ = '6:' + '_'.join(map(str, P)); s0 = pin[k_]['smin'] if k_ in pin else smin_of(P)
        Eo += float(pmagic(trav(P, q['S'], s0, 's', clampP=cp), trav(P, q['S'], s0, 'p', clampP=cp), 2.6)); no += 1
    print('trav clamped' if cp else 'trav unclamped', ': legacy %d squares -> E_magic %.4f (sched S-shape) / %.4f (H S-shape); our %d squares -> %.4f; per square %.2g / %.2g' % (n, E, Eh, no, Eo, E / n, Eo / no))
