import json, math, numpy as np
d = json.load(open('assign2_H.json')); XG = np.array(d['XGRID'])
tm = np.sum([c['cX'] for c in d['classes']], axis=0); tc = np.sum([c['ca'] for c in d['classes']], axis=0)
ratio = np.where(tm > 0, tc / np.maximum(tm, 1e-300), 1.0)
def load(v):
    p = json.load(open(f'pop_{v}_30000.json')); return np.sum([r['cX'] for r in p['rows']], axis=0)
curves = {'H (all P)': tc, 'H (monotone P)': tm, 'base_cal (all P, H multiplicity)': load('base_cal') * ratio, 'base_cal (monotone)': load('base_cal'),
          'H_cap10k (monotone)': load('H_cap10k'), 'nogrowth (monotone)': load('nogrowth')}
def xat(c, t):
    i = np.searchsorted(c, t)
    if i >= len(XG): return float('inf')
    if i == 0: return XG[0]
    a, b = math.log(max(c[i-1], 1e-300)), math.log(c[i]); w = (math.log(t) - a) / (b - a)
    return math.exp(math.log(XG[i-1]) + w * (math.log(XG[i]) - math.log(XG[i-1])))
print('| curve | N(1000) | N(2000) | N(3000) | N(5000) | N(1e4) | N(3e4) | X: N=0.105 (10%) | N=ln2 (median of smallest S) | N=1 | N=2.30 (90%) | slope at X=2000 | at 5000 | at 2e4 |')
for k, c in curves.items():
    sl = lambda X: math.log(np.interp(X * 1.2, XG, c) / np.interp(X / 1.2, XG, c)) / math.log(1.44)
    print(f'| {k} | ' + ' | '.join(f'{np.interp(x, XG, c):.2g}' for x in (1000, 2000, 3000, 5000, 1e4, 3e4)) + ' | ' + ' | '.join(f'{xat(c, t):.0f}' for t in (0.105, math.log(2), 1.0, 2.303)) + f' | {sl(2000):.1f} | {sl(5000):.1f} | {sl(2e4):.1f} |')
print('\nH (all P) with a multiplicative model error on E:')
for f in (0.1, 1/3, 1, 3, 10):
    c = tc * f
    print(f'  x{f:.2g}: smallest-S median {xat(c, math.log(2)):.0f}, 10-90% {xat(c, 0.105):.0f}-{xat(c, 2.303):.0f}, N=1 at {xat(c, 1):.0f}')
print('multiplicity ratio all/monotone at X=', ' '.join(f'{x}:{np.interp(x, XG, ratio):.1f}' for x in (1000, 2000, 3000, 5000, 10000, 30000)))
json.dump({'XGRID': XG.tolist(), 'H_all': tc.tolist(), 'H_mono': tm.tolist(), 'ratio': ratio.tolist()}, open('final_curves.json', 'w'))
