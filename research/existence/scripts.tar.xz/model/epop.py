"""Per-P expected magic squares E(P, S) from the scheduler model + corrections, with analytic N(S)."""
import json, math
import numpy as np
from mlib import *
import nmodel as nm
NCAL = json.load(open(HERE + '/ncal.json'))['coef']
XG = np.arange(0.0, 1.2001, 0.004)            # x = ln(S/S_min) grid
def ncorr(P, x):
    b = NCAL; t = tau(P); k = sum(1 for e in P if e); s2 = nm.s2_of(P)
    lr = b[0] + b[1] * np.asarray(x) + b[2] * math.log(t) + b[3] * k + b[4] * math.log(s2)
    return np.exp(np.minimum(lr, 0.0))          # distinctness etc.: never above 1
def smin_analytic(P):
    """S where the expected cumulative (corrected) count reaches 1"""
    lP = lnP(P); s2 = nm.s2_of(P); V = nm.V_of(P) / 720.0
    xs = np.exp(np.linspace(math.log(1e-5), math.log(0.5), 400))
    F = nm.cdf(xs, s2) * V * ncorr(P, 0.0)
    i = np.searchsorted(F, 1.0)
    xp = xs[min(i, len(xs) - 1)]
    return 6 * math.exp(lP / 6 + xp)
def profile(P, smin=None):
    """S grid, N per integer sum on the grid"""
    P = norm(P)
    if smin is None: smin = smin_analytic(P)
    lP = lnP(P); s2 = nm.s2_of(P); V = nm.V_of(P) / 720.0
    S = smin * np.exp(XG)
    xp = np.log(S / 6) - lP / 6
    h = 1e-3
    dF = (nm.cdf(xp + h, s2) - nm.cdf(np.maximum(xp - h, 0), s2)) / (xp + h - np.maximum(xp - h, 0))   # dF/dx'
    N = np.maximum(V * dF / S * ncorr(P, XG), 0.0)       # per integer S (dx = dS/S)
    return S, N, smin
DEF = dict(fresh=0.35, rho=2.6, NA=4000.0, g=2.25, growth='anchorS', trav_clampP=False, sq_clampP=True, ncap=None)
def per_sum(P, S, N, smin, o=DEF):
    """squares, p_magic per sum on the grid"""
    if o.get('sqmodel') == 'H':          # structural model (hmodel.py), its own calibration factor hfac
        from legcheck import sq_H
        sq = sq_H(P, S, N, smin) * o.get('hfac', 1.0)
        cp = o.get('trav_clampP', True)
        pm = pmagic(trav(P, S, smin, 's', clampP=cp), trav(P, S, smin, 'p', clampP=cp), o['rho'])
        if o.get('ncap'): sq = np.where(N > o['ncap'], 0.0, sq)
        return sq, pm
    sq = sq_model(P, S, N, smin, clampP=o.get('sq_clampP', True))
    if o.get('growth') and o['g'] is not None:
        NA = o['NA']
        if o['growth'] == 'anchorS':     # region verifier: anchor where N first reaches NA (along S), grow as N^g beyond
            idx = np.nonzero(N >= NA)[0]
            if len(idx):
                ia = idx[0]
                if N[0] >= NA:   # N above NA already at S_min: anchor at the model's value at (NA, x of first point)
                    sqa = float(sq_model(P, S[0], NA, smin))
                else:
                    sqa = float(sq[ia])
                alt = sqa * (N / NA) ** o['g'] * o.get('bigN_fac', o['fresh']) / o['fresh']
                beyond = np.arange(len(S)) >= ia
                sq = np.where(beyond, np.maximum(sq, alt), sq)
        elif o['growth'] == 'samex':    # anchor at the same x: model(NA, x) * (N/NA)^g
            alt = sq_model(P, S, np.full_like(N, NA), smin) * (N / NA) ** o['g']
            sq = np.where(N > NA, np.maximum(sq, alt), sq)
    sq = sq * o['fresh']
    cp = o.get('trav_clampP', True)
    pm = pmagic(trav(P, S, smin, 's', clampP=cp), trav(P, S, smin, 'p', clampP=cp), o['rho'])
    if o.get('ncap'): sq = np.where(N > o['ncap'], 0.0, sq)
    return sq, pm
def E_of(P, o=DEF, smin=None, xmax=None):
    S, N, s0 = profile(P, smin)
    sq, pm = per_sum(P, S, N, s0, o)
    dS = S * np.gradient(XG)          # integer sums per grid cell
    e = sq * pm * dS
    return S, N, sq, pm, e, dS, s0
