"""Test a structural form for squares per sum: squares ~ C * D(L) * N^b * (rho p_S p_P)^c
(rows-then-columns heuristic gives b = 6, c = 5) against the scheduler model."""
import json, glob, math, sys
import numpy as np
from mlib import *
pin = json.load(open(SP + '/forecast/state/pinfo_6.json'))
SMIN = {}
def smin(P):
    P = norm(P)
    if P not in SMIN:
        k = '6:' + '_'.join(map(str, P))
        SMIN[P] = pin[k]['smin'] if k in pin and pin[k]['smin'] else smin_of(P)
    return SMIN[P]
paths = (glob.glob(SP + '/forecast/state/units/*.jsonl') + glob.glob(SP + '/verify-forecast/*/ms*.jsonl')
         + glob.glob(SP + '/verify-forecast/*/hx*.jsonl') + glob.glob(HERE + '/runs/*.jsonl'))
sums, _ = load_jsonl(paths)
seen = set(); R = []
for r in sums:
    P = norm(r['P']); key = (P, r['S'])
    if key in seen or r.get('truncated') or r['nvecs_raw'] < 300: continue
    seen.add(key)
    R.append((P, r['S'], r['nvecs_raw'], r['labels'], smin(P), r['squares']))
print(len(R), 'sums with N>=300', sum(r[5] for r in R), 'squares')
y = np.array([r[5] for r in R], float)
lN = np.log([r[2] for r in R]); L = np.array([r[3] for r in R], float)
x = np.array([math.log(r[1] / r[4]) for r in R])
lps = np.log([float(trav(r[0], r[1], r[4], 's')) for r in R]); lpp = np.log([float(trav(r[0], r[1], r[4], 'p')) for r in R])
lt = np.array([math.log(tau(r[0])) for r in R]); k = np.array([sum(1 for e in r[0] if e) for r in R], float)
msq = np.array([float(sq_model(r[0], r[1], r[2], r[4])) for r in R])
def pois(X, y, off=None, iters=100):
    X = np.column_stack([np.ones(len(y))] + list(X)); off = np.zeros(len(y)) if off is None else off
    b = np.zeros(X.shape[1]); b[0] = math.log(max(y.mean(), 1e-9))
    for _ in range(iters):
        eta = X @ b + off; mu = np.exp(np.minimum(eta, 50))
        W = mu; z = eta - off + (y - mu) / np.maximum(mu, 1e-300)
        A = X.T @ (W[:, None] * X) + 1e-6 * np.eye(X.shape[1]); bn = np.linalg.solve(A, X.T @ (W * z))
        if np.max(np.abs(bn - b)) < 1e-9: b = bn; break
        b = bn
    mu = np.exp(X @ b + off)
    dev = 2 * np.sum(np.where(y > 0, y * np.log(np.maximum(y, 1e-300) / mu), 0) - (y - mu))
    return b, dev, mu
lp2 = lps + lpp
def report(name, b, dev, mu):
    print(f'{name:40s} dev {dev:9.1f}  coef ' + ' '.join(f'{v:7.3f}' for v in b))
# scheduler model with a free scale
b, dev, mu = pois([], y, np.log(np.maximum(msq, 1e-300))); report('scheduler model * c', b, dev, mu)
b, dev, mu = pois([lN, lp2], y); report('a + b lN + c log(ps pp)', b, dev, mu)
b, dev, mu = pois([lN, lp2, 1 / L], y); report('... + d/L', b, dev, mu)
b, dev, mu = pois([lN, lp2, np.log(L)], y); report('... + d log L', b, dev, mu)
b, dev, mu = pois([], y, 6 * lN + 5 * (lp2 + math.log(2.15))); report('fixed b=6 c=5 (free C)', b, dev, mu)
b, dev, mu = pois([np.log(L)], y, 6 * lN + 5 * (lp2 + math.log(2.15))); report('fixed b=6 c=5 + d log L', b, dev, mu)
b, dev, mu = pois([lN, lps, lpp, np.log(L), x, lt, k], y); report('free: lN lps lpp logL x lt k', b, dev, mu)
b0, dev0, mu0 = pois([lN, lp2, np.log(L)], y)
np.save('struct_rows.npy', np.array([[r[2], r[3], r[1], r[4], tau(r[0]), r[5]] for r in R], float))
# residuals by N and x
for nm, by, edges in (('N', np.exp(lN), [300, 700, 1000, 1500, 2000, 3000, 4000, 6000, 9000]), ('x', x, [0, .1, .2, .3, .4, .5, .6, .8, 1, 1.3])):
    print('obs/pred by', nm, '(struct a+b lN+c lp2+d logL | scheduler*1)')
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (by >= lo) & (by < hi)
        if m.sum(): print(f'   {lo:6g}-{hi:<6g} n {m.sum():6d} obs {y[m].sum():6.0f}  struct {y[m].sum()/mu0[m].sum():6.2f}  sched {y[m].sum()/msq[m].sum():6.2f}')

# random 6-uniform hypergraph heuristic: squares ~ (L)_36 / (2*720^2) * (N / C(L,6))^12
from math import lgamma
Nn = np.exp(lN)
lH = np.array([lgamma(l + 1) - lgamma(l - 35) - math.log(2 * 720 ** 2) + 12 * (math.log(n) - (lgamma(l + 1) - lgamma(l - 5) - lgamma(7))) if l > 36 else -300 for n, l in zip(Nn, L)])
ok = lH > -299
b, dev, mu = pois([lH[ok]], y[ok]); report('a + b*log H (hypergraph)', b, dev, mu)
b, dev, mu = pois([], y[ok], lH[ok]); report('H * C', b, dev, mu)
b, dev, mu = pois([lH[ok], x[ok]], y[ok]); report('a + b log H + c x', b, dev, mu)
bb, dev, muH = pois([lH[ok], x[ok], lN[ok]], y[ok]); report('a + b log H + c x + d lN', bb, dev, muH)
for nm, by, edges in (('N', Nn[ok], [300, 700, 1000, 1500, 2000, 3000, 4000, 6000, 9000]), ('x', x[ok], [0, .1, .2, .3, .4, .5, .6, .8, 1, 1.3])):
    print('obs/pred by', nm, '(a+b logH+c x+d lN)')
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (by >= lo) & (by < hi)
        if m.sum(): print(f'   {lo:6g}-{hi:<6g} n {m.sum():6d} obs {y[ok][m].sum():6.0f}  pred {muH[m].sum():8.1f} ratio {y[ok][m].sum()/muH[m].sum():6.2f}')
big = Nn[ok] > 3000
print('big-N sums: obs', y[ok][big], 'pred', np.round(muH[big], 1))

print('\n== row-column heuristic: sq = C * 0.5*720^4 * D(L) * N^6 * (p_S p_P)^5, D = prod_j (1-6j/L)^6')
D = np.array([np.prod([(1 - 6 * j / l) ** 6 for j in range(1, 6)]) if l > 31 else 1e-30 for l in L])
lRC = math.log(0.5 * 720 ** 4) + np.log(D) + 6 * lN + 5 * lp2
b, dev, muRC = pois([], y, lRC); report('RC * C (C=exp coef)', b, dev, muRC)
b, dev, muRC2 = pois([lRC], y); report('a + b*log RC', b, dev, muRC2)
b, dev, muRC3 = pois([lRC, x], y); report('a + b*log RC + c x', b, dev, muRC3)
for nm, by, edges in (('N', Nn, [300, 700, 1000, 1500, 2000, 3000, 4000, 6000, 9000]), ('x', x, [0, .1, .2, .3, .4, .5, .6, .8, 1, 1.3]), ('tau', np.exp(lt), [0, 1500, 2500, 4000, 6500, 1e5])):
    print('obs/pred by', nm, '(RC*C | a+b logRC)')
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (by >= lo) & (by < hi)
        if m.sum(): print(f'   {lo:6g}-{hi:<6g} n {m.sum():6d} obs {y[m].sum():6.0f}  RC*C {y[m].sum()/muRC[m].sum():6.2f}  a+b {y[m].sum()/muRC2[m].sum():6.2f}')
print('big-N sums: obs', y[big if len(big)==len(y) else Nn>3000], 'RC*C', np.round(muRC[Nn > 3000], 1))
