import json, sys, math, numpy as np
d = json.load(open(sys.argv[1])); rows = d['rows']; XG = np.array(d['XGRID'])
X = float(sys.argv[2]) if len(sys.argv) > 2 else XG[-1]
E = np.array([np.interp(X, XG, r['cX']) for r in rows]); tot = E.sum()
print(sys.argv[1], 'X<=%g: total %.4g over %d P' % (X, tot, len(rows)))
def br(name, vals, edges, fmt='%g'):
    vals = np.array(vals); s = []
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (vals >= lo) & (vals < hi); s.append(f'{fmt % lo}-{fmt % hi}: {E[m].sum() / tot:.3f} ({m.sum()})')
    print(f'  by {name}: ' + ', '.join(s))
br('tau', [r['tau'] for r in rows], [0, 1500, 3000, 6500, 15000, 30000, 1e5, 1e9])
br('S_min', [r['smin'] for r in rows], [0, 500, 1000, 1500, 2000, 3000, 5000, 1e5])
br('k', [r['k'] for r in rows], [1, 4, 5, 6, 7, 8, 13])
br('largest prime idx', [r['np'] for r in rows], [1, 5, 6, 7, 8, 9, 10, 13])
br('E-weighted x', [r['xbar'] for r in rows], [0, .1, .2, .3, .4, .6, .8, 1.3])
br('E-weighted N', [math.exp(r['lNbar']) for r in rows], [0, 1000, 2000, 4000, 8000, 2e4, 1e5, 1e6, 1e12])
top = sorted(range(len(rows)), key=lambda i: -E[i])[:12]
for i in top:
    r = rows[i]; print('   ', '_'.join(map(str, r['P'])).ljust(24), 'tau', r['tau'], 'smin %.0f' % r['smin'], 'E %.3g' % E[i], 'xbar %.2f Nbar %.0f Npk %.0f' % (r['xbar'], math.exp(r['lNbar']), r['Npk']), 'T50 %.3g h' % (r['T50'] / 3600))
