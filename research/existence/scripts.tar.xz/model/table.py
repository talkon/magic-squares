import json, sys, math, os
import numpy as np
V = sys.argv[1:] or ['nogrowth', 'nogrowth_cap10k', 'samex', 'base', 'base_cal', 'H_cap10k', 'H', 'nogrowth_travclamp', 'H_travclamp']
Xs = [500, 1000, 2000, 3000, 4000, 5000, 7000, 10000, 20000, 30000]
print('| variant | ' + ' | '.join(f'X={x:g}' for x in Xs) + ' | X(N=0.1) | X(N=ln2) | X(N=1) |')
print('|---|' + '---:|' * (len(Xs) + 3))
for v in V:
    f = f'pop_{v}_30000.json'
    if not os.path.exists(f): continue
    d = json.load(open(f)); XG = np.array(d['XGRID']); cX = np.sum([r['cX'] for r in d['rows']], axis=0)
    def xat(t):
        i = np.searchsorted(cX, t)
        if i >= len(XG): return '>3e4'
        if i == 0: return f'{XG[0]:.0f}'
        # log interpolation
        a, b = math.log(max(cX[i-1], 1e-300)), math.log(cX[i]); w = (math.log(t) - a) / (b - a)
        return f'{math.exp(math.log(XG[i-1]) + w * (math.log(XG[i]) - math.log(XG[i-1]))):.0f}'
    print(f'| {v} | ' + ' | '.join(f'{np.interp(x, XG, cX):.2g}' for x in Xs) + f' | {xat(0.1)} | {xat(math.log(2))} | {xat(1.0)} |')
