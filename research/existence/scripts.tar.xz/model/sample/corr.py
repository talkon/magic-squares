"""Run a model-dir script (runpop.py / frontier.py / sampletab-like) with an extra H variant whose calibration
factor depends on N: hf(N) = 0.8 for N < 3000, A (N/1e4)^B for N >= 3000 (fit to the large-N sums, bigN.py).
usage: corr.py A B script.py args...   (registers variant 'H_corr')"""
import sys, runpy, math
MD = '/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/model'
sys.path.insert(0, MD)
import numpy as np
import epop, variants
A, B = float(sys.argv[1]), float(sys.argv[2])
orig = epop.per_sum
def hf(N):
    N = np.asarray(N, float)
    return np.where(N < 3000, 0.8, A * (np.maximum(N, 1) / 1e4) ** B)
def per_sum2(P, S, N, smin, o=epop.DEF):
    if o.get('hcorr'):
        o2 = dict(o); o2['hfac'] = 1.0; o2.pop('hcorr')
        sq, pm = orig(P, S, N, smin, o2)
        return sq * hf(N), pm
    return orig(P, S, N, smin, o)
epop.per_sum = per_sum2
import os
variants.VAR['H_corr'] = dict(epop.DEF, sqmodel='H', hcorr=True)
if os.environ.get('NCAP'): variants.VAR['H_corr']['ncap'] = float(os.environ['NCAP'])
script = sys.argv[3]
sys.argv = [script] + sys.argv[4:]
runpy.run_path(MD + '/' + script if not script.startswith('/') else script, run_name='__main__')
