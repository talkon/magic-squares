#!/bin/bash
cd /tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/model/sample
python3 corr.py 0.64 -0.27 runpop.py --xmax 30000 --npr 14 --variant H_corr --out pop_Hc_mid_30000.json > logs_Hc_mid.txt 2>&1
python3 corr.py 0.54 -0.62 runpop.py --xmax 30000 --npr 14 --variant H_corr --out pop_Hc_low_30000.json > logs_Hc_low.txt 2>&1
python3 corr.py 0.76 0.08 runpop.py --xmax 30000 --npr 14 --variant H_corr --out pop_Hc_high_30000.json > logs_Hc_high.txt 2>&1
NCAP=32000 python3 corr.py 0.64 -0.27 runpop.py --xmax 30000 --npr 14 --variant H_corr --out pop_Hc_cap32k_30000.json > logs_Hc_cap32k.txt 2>&1
python3 corr.py 0.64 -0.27 assign3.py pop_Hc_mid_30000.json --variant H_corr --ntop 25 > assign3_Hc_mid.txt 2>&1
echo done > batchc.done
