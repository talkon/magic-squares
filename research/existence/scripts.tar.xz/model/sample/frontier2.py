"""Cost frontier: all (P, S) cells of the population sorted by expected magic squares per CPU-second
(any order of sums allowed). Time per sum: scheduler model (current build) up to N = 4000, then
t(4000) (N/4000)^a (a = 3.5 measured at N 4-8k; 5.5 = scheduler's extrapolation); floor 1 s per expected semi-magic square."""
import json, sys, math, argparse
import numpy as np
from epop import *
from variants import VAR
ap = argparse.ArgumentParser()
ap.add_argument('pop'); ap.add_argument('--variant', default='base'); ap.add_argument('--a', type=float, default=3.5)
ap.add_argument("--xmax", type=float, default=1e9); ap.add_argument("--t4000", type=float, default=0); ap.add_argument("--a2", type=float, default=0); ap.add_argument("--n2", type=float, default=2e4)
a = ap.parse_args()
o = VAR[a.variant]
rows = json.load(open(a.pop))['rows']
t4000 = a.t4000 or float(sum_time(4000.0))
def tsum(N, sq):
    t = np.where(N <= 4000, sum_time(N), t4000 * (np.maximum(N, 1) / 4000.0) ** a.a)
    if a.a2:   # steeper beyond n2 (measured local slope 5.2 at N 15-32k)
        t = np.where(N > a.n2, t4000 * (a.n2 / 4000.0) ** a.a * (np.maximum(N, 1) / a.n2) ** a.a2, t)
    return np.maximum(t, 1.0 * sq)
B = np.linspace(-30, 0, 601)   # log10 density bins (magic per CPU-s)
acc = np.zeros((len(B) + 1, 7))  # sum e, sum t, e*lnN, e*x, e*ln tau, e*ln smin, e*S
for r in rows:
    P = tuple(r['P'])
    if r['smin'] > a.xmax: continue
    S, N, sq, pm, e, dS, s0 = E_of(P, o, smin=r['smin'])
    m = (e > 0) & (S <= a.xmax)
    if not m.any(): continue
    t = tsum(N, sq) * dS
    dens = np.log10(np.maximum(e[m] / t[m], 1e-300))
    idx = np.searchsorted(B, dens)
    for col, val in enumerate((e[m], t[m], e[m] * np.log(np.maximum(N[m], 1)), e[m] * XG[m], e[m] * math.log(r['tau']), e[m] * math.log(r['smin']), e[m] * S[m])):
        np.add.at(acc[:, col], idx, val)
order = np.arange(len(acc))[::-1]
cE = np.cumsum(acc[order, 0]); cT = np.cumsum(acc[order, 1]) / 3600
print(f'{a.pop} variant {a.variant}, t(4000) {t4000:.1f} s, time exponent beyond N=4000: {a.a}, beyond {a.n2:.0f}: {a.a2 or a.a}; total E {cE[-1]:.4g}')
for C in (1e2, 1e3, 1e4, 8766, 87660, 876600, 8766000, 8.766e7, 8.766e8, 8.766e9):
    i = np.searchsorted(cT, C); i = min(i, len(cE) - 1)
    print(f'   C = {C:10.3g} CPU-h ({C / 8766:9.3g} CPU-yr): E = {cE[i]:.4g}')
for target in (0.1, 0.5, 1.0, 2.0):
    i = np.searchsorted(cE, target)
    if i >= len(cE): print(f'   E = {target}: not reached'); continue
    sel = order[:i + 1]; es = acc[sel, 0].sum()
    print(f'   E = {target}: {cT[i]:.3g} CPU-h = {cT[i] / 8766:.3g} CPU-yr; marginal density 1/{1 / 10 ** B[min(order[i], len(B) - 1)] / 3.156e7:.3g} CPU-yr per magic; '
          f'e-weighted N {math.exp(acc[sel, 2].sum() / es):.0f}, x {acc[sel, 3].sum() / es:.2f}, tau {math.exp(acc[sel, 4].sum() / es):.0f}, S_min {math.exp(acc[sel, 5].sum() / es):.0f}, S {acc[sel, 6].sum() / es:.0f}')
