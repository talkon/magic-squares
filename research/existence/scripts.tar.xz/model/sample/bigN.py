"""All sums with N >= NMIN (full runs + sampled runs): observed vs model predictions; fit a large-N correction to H."""
import sys, glob, json, math
sys.path.insert(0, '/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/model')
sys.path.insert(0, '/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/model/sample')
import numpy as np
from mlib import *
from predict import preds
NMIN = float(sys.argv[1]) if len(sys.argv) > 1 else 3000
pin = json.load(open(SP + '/forecast/state/pinfo_6.json'))
def smin(P):
    k = '6:' + '_'.join(map(str, P))
    return pin[k]['smin'] if k in pin and pin[k]['smin'] else smin_of(P)
paths = (glob.glob(SP + '/forecast/state/units/*.jsonl') + glob.glob(SP + '/verify-forecast/*/ms*.jsonl')
         + glob.glob(SP + '/verify-forecast/*/hx*.jsonl') + glob.glob(HERE + '/runs/*.jsonl'))
sums, sqs = load_jsonl(paths)
rows = {}
for r in sums:
    if r.get('truncated') or r['nvecs_raw'] < NMIN: continue
    P = norm(r['P']); rows[(P, r['S'])] = dict(P=P, S=r['S'], N=r['nvecs_raw'], L=r['labels'], y=r['squares'], f=1.0, se=math.sqrt(max(r['squares'], 1)), t=r['time'], src='full')
# traversal counts of full-run squares at these sums
trav = {}
for q in sqs:
    key = (norm(q['P']), q['S'])
    if key in rows:
        a = trav.setdefault(key, [0, 0, 0, 0]); a[0] += 1; a[1] += q['s_count']; a[2] += q['p_count']; a[3] += q['sp_count']
# sampled runs: logs + jsonl in this dir
HERE2 = '/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/model/sample'
samp = {}
for lg in sorted(glob.glob(HERE2 + '/t*.log')):
    js = lg[:-4] + '.jsonl'
    sm, sq = load_jsonl([js])
    if not sm: continue
    r = sm[-1]; P = norm(r['P']); key = (P, r['S'])
    recs = []
    N = None
    for l in open(lg):
        if l.startswith('#'): N = int(l.split()[2]); continue
        a = l.split(); recs.append((int(a[0]), int(a[1]), float(a[3])))
    s = samp.setdefault(key, dict(P=P, S=r['S'], N=N, L=r['labels'], recs=[], sq=[]))
    s['recs'] += recs; s['sq'] += sq
for key, s in samp.items():
    n = len(s['recs']); N = s['N']; c = [x[1] for x in s['recs']]
    m = sum(c) / n; v = sum((x - m) ** 2 for x in c) / max(n - 1, 1)
    rows[key] = dict(P=s['P'], S=s['S'], N=N, L=s['L'], y=sum(c), f=n / N, se=N * math.sqrt(v / n), t=N * sum(x[2] for x in s['recs']) / n, src='sampled')
    a = [0, 0, 0, 0]
    for q in s['sq']: a[0] += 1; a[1] += q['s_count']; a[2] += q['p_count']; a[3] += q['sp_count']
    trav[key] = a
# stratified sum (13 7 4 3 1 1, S = 2650): stratum A = r1 < 5164 sampled 1/600, stratum B = r1 >= 5164 sampled 1/3000
def readlog(f):
    rec = []
    for l in open(f):
        if l.startswith('#'): continue
        a = l.split(); rec.append((int(a[0]), int(a[1]), float(a[3])))
    return rec
import os
if os.path.exists(HERE2 + '/u2650_137_B.log'):
    A = readlog(HERE2 + '/s2650_137_A.log'); Bv = readlog(HERE2 + '/u2650_137_B.log')
    Ntot = 31743; NA = 5164; NB = Ntot - NA
    def strat(rec, Nh):
        c = [x[1] for x in rec]; n = len(c); m = sum(c) / n; v = sum((x - m) ** 2 for x in c) / max(n - 1, 1)
        tm = sum(x[2] for x in rec) / n
        return Nh * m, Nh ** 2 * v / n, Nh * tm, n
    eA, vA, tA, nA = strat(A, NA); eB, vB, tB, nB = strat(Bv, NB)
    smA, sqA = load_jsonl([HERE2 + '/s2650_137_A.jsonl']); smB, sqB = load_jsonl([HERE2 + '/u2650_137_B.jsonl'])
    P = (13, 7, 4, 3, 1, 1); key = (P, 2650)
    y = sum(x[1] for x in A) + sum(x[1] for x in Bv)
    est = eA + eB
    rows[key] = dict(P=P, S=2650, N=Ntot, L=279, y=y, f=(y / est if est > 0 else (nA + nB) / Ntot), se=math.sqrt(vA + vB), t=tA + tB, src='strat')
    a = [0, 0, 0, 0]
    for q in sqA + sqB: a[0] += 1; a[1] += q['s_count']; a[2] += q['p_count']; a[3] += q['sp_count']
    trav[key] = a
    print(f'stratified 2650: A n={nA} est {eA:.0f}; B n={nB} est {eB:.0f}; total {est:.0f} +- {math.sqrt(vA+vB):.0f}; time {tA+tB:.0f} s')
out = []
print(f"{'P':22s} {'S':>5s} {'x':>5s} {'N':>6s} {'L':>4s} {'src':7s} {'f':>6s} {'y':>4s} {'est':>7s} {'+-':>6s} | {'H raw':>7s} {'base_cal':>8s} {'samex':>6s} {'clamp':>6s} | {'est/H':>5s} {'est/bc':>6s} | {'time s':>7s}")
for key, r in sorted(rows.items(), key=lambda kv: kv[1]['N']):
    s0 = smin(r['P'])
    pr = preds(r['P'], r['S'], r['N'], s0)
    est = r['y'] / r['f']
    r.update(pr); r['est'] = est; r['smin'] = s0
    out.append(r)
    print(f"{' '.join(map(str, r['P'])):22s} {r['S']:5d} {pr['x']:5.2f} {r['N']:6d} {r['L']:4d} {r['src']:7s} {r['f']:6.4f} {r['y']:4d} {est:7.0f} {r['se']:6.0f} | {pr['H_raw']:7.0f} {pr.get('base_cal', float('nan')):8.0f} {pr['samex_raw']*0.35:6.1f} {pr['sched_clamped_x0.35']:6.2f} | {est/pr['H_raw']:5.2f} {est/pr.get('base_cal', float('nan')):6.2f} | {r['t']:7.0f}")
# pooled
y = np.array([r['y'] for r in out], float); f = np.array([r['f'] for r in out]); N = np.array([r['N'] for r in out], float)
for nm in ('H_raw', 'base_cal', 'samex_raw', 'sched_clamped_x0.35'):
    mu = np.array([r.get(nm, np.nan) for r in out]) * f
    if nm == 'samex_raw': mu = mu * 0.35
    ok = np.isfinite(mu)
    print(f'pooled obs/pred {nm:20s}: {y[ok].sum():.0f} / {mu[ok].sum():.1f} = {y[ok].sum()/mu[ok].sum():.3f};  N>=12000 only: {y[ok & (N>=12000)].sum():.0f}/{mu[ok & (N>=12000)].sum():.1f} = {y[ok & (N>=12000)].sum()/max(mu[ok & (N>=12000)].sum(),1e-9):.3f}')
# Poisson fit of log(ratio to H raw) = a + b ln(N/10000), sample fraction as exposure
mu0 = np.array([r['H_raw'] for r in out]) * f
X = np.column_stack([np.ones(len(out)), np.log(N / 10000)])
b = np.zeros(2)
for _ in range(100):
    mu = mu0 * np.exp(X @ b)
    g = X.T @ (y - mu); Hs = X.T @ (mu[:, None] * X)
    b = b + np.linalg.solve(Hs, g)
mu = mu0 * np.exp(X @ b)
cov = np.linalg.inv(X.T @ (mu[:, None] * X))
# overdispersion from Pearson chi2
phi = max(1.0, float(np.sum((y - mu) ** 2 / mu) / (len(y) - 2)))
print(f'H raw correction: ratio = exp({b[0]:.3f} + {b[1]:.3f} ln(N/1e4));  se (Poisson) {np.sqrt(np.diag(cov)).round(3)}, overdispersion phi {phi:.2f} -> se {np.sqrt(np.diag(cov) * phi).round(3)}')
for Nq in (5000, 10000, 20000, 50000, 1e5):
    l = b[0] + b[1] * math.log(Nq / 1e4); sl = math.sqrt(phi * (cov[0, 0] + 2 * cov[0, 1] * math.log(Nq / 1e4) + cov[1, 1] * math.log(Nq / 1e4) ** 2))
    print(f'   N {Nq:7.0f}: obs/H_raw {math.exp(l):.2f} (x/ {math.exp(sl):.2f})')
# traversal check
ps_o = ps_e = pp_o = pp_e = sp_o = sp_e = 0.0
for r in out:
    key = (r['P'], r['S']); a = trav.get(key)
    if not a: continue
    ps_o += a[1]; pp_o += a[2]; sp_o += a[3]; ps_e += a[0] * 720 * r['p_S']; pp_e += a[0] * 720 * r['p_P']; sp_e += a[0] * 720 * r['p_S'] * r['p_P'] * 2.6
print(f'traversals at N>={NMIN:.0f}: S {ps_o:.0f} vs {ps_e:.1f} pred ({ps_o/ps_e:.2f});  P {pp_o:.0f} vs {pp_e:.1f} ({pp_o/pp_e:.2f});  SP {sp_o:.0f} vs {sp_e:.2f} (rho 2.6)')
json.dump([{k: (list(v) if isinstance(v, tuple) else v) for k, v in r.items()} for r in out], open(HERE2 + '/bigN_rows.json', 'w'))
