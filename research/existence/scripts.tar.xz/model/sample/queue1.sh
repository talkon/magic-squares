#!/bin/bash
# sampled runs, one at a time
cd /tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/model/sample
run() { # tag stride S exps...
  tag=$1; st=$2; S=$3; shift 3
  off=$(( (RANDOM * 32768 + RANDOM) % st ))
  SAMPLE_STRIDE=$st SAMPLE_OFFSET=$off SAMPLE_LOG=$tag.log timeout 500 ./msearch_sample --sums $S --out $tag.jsonl "$@"
  echo "$tag done rc=$? off=$off" >> queue1.status
}
run t2700_k8 400 2700 9 6 4 3 1 1 1 1
run t2250_116 400 2250 11 6 4 3 2 1
run t3600_14 300 3600 14 7 4 4 1 0 0 1
run t2400_137 600 2400 13 7 4 3 1 1
run t3500_129 250 3500 12 9 6 2 1 1
run t2200_b 200 2200 13 7 4 3 1 1
echo ALLDONE >> queue1.status
