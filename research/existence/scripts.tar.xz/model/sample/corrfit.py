import json, math, numpy as np
R = json.load(open('bigN_rows.json'))
y = np.array([r['y'] for r in R], float); f = np.array([r['f'] for r in R]); N = np.array([r['N'] for r in R], float)
x = np.array([r['x'] for r in R]); mu0 = np.array([r['H_raw'] for r in R]) * f
def fit(cols, names):
    X = np.column_stack([np.ones(len(R))] + cols)
    b = np.zeros(X.shape[1])
    for _ in range(200):
        mu = mu0 * np.exp(X @ b); b = b + np.linalg.solve(X.T @ (mu[:, None] * X), X.T @ (y - mu))
    mu = mu0 * np.exp(X @ b); cov = np.linalg.inv(X.T @ (mu[:, None] * X))
    phi = max(1.0, float(np.sum((y - mu) ** 2 / mu) / (len(y) - X.shape[1])))
    dev = 2 * np.sum(np.where(y > 0, y * np.log(np.maximum(y, 1e-300) / mu), 0) - (y - mu))
    print(' + '.join(f'{v:.3f}*{n}' for v, n in zip(b, ['1'] + names)), ' se', np.sqrt(np.diag(cov) * phi).round(3), f'phi {phi:.1f} dev {dev:.1f}')
    return b, cov * phi
print('ratio to H_raw, sums with N >= 3000:', len(R))
fit([], [])
fit([np.log(N / 1e4)], ['lnN'])
fit([x], ['x'])
fit([np.log(N / 1e4), x], ['lnN', 'x'])
m = N >= 12000
print('N>=12000: obs', y[m].sum(), 'H_raw', mu0[m].sum().round(1), 'ratio', (y[m].sum() / mu0[m].sum()).round(3))
