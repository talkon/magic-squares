#!/bin/bash
cd /tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/model/sample
python3 corr.py 0.64 -0.27 /tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/model/sample/pertab2.py pertab_mid.json > pertab_mid.txt 2>&1
python3 corr.py 0.64 -0.27 /tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/model/sample/where2.py pop_Hc_mid_30000.json H_corr 2000 2900 5000 10000 > where_mid.txt 2>&1
python3 corr.py 0.64 -0.27 /tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/model/sample/frontier2.py pop_Hc_mid_30000.json --variant H_corr --a 3.92 > front_mid_a3.92.txt 2>&1
python3 corr.py 0.64 -0.27 /tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/model/sample/frontier2.py pop_Hc_mid_30000.json --variant H_corr --a 3.92 --a2 5.2 > front_mid_a3.92_5.2.txt 2>&1
python3 corr.py 0.54 -0.62 /tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/model/sample/frontier2.py pop_Hc_low_30000.json --variant H_corr --a 3.92 > front_low_a3.92.txt 2>&1
python3 corr.py 0.76 0.08 /tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/model/sample/frontier2.py pop_Hc_high_30000.json --variant H_corr --a 3.92 > front_high_a3.92.txt 2>&1
echo done > batchd.done
