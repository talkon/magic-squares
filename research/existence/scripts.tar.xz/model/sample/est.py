"""Estimate total squares (and full-sum time) from per-r1 sample logs. usage: est.py log1 [log2 ...] (same sum)"""
import sys, math
rows = []; N = None; strides = []
for f in sys.argv[1:]:
    for l in open(f):
        if l.startswith('#'):
            a = l.split(); N = int(a[2]); L = int(a[4]); strides.append(int(a[6])); continue
        r, sq, nd, t = l.split(); rows.append((int(r), int(sq), int(nd), float(t)))
n = len(rows)
sq = [r[1] for r in rows]; t = [r[3] for r in rows]
m = sum(sq) / n; v = sum((s - m) ** 2 for s in sq) / max(n - 1, 1)
f = n / N
tot = N * m; se = N * math.sqrt(v / n * (1 - f))
tt = N * sum(t) / n
mt = sum(t) / n; vt = sum((x - mt) ** 2 for x in t) / max(n - 1, 1)
print(f'N {N} L {L} sampled r1 {n} (f={f:.4f}) squares in sample {sum(sq)} r1 with squares {sum(1 for s in sq if s)} max/r1 {max(sq)}')
print(f'est squares {tot:.0f} +- {se:.0f} (SRS se; Poisson-only se {N*math.sqrt(sum(sq))/n:.0f})')
print(f'est full time {tt:.0f} s +- {N*math.sqrt(vt/n):.0f}; sample time {sum(t):.1f} s; s/square {tt/max(tot,1):.1f}')
