"""How the per-P total E(P) scales with tau, ln P, S_min, k (monotone P population). usage: percoef.py pop.json"""
import json, sys, math
import numpy as np
d = json.load(open(sys.argv[1])); R = [r for r in d['rows'] if r['E'] > 0]
E = np.array([r['E'] for r in R]); t = np.array([r['tau'] for r in R], float); s = np.array([r['smin'] for r in R]); k = np.array([r['k'] for r in R], float)
lP = np.array([r['lP'] for r in R])
X = np.column_stack([np.ones(len(R)), np.log(t), np.log(s), k])
b, *_ = np.linalg.lstsq(X, np.log(E), rcond=None); res = np.log(E) - X @ b
print(f'{sys.argv[1]}: {len(R)} P; ln E = {b[0]:.1f} + {b[1]:.2f} ln tau + {b[2]:.2f} ln S_min + {b[3]:.2f} k   (resid sd {res.std():.2f})')
X2 = np.column_stack([np.ones(len(R)), np.log(t), lP, k])
b2, *_ = np.linalg.lstsq(X2, np.log(E), rcond=None)
print(f'   equivalently ln E = {b2[0]:.1f} + {b2[1]:.2f} ln tau + {b2[2]:.2f} ln P + {b2[3]:.2f} k')
print('   by S_min class: n P, total E, max E(P) (its P), median E(P), E share of top 1% of P')
for lo, hi in ((150, 300), (300, 500), (500, 1000), (1000, 1500), (1500, 2000), (2000, 3000), (3000, 5000), (5000, 10000), (10000, 20000), (20000, 30000)):
    m = (s >= lo) & (s < hi)
    if not m.any(): continue
    Em = np.sort(E[m])[::-1]; i = np.argmax(np.where(m, E, -1)); n1 = max(1, int(0.01 * m.sum()))
    print(f'   {lo:5d}-{hi:<5d}: {m.sum():6d} P, total {Em.sum():9.3g}, max {Em[0]:9.3g} ({"_".join(map(str, R[i]["P"]))}, tau {R[i]["tau"]}), median {np.median(Em):9.2g}, top1% share {Em[:n1].sum() / Em.sum():.2f}')
print('   by tau class: median E(P), max E(P)')
for lo, hi in ((500, 1000), (1000, 2000), (2000, 4000), (4000, 8000), (8000, 16000), (16000, 32000), (32000, 1e9)):
    m = (t >= lo) & (t < hi)
    if m.any(): print(f'   tau {lo:6.0f}-{hi:<6.0f}: {m.sum():6d} P, median {np.median(E[m]):9.2g}, max {E[m].max():9.3g}, total {E[m].sum():9.3g}')
