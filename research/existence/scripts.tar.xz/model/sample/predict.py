"""Model predictions of semi-magic squares (and p_S, p_P) for one (P, S) with known N, S_min.
usage: predict.py S N smin L e1 e2 ...   (L = observed labels, optional 0)"""
import sys, math
sys.path.insert(0, '/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/model')
import numpy as np
from mlib import *
from epop import profile, XG
from legcheck import sq_H
import hmodel as hm, json
HC = json.load(open(HERE + '/hcoef.json'))['coef']
def preds(P, S, N, smin, Lobs=0):
    P = norm(P)
    out = {}
    out['sched_clamped_x0.35'] = float(sq_model(P, S, N, smin)) * 0.35
    out['sched_raw'] = float(sq_model(P, S, N, smin))
    # same-x N^2.25 (raw scheduler at N=4000, same x)
    out['samex_raw'] = float(sq_model(P, S, 4000.0, smin)) * (N / 4000.0) ** 2.25 if N > 4000 else out['sched_raw']
    # anchored along S (base_cal): anchor where analytic N first reaches 4000
    Sg, Ng, s0 = profile(P, smin)
    idx = np.nonzero(Ng >= 4000)[0]
    if len(idx):
        ia = idx[0]
        sqa = float(sq_model(P, Sg[0], 4000.0, smin)) if Ng[0] >= 4000 else float(sq_model(P, Sg[ia], Ng[ia], smin))
        out['anchored_raw'] = max(out['sched_raw'], sqa * (N / 4000.0) ** 2.25)
        out['base_cal'] = max(out['sched_raw'] * 0.35, sqa * (N / 4000.0) ** 2.25 * 0.84)
        out['x_anchor'] = math.log(Sg[ia] / smin)
    out['H_raw'] = float(sq_H(P, np.array([float(S)]), np.array([float(N)]), smin)[0])
    out['H_x0.8'] = out['H_raw'] * 0.8
    if Lobs:
        x = math.log(S / smin)
        lH = float(hm.logH(N, Lobs))
        out['H_raw_Lobs'] = math.exp(HC[0] + HC[1] * lH + HC[2] * x + HC[3] * math.log(N))
    ps = float(trav(P, S, smin, 's', clampP=False)); pp = float(trav(P, S, smin, 'p', clampP=False))
    out['p_S'] = ps; out['p_P'] = pp; out['p_magic'] = pmagic(ps, pp, 2.6)
    out['x'] = math.log(S / smin)
    return out
if __name__ == '__main__':
    S, N, smin, L = float(sys.argv[1]), float(sys.argv[2]), float(sys.argv[3]), float(sys.argv[4])
    P = tuple(int(a) for a in sys.argv[5:])
    for k, v in preds(P, S, N, smin, L).items():
        print(f'{k:22s} {v:.4g}')
