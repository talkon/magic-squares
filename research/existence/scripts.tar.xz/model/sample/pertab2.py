"""Per-P expected magic squares under H_corr (A, B from corr.py) + where within P. usage: corr.py A B pertab2.py"""
import math, json, sys
import numpy as np
from epop import *
from variants import VAR
SAMPLE = ['10 4 3 2', '12 6 3 2', '11 4 3 2 1', '13 7 3 2 1', '14 7 5 3', '12 6 3 2 1 1', '13 7 4 2 0 1', '12 8 4 2 1', '13 7 4 3 1 1',
          '11 6 4 3 2 1', '12 9 6 2 1 1', '14 7 4 4 1 0 0 1', '9 6 4 3 1 1 1 1', '10 5 3 2 1 1 1 1 1', '14 8 5 3 2 1 1',
          '16 9 5 3 2 1 1 1', '18 10 6 4 3 2 1 1', '20 12 7 5 3 2 2 1 1', '24 14 8 6 4 3 2 2 1 1']
o = VAR['H_corr']
print('| P | tau | k | S_min | N_peak | E(P) | x50 | S50/S_min | N at x50 | share S > 1.6 S_min | semi-magic squares (all S) | P(magic/square), E-weighted |')
print('|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|')
out = []
for s in SAMPLE:
    P = tuple(int(t) for t in s.split())
    s0 = smin_of(P) if lnP(P) < 43 else int(round(smin_analytic(P)))
    S, N, sq, pm, e, dS, _ = E_of(P, o, smin=s0)
    Et = e.sum(); c = np.cumsum(e); i50 = min(np.searchsorted(c, 0.5 * Et), len(S) - 1)
    frac16 = e[S > 1.6 * s0].sum() / Et if Et else 0
    nsq = (sq * dS).sum()
    print(f'| {s} | {tau(P)} | {sum(1 for x in P if x)} | {s0} | {N.max():.3g} | {Et:.2g} | {XG[i50]:.2f} | {math.exp(XG[i50]):.2f} | {N[i50]:.3g} | {frac16:.2f} | {nsq:.2g} | {Et / nsq if nsq else 0:.1g} |')
    out.append(dict(P=s, tau=tau(P), smin=s0, E=float(Et), x50=float(XG[i50]), N50=float(N[i50]), sq=float(nsq)))
json.dump(out, open(sys.argv[1] if len(sys.argv) > 1 else 'pertab2.json', 'w'), indent=1)
