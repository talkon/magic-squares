"""Where the expected magic squares with S <= X are: E-weighted histograms over sums (N, x, S/S_min) and P (tau, S_min, k).
usage (via corr.py): corr.py A B where2.py pop.json VARIANT X1 [X2 ...]"""
import sys, json, math
import numpy as np
from epop import *
from variants import VAR
pop, var = sys.argv[1], sys.argv[2]; Xs = [float(v) for v in sys.argv[3:]]
o = VAR[var]
rows = json.load(open(pop))['rows']
NE = [0, 1000, 3000, 1e4, 2e4, 3.2e4, 5e4, 1e5, 3e5, 1e12]
XE = [0, .1, .2, .3, .4, .5, .6, .8, 1.3]
TE = [0, 3000, 6500, 10000, 15000, 30000, 1e9]
SE = [0, 1000, 1500, 2000, 2500, 3000, 5000, 1e9]
KE = [1, 5, 6, 7, 8, 20]
acc = {X: dict(N=np.zeros(len(NE) - 1), x=np.zeros(len(XE) - 1), tau=np.zeros(len(TE) - 1), smin=np.zeros(len(SE) - 1), k=np.zeros(len(KE) - 1), tot=0.0, sq=0.0, lpm=0.0) for X in Xs}
top = {X: [] for X in Xs}
for r in rows:
    if r['smin'] > max(Xs): continue
    P = tuple(r['P'])
    S, N, sq, pm, e, dS, s0 = E_of(P, o, smin=r['smin'])
    for X in Xs:
        m = S <= X
        if not m.any(): continue
        em = e[m]; tot = em.sum()
        if tot <= 0: continue
        a = acc[X]; a['tot'] += tot; a['sq'] += (sq * dS)[m].sum()
        a['lpm'] += (em * np.log(np.maximum(pm[m], 1e-300))).sum()
        a['N'] += np.histogram(N[m], NE, weights=em)[0]
        a['x'] += np.histogram(XG[m], XE, weights=em)[0]
        a['tau'][np.searchsorted(TE, r['tau'], 'right') - 1] += tot
        a['smin'][np.searchsorted(SE, r['smin'], 'right') - 1] += tot
        a['k'][min(np.searchsorted(KE, r['k'], 'right') - 1, len(KE) - 2)] += tot
        top[X].append((tot, P, r['tau'], r['smin']))
for X in Xs:
    a = acc[X]; t = a['tot']
    print(f'X = {X:.0f}: monotone-P total E {t:.4g}; semi-magic squares with S <= X (monotone P, model) {a["sq"]:.3g}; E-weighted geometric-mean P(magic|square) {math.exp(a["lpm"] / t):.2g}')
    for nm, ed in (('N', NE), ('x', XE), ('tau', TE), ('smin', SE), ('k', KE)):
        print(f'  by {nm:5s}: ' + ', '.join(f'{lo:g}-{hi:g}: {v / t:.3f}' for lo, hi, v in zip(ed[:-1], ed[1:], a[nm])))
    print('  top P:', '; '.join(f"{'_'.join(map(str, P))} (tau {tt}, smin {s:.0f}) {e:.3g}" for e, P, tt, s in sorted(top[X], reverse=True)[:8]))
