"""N_magic(X) curves for the recalibrated model (H_corr) and comparisons."""
import json, math
import numpy as np
MD = '/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/model'
d = json.load(open('assign2_H_corr.json')); XG = np.array(d['XGRID'])
tm = np.sum([c['cX'] for c in d['classes']], axis=0); tc = np.sum([c['ca'] for c in d['classes']], axis=0)
ratio = np.where(tm > 0, tc / np.maximum(tm, 1e-300), 1.0)
def load(f): p = json.load(open(f)); return np.sum([r['cX'] for r in p['rows']], axis=0)
old = json.load(open(MD + '/final_curves.json')); old_ratio = np.array(old['ratio'])
curves = {
 'H_corr mid (all P)': tc,
 'H_corr mid (monotone P)': tm,
 'H_corr low (all P)': load('pop_Hc_low_30000.json') * ratio,
 'H_corr high (all P)': load('pop_Hc_high_30000.json') * ratio,
 'H_corr mid, only sums with N <= 32k (all P)': load('pop_Hc_cap32k_30000.json') * ratio,
 'base_cal x1.18 (all P)': load(MD + '/pop_base_cal_30000.json') * old_ratio * 1.18,
 'previous central: H x0.8 (all P)': np.array(old['H_all']),
 'scheduler clamped, no growth (monotone)': load(MD + '/pop_nogrowth_30000.json'),
}
def xat(c, t):
    i = np.searchsorted(c, t)
    if i >= len(XG): return float('inf')
    if i == 0: return XG[0]
    a, b = math.log(max(c[i-1], 1e-300)), math.log(c[i]); w = (math.log(t) - a) / (b - a)
    return math.exp(math.log(XG[i-1]) + w * (math.log(XG[i]) - math.log(XG[i-1])))
Xs = (1000, 1500, 2000, 2500, 3000, 4000, 5000, 7000, 1e4, 2e4, 3e4)
print('| curve | ' + ' | '.join(f'{x:g}' for x in Xs) + ' | X: 0.105 | ln2 | 1 | 2.303 |')
print('|---|' + '---:|' * (len(Xs) + 4))
for k, c in curves.items():
    print(f'| {k} | ' + ' | '.join(f'{np.interp(x, XG, c):.2g}' for x in Xs) + ' | ' + ' | '.join(f'{xat(c, t):.0f}' for t in (0.105, math.log(2), 1.0, 2.303)) + ' |')
c = tc
sl = lambda X: math.log(np.interp(X * 1.2, XG, c) / np.interp(X / 1.2, XG, c)) / math.log(1.44)
print('\nlocal growth exponent d ln N / d ln X (mid, all P):', ', '.join(f'{X:g}: {sl(X):.1f}' for X in (1200, 1500, 2000, 3000, 5000, 1e4, 2e4)))
print('multiplicity all/monotone (mid):', ', '.join(f'{X:g}: {np.interp(X, XG, ratio):.1f}' for X in (1000, 2000, 3000, 5000, 1e4, 3e4)))
print('\nmid (all P) with an extra multiplicative model error F on E (rho, p_S p_P, multiplicity sampling, analytic N, h at N<3000):')
for f in (0.1, 1/3, 0.5, 1, 2, 3, 10):
    cc = tc * f
    print(f'  F = {f:.2g}: smallest-S median {xat(cc, math.log(2)):.0f}, Poisson 10-90% {xat(cc, 0.105):.0f}-{xat(cc, 2.303):.0f}, N_magic = 1 at {xat(cc, 1):.0f}')
for nm in ('H_corr low (all P)', 'H_corr high (all P)'):
    cc = curves[nm]
    print(f'  {nm}: median {xat(cc, math.log(2)):.0f}, N=1 at {xat(cc, 1):.0f}')
json.dump({'XGRID': XG.tolist(), **{k: v.tolist() for k, v in curves.items()}}, open('final2_curves.json', 'w'))
