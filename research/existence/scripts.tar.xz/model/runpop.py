"""E(P) over a population of P; per-P cumulative E at a grid of X (max magic sum)."""
import json, math, sys, time, argparse
import numpy as np
from epop import *
from popgen import gen
ap = argparse.ArgumentParser()
ap.add_argument('--xmax', type=float, default=20000)
ap.add_argument('--tmin', type=int, default=500)
ap.add_argument('--npr', type=int, default=12)
ap.add_argument('--variant', default='base')
ap.add_argument('--out', default=None)
ap.add_argument('--keys', default=None, help='json list of P tuples instead of generating')
a = ap.parse_args()
from variants import VAR
o = VAR[a.variant]
XGRID = np.exp(np.linspace(math.log(100), math.log(a.xmax), 80))
Ps = [tuple(p) for p in json.load(open(a.keys))] if a.keys else gen(a.xmax, a.tmin, a.npr, monotone=True)
print(len(Ps), 'P', flush=True)
t0 = time.time(); rows = []
for i, P in enumerate(Ps):
    P = norm(P)
    lP = lnP(P)
    if 6 * math.exp(lP / 6) > a.xmax: continue
    S, N, sq, pm, e, dS, s0 = E_of(P, o)
    if N.max() < 300: 
        continue
    cum = np.cumsum(e)
    cX = np.interp(XGRID, S, cum, left=0.0, right=cum[-1])
    Et = float(cum[-1])
    if Et <= 0: continue
    w = e / Et
    # where the yield is: E-weighted x, N; CPU time to search all sums up to the median-E point and to 90% (scheduler time model)
    t = sum_time(N) * dS
    ct = np.cumsum(t)
    i50 = np.searchsorted(cum, 0.5 * Et); i90 = np.searchsorted(cum, 0.9 * Et)
    i50 = min(i50, len(S) - 1); i90 = min(i90, len(S) - 1)
    rows.append(dict(P=P, tau=tau(P), k=sum(1 for e_ in P if e_), np=len(P), smin=s0, lP=lP, E=Et, cX=cX.tolist(),
                     xbar=float((w * XG).sum()), lNbar=float((w * np.log(np.maximum(N, 1))).sum()), Npk=float(N.max()),
                     x50=float(XG[i50]), x90=float(XG[i90]), N50=float(N[i50]), T50=float(ct[i50]), T90=float(ct[i90]),
                     sq_tot=float((sq * dS).sum()), sq50=float((sq * dS)[:i50 + 1].sum())))
    if i % 5000 == 0: print(i, '%.0fs' % (time.time() - t0), flush=True)
out = a.out or f'pop_{a.variant}_{int(a.xmax)}.json'
json.dump(dict(XGRID=XGRID.tolist(), opts={k: v for k, v in o.items()}, rows=rows), open(out, 'w'))
tot = sum(r['E'] for r in rows)
print('done', len(rows), 'P with N>=300; total E (all S) %.4g' % tot, '%.0fs' % (time.time() - t0))
cX = np.sum([r['cX'] for r in rows], axis=0)
for X in (300, 500, 1000, 2000, 3000, 5000, 10000, 20000):
    if X <= a.xmax: print('  N_magic(X<=%d) = %.4g' % (X, np.interp(X, XGRID, cX)))
