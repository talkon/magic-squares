"""Per-P total E vs size; counts of P per S_min class; local growth exponent of N_magic(X)."""
import json, sys, math
import numpy as np
d = json.load(open(sys.argv[1])); rows = d['rows']; XG = np.array(d['XGRID'])
E = np.array([r['E'] for r in rows]); sm = np.array([r['smin'] for r in rows]); t = np.array([r['tau'] for r in rows], float)
k = np.array([r['k'] for r in rows], float); lP = np.array([r['lP'] for r in rows])
cX = np.sum([r['cX'] for r in rows], axis=0)
print(sys.argv[1])
print(' S_min class | #P (N>=300) | sum E(P) | max E(P) | top-1% P share | median tau of top 1%')
edges = [150, 300, 500, 700, 1000, 1500, 2000, 3000, 5000, 7000, 10000, 15000, 20000, 30000]
for lo, hi in zip(edges[:-1], edges[1:]):
    m = (sm >= lo) & (sm < hi)
    if not m.sum(): continue
    Es = np.sort(E[m])[::-1]; n1 = max(1, len(Es) // 100)
    top = np.argsort(-E * m)[:n1]
    print(f'  {lo:6d}-{hi:<6d} {m.sum():7d}  {E[m].sum():9.3g}  {Es[0]:9.3g}  {Es[:n1].sum() / Es.sum():5.2f}   {np.median(t[top]):8.0f}')
# fit: ln E(P) of the best P vs ln S_min (upper envelope: top 1% per log-bin)
lb = np.log(sm); bins = np.linspace(lb.min(), lb.max(), 25); env = []
for a, b in zip(bins[:-1], bins[1:]):
    m = (lb >= a) & (lb < b) & (E > 0)
    if m.sum() > 20: env.append(((a + b) / 2, np.log(np.quantile(E[m], 0.99))))
env = np.array(env)
if len(env) > 3:
    sl = np.polyfit(env[:, 0], env[:, 1], 1)
    print(' 99th-percentile E(P) vs S_min: slope d lnE / d ln S_min = %.2f' % sl[0], ' (points:', ' '.join(f'{math.exp(a):.0f}:{b/math.log(10):.2f}' for a, b in env[::3]), 'log10E)')
# regression over P with E above 1e-3 of max in their class
m = E > 0
X = np.column_stack([np.ones(m.sum()), np.log(t[m]), np.log(sm[m]), k[m]])
b, *_ = np.linalg.lstsq(X, np.log(E[m]), rcond=None)
print(' ln E(P) ~ %.2f + %.2f ln tau + %.2f ln S_min + %.2f k  (all P, OLS; resid sd %.2f)' % (*b, (np.log(E[m]) - X @ b).std()))
print(' N_magic(X) and local exponent d ln N / d ln X:')
for X in (500, 700, 1000, 1500, 2000, 3000, 5000, 7000, 10000, 15000, 20000, 30000):
    if X > XG[-1] * 1.0001: continue
    v = np.interp(X, XG, cX); v2 = np.interp(X * 1.2, XG, cX) if X * 1.2 <= XG[-1] else np.nan; v1 = np.interp(X / 1.2, XG, cX)
    print(f'   X {X:6d}  N_magic {v:10.4g}   local exponent {math.log(v2 / v1) / math.log(1.44) if v2 == v2 else float("nan"):5.2f}')
i = np.searchsorted(cX, 1.0)
print(' X where N_magic = 1:', '%.0f' % XG[i] if i < len(XG) else '> %.0f (N_magic(Xmax) = %.3g)' % (XG[-1], cX[-1]))
