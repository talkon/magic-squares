import math, json
import numpy as np
from epop import *
from variants import VAR
SAMPLE = ['10 4 3 2', '12 6 3 2', '11 4 3 2 1', '13 7 3 2 1', '14 7 5 3', '12 6 3 2 1 1', '13 7 4 2 0 1', '12 9 6 2 1 1',
          '14 7 4 4 1 0 0 1', '13 7 4 3 1 1', '11 6 4 3 2 1', '9 6 4 3 1 1 1 1', '10 5 3 2 1 1 1 1 1', '14 8 5 3 2 1 1',
          '16 9 5 3 2 1 1 1', '12 7 4 3 2 1 1 1 1 1', '18 10 6 4 3 2 1 1', '20 12 7 5 3 2 2 1 1']
out = []
print('P | tau k | S_min (exact) | N_peak (x of peak) | E(P) nogrowth / samex / base / H | H: x50, N at x50, frac E beyond 1.6 S_min, semi-magic squares (H) | magic per semi-magic (H, E-weighted)')
for s in SAMPLE:
    P = tuple(int(t) for t in s.split())
    s0 = smin_of(P) if lnP(P) < 43 else int(round(smin_analytic(P)))
    res = {}
    for v in ('nogrowth', 'samex', 'base', 'H'):
        S, N, sq, pm, e, dS, _ = E_of(P, VAR[v], smin=s0)
        res[v] = (e.sum(), S, N, sq, pm, e, dS)
    Et, S, N, sq, pm, e, dS = res['H']
    c = np.cumsum(e); i50 = min(np.searchsorted(c, 0.5 * Et), len(S) - 1)
    frac16 = e[S > 1.6 * s0].sum() / Et if Et else 0
    ip = int(np.argmax(N))
    nsq = (sq * dS).sum()
    print(f'{s:22s} | {tau(P):6d} {sum(1 for x in P if x)} | {s0:6d} | {N.max():9.0f} ({XG[ip]:.2f}) | ' + ' / '.join(f'{res[v][0]:.2g}' for v in ('nogrowth', 'samex', 'base', 'H'))
          + f' | {XG[i50]:.2f} {N[i50]:8.0f} {frac16:.3f} {nsq:9.3g} | {Et / nsq if nsq else 0:.2g}')
    out.append(dict(P=s, tau=tau(P), smin=s0, Npk=float(N.max()), E={v: float(res[v][0]) for v in res}, x50=float(XG[i50]), N50=float(N[i50]), frac16=float(frac16), sqH=float(nsq)))
json.dump(out, open('sampletab.json', 'w'), indent=1)
