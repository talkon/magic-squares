"""Analytic label count L(P, S): divisors of P with |ln d - ln(S/6)| <= w; ln-divisor histogram by convolution."""
import math
import numpy as np
from mlib import PRIMES, norm
H = 0.005
def ldiv_hist(P):
    P = norm(P)
    lP = sum(e * math.log(p) for p, e in zip(PRIMES, P))
    n = int(lP / H) + 3
    h = np.zeros(n); h[0] = 1.0
    for p, e in zip(PRIMES, P):
        if e == 0: continue
        sh = math.log(p) / H
        out = np.zeros(n)
        for j in range(e + 1):
            s = int(round(j * sh))
            out[s:] += h[:n - s]
        h = out
    return np.cumsum(h), lP
def labels(P, S, w):
    """number of divisors with ln d in [ln(S/6) - w, ln(S/6) + w]"""
    C, lP = ldiv_hist(P)
    c = np.log(np.asarray(S, float) / 6)
    lo = np.clip(((c - w) / H).astype(int), 0, len(C) - 1); hi = np.clip(((c + w) / H).astype(int), 0, len(C) - 1)
    return C[hi] - C[lo]
