"""Contribution of non-monotone exponent tuples (any assignment of exponents to primes), relative to the monotone ones.
Pre-filter all tuples with an analytic peak-N estimate, then evaluate E for survivors."""
import math, sys, json, time
import numpy as np
from mlib import PRIMES, norm
import nmodel as nm
from popgen import gen
xmax = float(sys.argv[1]); npr = int(sys.argv[2]) if len(sys.argv) > 2 else 12
t0 = time.time()
allP = gen(xmax, 500, npr, monotone=False)
print(len(allP), 'tuples', '%.0fs' % (time.time() - t0), flush=True)
lp = np.log(PRIMES[:npr]); 
E = np.array(allP, dtype=np.int16)
lP = E @ lp
s2 = ((E * (E + 6)) * 5 / 252) @ (lp ** 2)
lV = np.sum([np.log([math.comb(e + 5, 5) for e in range(0, 40)])[E[:, i]] for i in range(npr)], axis=0)
# peak density of x' distribution ~ F'(x) at x ~ 1 ... use crude N_peak ~ 0.75 * V/720 * c(s2) / S_peak with S_peak ~ 2.6*6P^(1/6)
# calibrate c(s2): peak of dF/dx' from the table
F, XG, S2G = nm.load()
dF = np.gradient(F, XG, axis=1).max(1)
c = np.interp(np.log(s2), np.log(S2G), dF)
Npk = 0.75 * np.exp(lV) / 720 * c / (2.6 * 6 * np.exp(lP / 6))
mono = np.all(E[:, :-1] >= E[:, 1:], axis=1)
keep = Npk >= 250
print('kept (N_peak est >= 250): %d (monotone %d, non-monotone %d)' % (keep.sum(), (keep & mono).sum(), (keep & ~mono).sum()), flush=True)
json.dump([list(map(int, norm(p))) for p in E[keep & ~mono]], open(f'nonmono_{int(xmax)}.json', 'w'))
json.dump([list(map(int, norm(p))) for p in E[keep & mono]], open(f'mono_{int(xmax)}.json', 'w'))
