#!/bin/bash
cd /tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/model
until [ -f batch2.done ]; do sleep 5; done
python3 assign3.py pop_H_30000.json --variant H --ntop 25 > assign3_H.txt 2>&1
python3 runpop.py --xmax 30000 --npr 14 --variant base_cal > logs_pop_base_cal.txt 2>&1
python3 frontier.py pop_base_cal_30000.json --variant base_cal --a 3.5 > front_base_cal_3.5.txt 2>&1
python3 assign3.py pop_H_cap10k_30000.json --variant H_cap10k --ntop 25 > assign3_H_cap10k.txt 2>&1
echo done > batch3.done
