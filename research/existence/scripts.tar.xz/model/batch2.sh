#!/bin/bash
cd /tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/existence/model
while pgrep -f "msearch --sums 1080" >/dev/null; do sleep 5; done
python3 assign.py pop_H_30000.json --variant H --ntop 20 > assign_H.txt 2>&1
python3 assign.py pop_base_30000.json --variant base --ntop 20 > assign_base.txt 2>&1
python3 assign.py pop_nogrowth_30000.json --variant nogrowth --ntop 20 > assign_nogrowth.txt 2>&1
python3 frontier.py pop_H_30000.json --variant H --a 3.5 > front_H_3.5.txt 2>&1
python3 frontier.py pop_base_30000.json --variant base --a 3.5 > front_base_3.5.txt 2>&1
python3 frontier.py pop_nogrowth_30000.json --variant nogrowth --a 3.5 > front_nogrowth_3.5.txt 2>&1
python3 frontier.py pop_H_30000.json --variant H --a 5.5 > front_H_5.5.txt 2>&1
echo done > batch2.done
