import sys, json, glob, math, collections
import numpy as np
from mlib import *
pin = json.load(open(SP + '/forecast/state/pinfo_6.json'))
SMIN = {}
def smin(P):
    P = norm(P)
    if P in SMIN: return SMIN[P]
    k = '6:' + '_'.join(map(str, P))
    SMIN[P] = pin[k]['smin'] if k in pin and pin[k]['smin'] else smin_of(P)
    return SMIN[P]
groups = {
 'units': glob.glob(SP + '/forecast/state/units/*.jsonl'),
 'verif': glob.glob(SP + '/verify-forecast/*/ms*.jsonl') + glob.glob(SP + '/verify-forecast/*/hx*.jsonl'),
 'mine': glob.glob(HERE + '/runs/*.jsonl'),
}
rows = []
for g, paths in groups.items():
    sums, sqs = load_jsonl(paths)
    seen = set()
    for r in sums:
        P = norm(r['P']); key = (P, r['S'])
        if key in seen or r.get('truncated'): continue
        seen.add(key)
        s0 = smin(P)
        rows.append((g, P, r['S'], r['nvecs_raw'], s0, r['squares'], r['time'] + r['setup_time']))
print(len(rows), 'sums')
P_ = [r[1] for r in rows]
pred = np.array([float(sq_model(r[1], r[2], r[3], r[4])) for r in rows])
obs = np.array([r[5] for r in rows], float)
x = np.array([math.log(r[2] / r[4]) for r in rows]); N = np.array([r[3] for r in rows], float)
g = np.array([r[0] for r in rows])
tauv = np.array([tau(r[1]) for r in rows])
def tab(mask, by, edges, name):
    print(f'-- {name}')
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = mask & (by >= lo) & (by < hi)
        if m.sum() == 0: continue
        print(f'  {lo:8.3g}-{hi:<8.3g} sums {m.sum():6d} obs {obs[m].sum():7.0f} pred {pred[m].sum():9.1f} obs/pred {obs[m].sum()/max(pred[m].sum(),1e-9):6.3f}')
for gg in ['units', 'verif', 'mine']:
    m = g == gg
    tab(m, x, [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.8, 1.0, 1.2, 1.5, 2, 3], gg + ' by x=ln(S/Smin)')
    tab(m, N, [400, 700, 1000, 1500, 2000, 3000, 4000, 6000, 9000], gg + ' by N')
m = (g=='units')
tab(m, tauv, [0, 1500, 2500, 4000, 6500, 1e5], 'units by tau')
