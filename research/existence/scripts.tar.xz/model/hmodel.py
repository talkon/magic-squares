"""Structural squares model: log mu = a + b log H(N, Lhat) + c x + d lN, H = (L)_36 / (2 720^2) * (N / C(L,6))^12,
Lhat from the analytic label model (lmodel + lcal.json). Fitted by Poisson ML on all sum-level data."""
import json, math
import numpy as np
from math import lgamma
_lg = np.vectorize(lgamma)
def gammaln(a):
    return _lg(np.asarray(a, float))
from mlib import HERE
LC = json.load(open(HERE + '/lcal.json'))
def logH(N, L):
    N = np.asarray(N, float); L = np.asarray(L, float)
    ok = L > 36.5
    Ls = np.where(ok, L, 40.0)
    v = gammaln(Ls + 1) - gammaln(Ls - 35) - math.log(2 * 720 ** 2) + 12 * (np.log(np.maximum(N, 1)) - (gammaln(Ls + 1) - gammaln(Ls - 5) - gammaln(7)))
    return np.where(ok, v, -300.0)
def Lhat(Lpred, N, x):
    b = LC['coef']
    return np.exp(b[0] + b[1] * np.log(np.maximum(Lpred, 1)) + b[2] * np.log(np.maximum(N, 1)) + b[3] * np.asarray(x))
def fit():
    d = np.load(HERE + '/lrows.npy')
    N, Lobs, Lp, x, y = d[:, 0], d[:, 1], d[:, 2], d[:, 3], d[:, 4]
    Lh = Lhat(Lp, N, x)
    lH = logH(N, Lh)
    ok = lH > -299
    X = np.column_stack([np.ones(ok.sum()), lH[ok], x[ok], np.log(N[ok])])
    yy = y[ok]
    b = np.zeros(4); b[0] = math.log(yy.mean())
    for _ in range(200):
        eta = X @ b; mu = np.exp(np.minimum(eta, 50)); z = eta + (yy - mu) / np.maximum(mu, 1e-300)
        bn = np.linalg.solve(X.T @ (mu[:, None] * X) + 1e-8 * np.eye(4), X.T @ (mu * z))
        if np.max(np.abs(bn - b)) < 1e-10: b = bn; break
        b = bn
    mu = np.exp(X @ b)
    dev = 2 * np.sum(np.where(yy > 0, yy * np.log(np.maximum(yy, 1e-300) / mu), 0) - (yy - mu))
    json.dump({'coef': list(b), 'dev': dev}, open(HERE + '/hcoef.json', 'w'))
    return b, dev, mu, N[ok], x[ok], yy
if __name__ == '__main__':
    b, dev, mu, N, x, y = fit()
    print('coef', np.round(b, 3), 'dev %.1f' % dev)
    for nm, by, edges in (('N', N, [300, 700, 1000, 1500, 2000, 3000, 4000, 6000, 9000]), ('x', x, [0, .1, .2, .3, .4, .5, .6, .8, 1, 1.3])):
        print(' obs/pred by', nm)
        for lo, hi in zip(edges[:-1], edges[1:]):
            m = (by >= lo) & (by < hi)
            if m.sum(): print(f'   {lo:6g}-{hi:<6g} n {m.sum():6d} obs {y[m].sum():6.0f} pred {mu[m].sum():8.1f} ratio {y[m].sum()/mu[m].sum():5.2f}')
    big = N > 3000
    print(' big-N: obs', y[big], 'pred', np.round(mu[big], 1))
