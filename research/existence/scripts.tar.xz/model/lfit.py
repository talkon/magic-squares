import json, glob, math
import numpy as np
from mlib import *
from lmodel import labels, ldiv_hist
pin = json.load(open(SP + '/forecast/state/pinfo_6.json'))
paths = (glob.glob(SP + '/forecast/state/units/*.jsonl') + glob.glob(SP + '/verify-forecast/*/ms*.jsonl')
         + glob.glob(SP + '/verify-forecast/*/hx*.jsonl') + glob.glob(HERE + '/runs/*.jsonl'))
sums, _ = load_jsonl(paths)
seen = set(); R = []
for r in sums:
    P = norm(r['P']); key = (P, r['S'])
    if key in seen or r.get('truncated') or r['nvecs_raw'] < 300: continue
    seen.add(key); k_ = '6:' + '_'.join(map(str, P))
    s0 = pin[k_]['smin'] if k_ in pin and pin[k_]['smin'] else smin_of(P)
    R.append((P, r['S'], r['nvecs_raw'], r['labels'], s0, r['squares']))
print(len(R))
byP = {}
for i, r in enumerate(R): byP.setdefault(r[0], []).append(i)
Lobs = np.array([r[3] for r in R], float)
xp = np.array([math.log(r[1] / 6) - lnP(r[0]) / 6 for r in R])
best = None
for cw in (1.2, 1.5, 1.8, 2.1, 2.4, 2.7, 3.0):
    Lp = np.zeros(len(R))
    for P, idx in byP.items():
        S = np.array([R[i][1] for i in idx], float)
        w = cw * np.sqrt(np.maximum(xp[idx], 1e-6))
        Lp[idx] = labels(P, S, w)
    lr = np.log(Lobs / np.maximum(Lp, 1))
    print('cw %.1f: median Lobs/Lpred %.3f sd log %.3f' % (cw, np.exp(np.median(lr)), lr.std()))
    if best is None or lr.std() < best[1]: best = (cw, lr.std(), Lp.copy())
cw, sd, Lp = best
# check residual vs N, x
lr = np.log(Lobs / Lp); N = np.array([r[2] for r in R], float)
for lo, hi in ((300, 1000), (1000, 2000), (2000, 4000), (4000, 9000)):
    m = (N >= lo) & (N < hi); print('  N %d-%d: n %d median ratio %.3f' % (lo, hi, m.sum(), np.exp(np.median(lr[m]))))
x = np.array([math.log(r[1] / r[4]) for r in R])
for lo, hi in ((0, .1), (.1, .3), (.3, .6), (.6, 1.2)):
    m = (x >= lo) & (x < hi); print('  x %.1f-%.1f: n %d median ratio %.3f' % (lo, hi, m.sum(), np.exp(np.median(lr[m]))))
# regression log Lobs = a + b log Lp + c log N
X = np.column_stack([np.ones(len(R)), np.log(Lp), np.log(N), x])
b, *_ = np.linalg.lstsq(X, np.log(Lobs), rcond=None); res = np.log(Lobs) - X @ b
print('log Lobs = %s . [1, log Lpred, log N, x]; resid sd %.3f' % (np.round(b, 3), res.std()))
json.dump({'cw': cw, 'coef': list(b)}, open('lcal.json', 'w'))
np.save('lrows.npy', np.column_stack([N, Lobs, Lp, x, [r[5] for r in R], [r[1] for r in R], [r[4] for r in R], [tau(r[0]) for r in R]]))
