"""Multiplicity correction for non-monotone P: for the top monotone P (by E) in each S_min class, enumerate all
distinct assignments of the same exponent multiset to the first NPR primes (P up to e^slack larger, S_min <= XMAX),
evaluate E for each, and report sum over assignments / E(sorted)."""
import json, math, sys, itertools, argparse
import numpy as np
from epop import *
from variants import VAR
ap = argparse.ArgumentParser()
ap.add_argument('pop'); ap.add_argument('--variant', default='H'); ap.add_argument('--npr', type=int, default=16)
ap.add_argument('--slack', type=float, default=6 * math.log(1.6)); ap.add_argument('--ntop', type=int, default=25)
ap.add_argument('--xmax', type=float, default=30000)
a = ap.parse_args()
o = VAR[a.variant]
d = json.load(open(a.pop)); rows = d['rows']; XGR = np.array(d['XGRID'])
lp = [math.log(p) for p in PRIMES[:a.npr]]
def assignments(P, lmax):
    exps = sorted([e for e in P if e], reverse=True)
    vals = sorted(set(exps), reverse=True); mult = [exps.count(v) for v in vals]
    out = []
    def rec(i, used, cur, lP):
        if i == len(vals):
            t = [0] * a.npr
            for pi, e in cur: t[pi] = e
            out.append(tuple(t)); return
        free = [j for j in range(a.npr) if j not in used]
        for comb in itertools.combinations(free, mult[i]):
            add = vals[i] * sum(lp[j] for j in comb)
            if lP + add > lmax + 1e-9: continue
            rec(i + 1, used | set(comb), cur + [(j, vals[i]) for j in comb], lP + add)
    rec(0, set(), [], 0.0)
    return out
edges = [300, 500, 700, 1000, 1500, 2000, 3000, 5000, 7000, 10000, 15000, 20000, 30000]
print(f'{a.pop} variant {a.variant}; assignments over first {a.npr} primes, P up to x{math.exp(a.slack):.0f} (S_min up to x{math.exp(a.slack/6):.2f}) of the sorted P')
res = []
for lo, hi in zip(edges[:-1], edges[1:]):
    cls = [r for r in rows if lo <= r['smin'] < hi and hi <= a.xmax * 1.0001]
    if not cls: continue
    cls.sort(key=lambda r: -r['E'])
    top = cls[:a.ntop]
    Es = Ea = 0.0; nas = 0; Eslim = 0.0
    for r in top:
        P = tuple(r['P']); lP0 = r['lP']
        lmax = min(lP0 + a.slack, 6 * math.log(a.xmax / 6))
        tot = 0.0; totlim = 0.0
        for Q in assignments(P, lmax):
            Q = norm(Q)
            S, N, sq, pm, e, dS, s0 = E_of(Q, o)
            tot += e.sum(); nas += 1
            totlim += e[S <= hi].sum()   # only sums below the class's upper X
        Es += r['E']; Ea += tot; Eslim += totlim
    clsE = sum(r['E'] for r in cls)
    res.append((lo, hi, len(cls), Es / clsE, Ea / Es, nas / len(top)))
    print(f'  S_min {lo:5d}-{hi:<5d}: top {len(top)} P hold {Es/clsE:.2f} of the class E; sum over assignments / sorted = {Ea/Es:6.2f}; counting only S <= {hi}: {Eslim/Es:6.2f} (avg {nas/len(top):.0f} assignments per multiset)', flush=True)
