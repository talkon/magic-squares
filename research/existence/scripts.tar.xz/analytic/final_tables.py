"""Final N_semi(X), N_magic(X) tables (gs3 stratified estimates x permutation multiplier x quadrature-grid
correction), local growth exponents, crossing points."""
import json, math, numpy as np
from gs3_est import est
from tabutil import interp, xcross
BIAS = {  # F(48 pts)/F(npts) at XG quartiles (gridbias.py), (X, magic, semi)
 5: [(700, 1.024, 1.032), (3742, 1.017, 1.014), (20000, 1.017, 1.014), (200000, 1.017, 1.014)],
 6: [(490, 1.038, 1.044), (2404, 1.016, 1.025), (11784, 1.011, 1.014), (50000, 1.011, 1.012)],
 7: [(388, 1.275, 1.335), (1506, 1.094, 1.126), (5833, 1.076, 1.108), (20000, 1.024, 1.037)],
 8: [(325, 2.007, 2.018), (1056, 1.229, 1.254), (3427, 1.113, 1.115), (10000, 1.059, 1.076)]}
def bias(n, X, j):
    B = BIAS[n]; xs = [math.log(b[0]) for b in B]; ys = [math.log(b[j]) for b in B]
    return math.exp(np.interp(math.log(X), xs, ys))
XS = {5: [300, 400, 500, 700, 1000, 2000, 5000, 10000, 20000, 50000, 200000],
      6: [250, 289, 300, 327, 400, 500, 700, 1000, 1500, 2000, 3000, 4000, 5000, 6000, 8000, 10000, 15000, 20000, 30000, 50000],
      7: [280, 300, 310, 350, 400, 435, 465, 500, 600, 800, 1000, 2000, 5000, 10000, 20000],
      8: [300, 330, 360, 375, 392, 420, 450, 500, 600, 840, 1000, 2000, 5000, 10000]}
out = {}
for n in (5, 6, 7, 8):
    d = json.load(open(f"gs3_n{n}.json"))
    R = {f: est(d, f) for f in ("lEs_lin", "lEm_lin", "lEm_quad")}
    XG = np.array(R["lEm_lin"][0])
    Ns = np.array(R["lEs_lin"][1]) * np.array([bias(n, x, 2) for x in XG])
    Nm = np.array(R["lEm_lin"][1]) * np.array([bias(n, x, 1) for x in XG])
    Nq = np.array(R["lEm_quad"][1]) * np.array([bias(n, x, 1) for x in XG])
    se = np.array(R["lEm_lin"][2]) * np.array([bias(n, x, 1) for x in XG])
    def g(arr, X):
        x0, x1 = X / 1.15, min(X * 1.15, XG[-1])
        a, b = interp(XG, arr, x0), interp(XG, arr, x1)
        return math.log(b / a) / math.log(x1 / x0) if a > 0 and b > 0 and x1 > x0 else float("nan")
    print(f"\n### n = {n}\n")
    print("| X | N_semi(S<=X) | g_semi | N_magic(S<=X) (se) | g_magic | N_magic quad | P(>=1 magic) |")
    print("|---|---|---|---|---|---|---|")
    rows = []
    for X in XS[n]:
        ns, nm, sm, nq = interp(XG, Ns, X), interp(XG, Nm, X), interp(XG, se, X), interp(XG, Nq, X)
        rows.append(dict(X=X, Ns=ns, Nm=nm, se=sm, Nq=nq, gs=g(Ns, X), gm=g(Nm, X)))
        print(f"| {X} | {ns:.3g} | {g(Ns, X):.1f} | {nm:.3g} ({sm:.2g}) | {g(Nm, X):.1f} | {nq:.3g} | {1 - math.exp(-nm):.3g} |")
    cr = {}
    for name, arr in (("semi", Ns), ("magic", Nm), ("magic_quad", Nq)):
        cr[name] = {t: xcross(XG, arr, v) for t, v in (("0.1", 0.1), ("ln2", math.log(2)), ("1", 1.0), ("3", 3.0))}
    print("crossings:", json.dumps({k: {t: (round(v) if v else None) for t, v in c.items()} for k, c in cr.items()}))
    print("N at top of grid X=%.0f: semi %.4g, magic %.4g, quad %.4g" % (XG[-1], Ns[-1], Nm[-1], Nq[-1]))
    out[n] = dict(rows=rows, cross=cr, top=(float(XG[-1]), float(Ns[-1]), float(Nm[-1]), float(Nq[-1])))
json.dump(out, open("final_tables.json", "w"), indent=1)
