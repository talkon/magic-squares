"""Fermi-Dirac (hard-core) maximum-entropy model: the n^2 entries of a square (or the
n entries of a vector) are a SET T of distinct divisors.  Occupation of divisor x is
Bernoulli(p_x), p_x = z w_x / (1 + z w_x), w_x = exp(-b d_x + lam . e_x), with
sum p = m, sum p d = m S/n, sum p e = m a/n.

 #sets T with |T| = m and the right totals ~ exp(F) * P_Bern(count, totals)
 #squares ~ m! #sets * P(lines | T) / (2 (n!)^2) * local
 P(lines | T) = [n^(2-n)]^q / ((2pi)^((n-1) q) det(C_T m/(m-1))^(n-1))
with C_T the population covariance of v = (d, e) over T (its FD expectation).
"""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import math
import numpy as np
from maxent import divisors, norm
from corr import logc
from model import ndiag_pairs

def fd_solve(P, S, n, m, init=None):
    ds, E, a = divisors(P)
    k = len(a); q = 1 + k
    sc = S / n
    keep = ds < 100 * sc
    ds = ds[keep]; E = E[keep]
    # features u = (1, -d/sc, e); target per-cell means (1, -1, a/n) times m
    U = np.concatenate([np.ones((len(ds), 1)), -(ds / sc)[:, None], E], axis=1)
    tgt = m * np.concatenate([[1.0, -1.0], a / n])
    th = np.zeros(q + 1) if init is None else init.copy()
    if init is None:
        th[1] = 1.0; th[0] = math.log(m / len(ds))
    def F(th):
        z = U @ th
        # sum log(1 + e^z) stable
        return np.logaddexp(0, z).sum() - th @ tgt, z
    val, z = F(th)
    for it in range(200):
        p = 1 / (1 + np.exp(-z))
        g = U.T @ p - tgt
        if np.abs(g).max() < 1e-9 * m:
            break
        Hs = (U * (p * (1 - p))[:, None]).T @ U
        step = np.linalg.solve(Hs + 1e-12 * np.eye(q + 1), g)
        t = 1.0
        for _ in range(50):
            nv, nz = F(th - t * step)
            if nv <= val - 1e-4 * t * (g @ step) + 1e-12 * abs(val): break
            t *= 0.5
        th = th - t * step; val, z = nv, nz
    p = 1 / (1 + np.exp(-z))
    return dict(th=th, F=val, p=p, ds=ds, E=E, a=a, k=k, q=q, U=U, sc=sc,
                resid=float(np.abs(U.T @ p - tgt).max()))

def fd_model(P, S, n=6):
    P = norm(P)
    out = dict(n=n)
    L2P = math.log(2 * math.pi)
    for m, tag in ((n, "vec"), (n * n, "grid")):
        r = fd_solve(P, S, n, m)
        p, ds, E, q = r["p"], r["ds"], r["E"], r["q"]
        # log of sum over sets with totals at target: F + log P_Bern
        Uo = np.concatenate([np.ones((len(ds), 1)), ds[:, None], E], axis=1)  # (1, d, e)
        V = (Uo * (p * (1 - p))[:, None]).T @ Uo
        ldV = np.linalg.slogdet(V)[1]
        lsets = r["F"] - 0.5 * (q + 1) * L2P - 0.5 * ldV
        out["lsets_" + tag] = lsets
        out["resid_" + tag] = r["resid"]
        if tag == "grid":
            v = np.concatenate([ds[:, None], E], axis=1)
            mu = (p @ v) / m
            X = v - mu
            CT = (X * p[:, None]).T @ X / m
            ldCT = np.linalg.slogdet(CT * m / (m - 1))[1]
            out["llines"] = (q * (2 - n) * math.log(n) - (n - 1) * q * L2P - (n - 1) * ldCT)
            out["ldCT"] = ldCT
            out["perpT"] = float(np.exp(-(p / m * np.log(np.maximum(p / m, 1e-300))).sum()))
            # traversal / pair probabilities with the FD population covariance
            Ce = CT[1:, 1:]
            cdd = -1.0 if n % 2 == 0 else 0.0
            ldpair = math.log((n - 1) ** 2 - cdd ** 2)
            out["lpS"] = -0.5 * (math.log(2 * math.pi * (n - 1)) + math.log(CT[0, 0]))
            out["lpP"] = -0.5 * ((q - 1) * math.log(2 * math.pi * (n - 1)) + np.linalg.slogdet(Ce)[1])
            out["lpSP"] = -0.5 * (q * math.log(2 * math.pi * (n - 1)) + np.linalg.slogdet(CT)[1])
            out["lpair"] = -(q * L2P + np.linalg.slogdet(CT)[1] + 0.5 * q * ldpair)
    loc = {kk: sum(logc(kk, n, x) for x in P if x > 0) for kk in ("vec", "semi", "T", "M")}
    out["logN"] = out["lsets_vec"] + loc["vec"]
    m = n * n
    out["logEsemi"] = (math.lgamma(m + 1) + out["lsets_grid"] + out["llines"] + loc["semi"]
                       - math.log(2) - 2 * math.lgamma(n + 1))
    out["lpP"] += loc["T"]; out["lpSP"] += loc["T"]; out["lpair"] += loc["M"]
    out["logEmagic"] = out["logEsemi"] + math.log(ndiag_pairs(n)) + out["lpair"]
    return out

if __name__ == "__main__":
    import sys
    P = tuple(int(x) for x in sys.argv[1].split(",")); n = int(sys.argv[2])
    from model import components, assemble
    for S in map(int, sys.argv[3:]):
        o = fd_model(P, S, n)
        a = assemble(components(P, S, n, pairs=False))
        print(S, "FD: logN %.3f logEsemi %.3f lpSP %.3f | iid: logN %.3f logEsemi %.3f lpSP %.3f" % (
            o["logN"], o["logEsemi"], o["lpSP"], a["logN"], a["logEsemi"], a["lpSP"]))
