#!/bin/sh
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1
while [ ! -s gs3_n5.json ]; do sleep 10; done
nice python3 gs3.py 8 50 10000 4000 40 80 0.10 gs3_n8.json 22 2> gs3_n8.err
echo queue5-done
