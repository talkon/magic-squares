#!/bin/sh
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1
nice python3 gs3.py 5 50 200000 300 40 80 0.10 gs3_n5.json 22 2> gs3_n5.err
echo queue6-done
