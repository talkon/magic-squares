import json, math, sys, numpy as np
from gs3_est import est
def xcross(XG, N, target=1.0):
    for i in range(1, len(XG)):
        if N[i - 1] < target <= N[i] and N[i - 1] > 0:
            t = (math.log(target) - math.log(N[i - 1])) / (math.log(N[i]) - math.log(N[i - 1]))
            return math.exp(math.log(XG[i - 1]) + t * (math.log(XG[i]) - math.log(XG[i - 1])))
    return None
out = {}
for fn in sys.argv[1:]:
    d = json.load(open(fn)); n = d["n"]
    R = {}
    for f in ("lEs_lin", "lEm_lin", "lEs_quad", "lEm_quad"):
        XG, t, s, m, miss = est(d, f); R[f] = (t, s, m)
    XG = np.array(XG)
    print(f"== n={n}: evaluated {len(d['res'])} of {sum(d['strata'].values())} candidate P (scale <= {d['Xhi']:.0f}, tau >= {d['tmin']}); unsampled-strata P {miss}")
    print("       X   N_semi       (se)    g_semi   N_magic      (se)   g_magic  perm-mult  | quad: N_semi  N_magic")
    rows = []
    for i, X in enumerate(XG):
        ts, ss, _ = R["lEs_lin"][0][i], R["lEs_lin"][1][i], 0
        tm, sm, mm = R["lEm_lin"][0][i], R["lEm_lin"][1][i], R["lEm_lin"][2][i]
        if ts <= 0: continue
        j0, j1 = max(i - 2, 0), min(i + 2, len(XG) - 1)
        def g(arr):
            a, b = arr[j0], arr[j1]
            return math.log(b / a) / math.log(XG[j1] / XG[j0]) if a > 0 and b > 0 else float("nan")
        gs, gm = g(R["lEs_lin"][0]), g(R["lEm_lin"][0])
        rows.append(dict(X=float(X), Ns=ts, Ns_se=ss, gs=gs, Nm=tm, Nm_se=sm, gm=gm, mult=mm, Ns_q=R["lEs_quad"][0][i], Nm_q=R["lEm_quad"][0][i]))
        print(f"{X:8.0f}  {ts:9.3g} ({ss:7.2g})  {gs:5.1f}   {tm:9.3g} ({sm:7.2g})  {gm:5.1f}    {mm:4.2f}     | {R['lEs_quad'][0][i]:9.3g} {R['lEm_quad'][0][i]:9.3g}")
    x1 = xcross(XG, R["lEm_lin"][0]); x1q = xcross(XG, R["lEm_quad"][0])
    xh = xcross(XG, R["lEm_lin"][0], math.log(2))
    print(f"   X where N_magic = 1: lin {x1}  quad {x1q};  P(exists) = 1/2 at X = {xh}")
    # weighted diagnostics
    lw = [(r.get("ld_w"), r["lEm_lin"][-1]) for r in d["res"] if r.get("ld_w") is not None]
    w = np.array([b for a, b in lw]); l = np.array([a for a, b in lw])
    print(f"   magic-weighted mean ld (sampled P, unweighted by strata) {np.sum(w*l)/np.sum(w):.1f}")
    out[n] = dict(rows=rows, X1=x1, X1q=x1q, Xhalf=xh)
json.dump(out, open("gs3_summary.json", "w"), indent=1)
