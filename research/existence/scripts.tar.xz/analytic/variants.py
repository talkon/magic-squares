import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json, math, numpy as np, collections
from model import assemble
d = json.load(open("calib3.json"))
sq = np.array([r["sq"] for r in d], float)
for v in [dict(edge=False, local=True), dict(edge=False, local=False), dict(edge=True, local=True),
          dict(edge=True, local=True, condpairs=True), dict(edge=False, local=True, condpairs=True)]:
    A = [assemble(r["comp"], **v) for r in d]
    lE = np.array([a["logEsemi"] for a in A]); ld = np.array([r["comp"]["ld_n2"] for r in d])
    if v.get("condpairs"): ld = np.array([r["comp"]["ld_n2"] * r["comp"]["B_semi"] for r in d])
    E = np.exp(lE)
    out = [f"{str(v):60s} obs/pred {sq.sum()/E.sum():.3f}"]
    for lo, hi in [(-14, -11), (-11, -10), (-10, -9), (-9, -8), (-8, -5)]:
        m = (ld >= lo) & (ld < hi)
        out.append(f"[{lo},{hi}) {sq[m].sum()/E[m].sum():.3f}")
    print(" ".join(out))
