"""Per half-octave (scale of the sorted P) totals of the magic / semi yield, summed over all S
(up to the grid end), with top contributors and composition."""
import json, math, sys, collections, numpy as np
for fn in sys.argv[1:]:
    d = json.load(open(fn)); st = d["strata"]; n = d["n"]
    by = collections.defaultdict(list)
    for r in d["res"]: by["|".join(map(str, r["st"]))].append(r)
    T = collections.defaultdict(lambda: np.zeros(4)); cnt = collections.Counter()
    comp_k = collections.defaultdict(float); comp_tau = collections.defaultdict(float); tot = 0.0
    top = []
    for key, Nst in st.items():
        h = int(key.split("|")[0]); cnt[h] += Nst
        v = by.get(key)
        if not v: continue
        w = Nst / len(v)
        for r in v:
            fm = r["lEm_lin"][-1]; fs = r["lEs_lin"][-1]
            T[h] += w * np.array([fs, fm, r["lEs_quad"][-1], r["lEm_quad"][-1]])
            k = sum(1 for a in r["P"] if a); tau = 1
            for a in r["P"]: tau *= a + 1
            comp_k[k] += w * fm; comp_tau[int(math.log2(tau))] += w * fm; tot += w * fm
            top.append((fm, r["P"], r.get("smin")))
    print(f"== n={n}: per half-octave of scale n P^(1/n) (sorted-exponent P; x perm multiplier not applied)")
    print("  scale     #P      semi(all S)   magic(all S)  magic(quad)")
    for h in sorted(T):
        print(f"  {2**(h/2):7.0f} {cnt[h]:7d}  {T[h][0]:12.3g}  {T[h][1]:12.3g}  {T[h][3]:12.3g}")
    print("  magic share by k:", {k: round(v / tot, 3) for k, v in sorted(comp_k.items())})
    print("  magic share by log2 tau:", {k: round(v / tot, 3) for k, v in sorted(comp_tau.items())})
    top.sort(key=lambda t: -t[0])
    print("  top P:", [(tuple(p), round(s or 0), f"{f:.2g}") for f, p, s in top[:8]])
