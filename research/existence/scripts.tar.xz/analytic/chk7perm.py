import os, sys, json, time, random
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import numpy as np, gs3, gmodel, maxent
gmodel.NPTS = 22
d = json.load(open("gs3_n7.json")); n = d["n"]
gs3.UNIV["Xlo"], gs3.UNIV["Xhi"] = d["Xlo"], d["Xhi"]
R = [r for r in d["res"] if "perm" in r]
R.sort(key=lambda r: -r["lEm_lin"][-1])
random.seed(3)
pick = R[:3] + random.sample(R[3:], 3)
t0 = time.time()
for r in pick:
    ex, c = gs3.perms_extra(tuple(r["P"]), n, d["XG"])
    old = np.array(r["perm"]["lEm_lin"][-1]); new = ex["lEm_lin"][-1]
    print(r["P"], "own %.3g old-perm %.3g new-perm %.3g nperm old %s new %d  t=%.0f" % (r["lEm_lin"][-1], old, new, r.get("nperm"), c, time.time() - t0), flush=True)
    maxent._div_cache.clear()
