"""Collect all sum and square records (n=6) from the scratchpad runs, deduplicated."""
import json, glob, os, collections
SP = "/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad"
def norm(P):
    P = list(P)
    while P and P[-1] == 0: P.pop()
    return tuple(P)
def load(extra=True):
    files = glob.glob(SP + "/forecast/state/units/*.jsonl")
    if extra:
        files += glob.glob(SP + "/verify-forecast/**/*.jsonl", recursive=True)
    sums, squares = {}, {}
    for f in files:
        for line in open(f):
            try: r = json.loads(line)
            except Exception: continue
            if r.get("n", 6) != 6: continue
            t = r.get("type")
            if t == "sum":
                key = (norm(r["P"]), r["S"])
                if r.get("truncated"): continue
                if key not in sums: sums[key] = r
            elif t == "square":
                h = r.get("hash") or json.dumps(r["grid"])
                key = (norm(r["P"]), r["S"], h)
                squares[key] = r
    return sums, squares
if __name__ == "__main__":
    s, q = load()
    print(len(s), "sum records", len(q), "squares")
    tot = collections.Counter()
    for (P, S), r in s.items(): tot[P] += r["squares"]
    print(len(tot), "P;", sum(tot.values()), "squares by sum records")
