#!/bin/sh
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1
while pgrep -f "strat2.py 6" > /dev/null; do sleep 10; done
nice python3 strat3.py 7 150 6000 4 8 10 1200 1800 strat7.json 2> strat7.err
nice python3 strat3.py 8 200 3500 6 10 10 1200 1800 strat8.json 2> strat8.err
nice python3 strat3.py 5 150 40000 5 9 10 1200 1800 strat5.json 2> strat5.err
echo queue-done
