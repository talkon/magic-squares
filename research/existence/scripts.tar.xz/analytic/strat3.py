"""Two-phase stratified cumulative N_semi(X), N_magic(X) on XGRID for candidates from gen2."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import sys, json, math, random, time, collections
import numpy as np
from gsum import eval_P, cum
from smin import save
from screen import dnear
from cands2 import gen2
from strat2 import stratum
XGRID = [200, 250, 300, 350, 400, 465, 550, 650, 800, 1000, 1250, 1600, 2000, 2500, 3200, 4000, 5000, 6400, 8000, 10000, 12500, 16000, 20000, 25000, 32000, 40000, 50000, 64000, 80000, 100000]
if __name__ == "__main__":
    n, Xlo, Xhi, omax, kmax, mp, n1, n2, out = sys.argv[1:10]
    n, Xlo, Xhi, omax, kmax, mp, n1, n2 = int(n), float(Xlo), float(Xhi), int(omax), int(kmax), int(mp), int(n1), int(n2)
    t0 = time.time()
    cands = [(dnear(P, n), P) for P in gen2(n, Xlo, Xhi, kmin=3, kmax=kmax, omax=omax, max_primes=mp, tau_min=n * n * 4)]
    print("candidates", len(cands), round(time.time() - t0), file=sys.stderr, flush=True)
    strata = collections.defaultdict(list)
    for dn, P in cands: strata[stratum(P, dn, n)].append((dn, P))
    random.seed(5)
    Xmax = 3 * Xhi
    def run(lst):
        res = []
        for i, (dn, P) in enumerate(lst):
            try: r = eval_P(tuple(P), n, Xmax)
            except Exception: r = None
            if r is None: res.append(dict(P=list(P), dn=dn, Fs=[0.0] * len(XGRID), Fm=[0.0] * len(XGRID)))
            else: res.append(dict(P=list(P), dn=dn, smin=r["smin"], Fs=[cum(r, X, "lEs") for X in XGRID], Fm=[cum(r, X, "lEm") for X in XGRID]))
            res[-1]["st"] = "|".join(map(str, stratum(P, dn, n)))
            if i % 200 == 0: print(i, len(lst), round(time.time() - t0), file=sys.stderr, flush=True); save()
        return res
    if n1 >= len(cands):
        res = run(cands)
    else:
        res = run(random.sample(cands, n1))
        done = {tuple(r["P"]) for r in res}
        byst = collections.defaultdict(list); coarse = collections.defaultdict(list)
        for r in res:
            v = max(r["Fm"][-1], 1e-3 * r["Fs"][-1] * 1e-8)
            byst[r["st"]].append(v); coarse[tuple(r["st"].split("|")[:3])].append(v)
        alloc = {}
        for key, lst in strata.items():
            ks = "|".join(map(str, key))
            v = byst.get(ks) or coarse.get(tuple(ks.split("|")[:3])) or [0.0]
            alloc[key] = len(lst) * (math.sqrt(np.mean(np.square(v))) + 1e-18)
        tw = sum(alloc.values())
        ph2 = []
        for key, lst in strata.items():
            m = int(round(n2 * alloc[key] / tw))
            rest = [c for c in lst if tuple(c[1]) not in done]
            ph2 += random.sample(rest, min(m, len(rest)))
        res += run(ph2)
    save()
    json.dump(dict(n=n, XGRID=XGRID, strata={"|".join(map(str, k)): len(v) for k, v in strata.items()}, res=res), open(out, "w"))
