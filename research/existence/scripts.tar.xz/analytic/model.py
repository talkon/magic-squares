"""Analytic model for (P, S, n): components in log space.

base_*   max-entropy Gaussian (saddle point) estimates
edge_*   exponentiated first-order Edgeworth correction for the joint (d, e) cell law
ealone_* sum over primes of the Edgeworth estimate of each prime's own lattice factor
loc_*    sum over primes of the exact lattice factor (Ehrhart-type counts / Gaussian)
ld_n, ld_n2  log P(n resp. n^2 iid cells distinct), B_vec, B_semi Gaussian pair boosts
Variants are assembled by assemble()."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import math
import numpy as np
from maxent import solve, log_esym_distinct, norm
from edge import cumulants, delta
from corr import logc

def ndiag_pairs(n):
    f = math.factorial(n)
    if n % 2 == 0:
        inv = 1
        for j in range(n - 1, 0, -2): inv *= j
    else:
        inv = n
        for j in range(n - 2, 0, -2): inv *= j
    return f * inv // 2

_ea = {}
def edge_alone(n, kind, a):
    key = (n, kind, a)
    if key in _ea: return _ea[key]
    xs = np.arange(a + 1, dtype=float)
    lo, hi = -50, 50
    for _ in range(100):
        t = (lo + hi) / 2
        w = np.exp(t * xs - (t * xs).max()); w /= w.sum()
        if w @ xs < a / n: lo = t
        else: hi = t
    K = cumulants(xs[:, None], w)
    d = delta(n, kind, K)
    if kind in ("T", "M"):
        d -= delta(n, "semi", K)
    _ea[key] = d
    return d

def components(P, S, n=6, pairs=True):
    P = norm(P)
    r = solve(P, S, n)
    k, C, H, w = r["k"], r["C"], r["H"], r["w"]
    a_list = [a for a in P if a > 0]
    q = 1 + k
    ldC = np.linalg.slogdet(C)[1]
    ldCe = np.linalg.slogdet(C[1:, 1:])[1]
    L2P = math.log(2 * math.pi)
    o = dict(H=H, k=k, q=q, varD=C[0, 0], resid=r["resid"])
    o["base_tup"] = n * H - 0.5 * q * L2P - 0.5 * (q * math.log(n) + ldC)
    o["base_grid"] = (n * n * H - 0.5 * (2 * n - 1) * q * L2P - 0.5 * (2 * n - 1) * ldC
                      - (n - 1) * q * math.log(n))
    o["base_pS"] = -0.5 * (math.log(2 * math.pi * (n - 1)) + math.log(C[0, 0]))
    o["base_pP"] = -0.5 * (k * math.log(2 * math.pi * (n - 1)) + ldCe)
    o["base_pSP"] = -0.5 * (q * math.log(2 * math.pi * (n - 1)) + ldC)
    cdd = -1.0 if n % 2 == 0 else 0.0
    ldpair = math.log((n - 1) ** 2 - cdd ** 2)
    o["base_pair"] = -(q * L2P + ldC + 0.5 * q * ldpair)
    # pair of diagonals, sum only / product only
    o["base_pairS"] = -(L2P + math.log(C[0, 0]) + 0.5 * ldpair)
    o["base_pairP"] = -(k * L2P + ldCe + 0.5 * k * ldpair)
    m = w > 1e-15
    vals = np.concatenate([r["ds"][m, None], r["E"][m]], axis=1)
    ww = w[m] / w[m].sum()
    K = cumulants(vals, ww); Ke = cumulants(vals[:, 1:], ww); Kd = cumulants(vals[:, :1], ww)
    ds = delta(n, "semi", K)
    o["edge_vec"] = delta(n, "vec", K); o["edge_grid"] = ds
    o["edge_pSP"] = delta(n, "T", K) - ds; o["edge_pair"] = delta(n, "M", K) - ds
    o["edge_pP"] = delta(n, "T", Ke) - delta(n, "semi", Ke)
    o["edge_pS"] = delta(n, "T", Kd) - delta(n, "semi", Kd)
    for kk in ("vec", "semi", "T", "M"):
        o["ealone_" + kk] = sum(edge_alone(n, kk, a) for a in a_list)
        o["loc_" + kk] = sum(logc(kk, n, a) for a in a_list)
    o["ld_n"] = log_esym_distinct(r["logw"], n)
    o["ld_n2"] = log_esym_distinct(r["logw"], n * n)
    o["sum_mu2"] = float((w ** 2).sum())
    if pairs:
        from pairs import pair_classes
        X = vals - ww @ vals
        chi2 = np.einsum("ta,ab,tb->t", X, np.linalg.inv(C), X)
        w2 = ww ** 2 / (ww ** 2).sum()
        def boost(kind):
            cl = pair_classes(n, kind)
            tot = sum(c for c, _, _ in cl)
            return sum(c * d ** (-q / 2) * float(w2 @ np.exp(-0.5 * G * chi2)) for c, d, G in cl) / tot
        o["B_vec"], o["B_semi"] = boost("vec"), boost("semi")
    o["lD"] = math.log(ndiag_pairs(n))
    o["lfact"] = math.lgamma(n + 1)
    o["n"] = n
    return o

def assemble(o, edge=False, local=True, condpairs=False, gamma=1.0):
    """log N, log E_semi, log p's, log E_magic for one variant"""
    n = o["n"]
    tup, grid = o["base_tup"], o["base_grid"]
    pS, pP, pSP, pair = o["base_pS"], o["base_pP"], o["base_pSP"], o["base_pair"]
    if edge:
        tup += o["edge_vec"]; grid += o["edge_grid"]
        pS += o["edge_pS"]; pP += o["edge_pP"]; pSP += o["edge_pSP"]; pair += o["edge_pair"]
    if local:
        sub = (lambda kk: o["ealone_" + kk]) if edge else (lambda kk: 0.0)
        tup += o["loc_vec"] - sub("vec"); grid += o["loc_semi"] - sub("semi")
        pP += o["loc_T"] - sub("T"); pSP += o["loc_T"] - sub("T"); pair += o["loc_M"] - sub("M")
    ldn, ldn2 = o["ld_n"], o["ld_n2"]
    if condpairs:
        ldn *= o["B_vec"]; ldn2 *= o["B_semi"]
    ldn2 *= gamma
    out = dict(logN=tup + ldn - o["lfact"],
               logEsemi=grid + ldn2 - math.log(2) - 2 * o["lfact"],
               lpS=pS, lpP=pP, lpSP=pSP, lpair=pair)
    out["logEmagic"] = out["logEsemi"] + o["lD"] + pair
    return out

if __name__ == "__main__":
    import sys
    P = tuple(int(x) for x in sys.argv[1].split(","))
    n = int(sys.argv[2])
    for S in map(int, sys.argv[3:]):
        o = components(P, S, n)
        for v in (dict(edge=False), dict(edge=True)):
            a = assemble(o, **v)
            print(S, v, " ".join(f"{k}={x:.3f}" for k, x in a.items()))
