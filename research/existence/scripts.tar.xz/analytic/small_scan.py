import sys, math, json
from smallcount import count
from smin import smin, save
n = int(sys.argv[1]); fac = float(sys.argv[2])
res = []
for Ps in sys.argv[3:]:
    P = tuple(int(x) for x in Ps.split(","))
    s0 = smin(P, n)
    tot = 0; nv = 0
    for S in range(s0, int(fac * s0) + 1):
        c, N, L = count(P, S, n)
        tot += c; nv += N
        if c: res.append((P, S, c, N))
    print(P, "Smin", s0, "squares", tot, "vectors", nv, flush=True)
save()
json.dump(res, open(f"small_n{n}.json", "w"))
