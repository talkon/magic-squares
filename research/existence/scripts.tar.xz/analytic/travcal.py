"""Traversal calibration: observed s/p/sp traversal counts per square vs model p_S, p_P, p_SP (batch model)."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json, glob, math, collections, numpy as np
from batch import batch
SP = "/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad"
def norm(P):
    P = list(P)
    while P and P[-1] == 0: P.pop()
    return tuple(P)
files = {6: glob.glob(SP + "/forecast/state/units/*.jsonl") + glob.glob(SP + "/verify-forecast/**/*.jsonl", recursive=True)
            + [SP + "/existence/analytic/runs/n6low.jsonl"],
         5: glob.glob(SP + "/existence/analytic/runs/n5*.jsonl"),
         7: glob.glob(SP + "/existence/analytic/runs/n7*.jsonl") + glob.glob(SP + "/existence/analytic/runs/t7.jsonl")}
out = {}
for n, fl in files.items():
    sq = {}
    for f in fl:
        for l in open(f):
            try: r = json.loads(l)
            except Exception: continue
            if r.get("type") != "square" or r.get("n", 6) != n: continue
            sq[(norm(r["P"]), r["S"], r.get("hash") or json.dumps(r["grid"]))] = r
    byP = collections.defaultdict(set)
    for (P, S, h) in sq: byP[P].add(S)
    pred = {}
    for P, Ss in byP.items():
        Ss = sorted(Ss)
        o = batch(P, np.array(Ss, float), n, want_dist=False)
        for j, S in enumerate(Ss):
            pred[(P, S)] = (o["lpS"][j], o["lpP"][j], o["lpSP"][j], o["lpair"][j])
    nf = math.factorial(n)
    tot = np.zeros(6)
    rows = []
    for (P, S, h), r in sq.items():
        lpS, lpP, lpSP, lpair = pred[(P, S)]
        rows.append((P, S, r["s_count"], r["p_count"], r["sp_count"], nf * math.exp(lpS), nf * math.exp(lpP), nf * math.exp(lpSP), lpair))
    a = np.array([x[2:8] for x in rows], float)
    o_, e_ = a[:, :3].sum(0), a[:, 3:].sum(0)
    print(f"n={n}: squares {len(rows)}  S obs {o_[0]:.0f} pred {e_[0]:.1f} ratio {o_[0]/e_[0]:.3f} | P obs {o_[1]:.0f} pred {e_[1]:.1f} ratio {o_[1]/e_[1]:.3f} | SP obs {o_[2]:.0f} pred {e_[2]:.2f} ratio {o_[2]/e_[2]:.3f}")
    # rho: SP obs / (S obs * P obs / (n! * squares)) ; and model's own
    m = len(rows)
    print(f"      empirical rho = SP*n!*sq/(S*P) = {o_[2]*nf*m/(o_[0]*o_[1]):.2f};  model rho-like = {e_[2]*nf*m/(e_[0]*e_[1]):.2f}")
    lp = np.array([x[8] for x in rows])
    print(f"      mean model P(magic|square) = D_n * mean(p_pair) = {math.exp(np.log(np.mean(np.exp(lp)))):.3g} x D_n")
    out[n] = rows
json.dump({str(k): [list(map(lambda z: list(z) if isinstance(z, tuple) else z, r)) for r in v] for k, v in out.items()}, open("travcal.json", "w"))
