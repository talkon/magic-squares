"""Model vs the first search's per-P totals (stats/stats_short.txt): squares and
S-, P-, SP-traversal counts over [S_min, max_S]."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import sys, json, math, numpy as np
from batch import batch
from smin import smin, save
def parse():
    rows = []
    for line in open("/home/user/magic-squares/stats/stats_short.txt"):
        parts = line.split()
        if len(parts) < 16: continue
        # P exponents then P_val ... find P_val as the first token with value > 1000 after exps
        toks = line.split()
        # exps are leading small ints, followed by P_val (large int)
        i = 0; exps = []
        while i < len(toks) and toks[i].isdigit() and int(toks[i]) < 64 and (i + 1 < len(toks)):
            exps.append(int(toks[i])); i += 1
        if i + 13 >= len(toks): continue
        try:
            Pval = int(toks[i]); nv = int(toks[i + 1]); mx = int(toks[i + 2]); maxS = int(toks[i + 3])
            count = int(toks[i + 4]); time = float(toks[i + 5]); sols = int(toks[i + 6])
            nS, nP, nSP = int(toks[i + 7]), int(toks[i + 8]), int(toks[i + 9])
        except (ValueError, IndexError):
            continue
        P = list(exps)
        while P and P[-1] == 0: P.pop()
        rows.append(dict(P=tuple(P), Pval=Pval, maxS=maxS, sols=sols, nS=nS, nP=nP, nSP=nSP, time=time, nvecs=nv))
    return rows
def run(out="legacy_pred.json", npts=40, smax_cap=8.0):
    rows = parse()
    res = []
    for i, r in enumerate(rows):
        P = r["P"]
        if sum(1 for a in P if a) < 2: continue
        s0 = smin(P, 6)
        hi = min(r["maxS"], smax_cap * s0)
        if hi <= s0 + 2: continue
        u = np.concatenate([[0.0], np.geomspace(2e-3, hi / s0 - 1, npts - 1)])
        S = np.unique(np.round(s0 * (1 + u)).astype(int)); S = S[S > s0]
        try:
            o = batch(P, S, 6)
        except Exception as e:
            print("fail", P, e, file=sys.stderr); continue
        rec = dict(r, smin=s0, hi=int(hi), S=S.tolist())
        for k in ("logEsemi", "ld_n2", "lpair", "lpS", "lpP", "lpSP", "logN"):
            rec[k] = [float(x) for x in o[k]]
        res.append(rec)
        if i % 100 == 0:
            print(i, len(rows), P, file=sys.stderr, flush=True); save()
    save()
    json.dump(res, open(out, "w"))
if __name__ == "__main__":
    rows = parse()
    print(len(rows), sum(r["sols"] for r in rows), sum(r["nSP"] for r in rows), rows[:2])
    if len(sys.argv) > 1 and sys.argv[1] == "run":
        run()
