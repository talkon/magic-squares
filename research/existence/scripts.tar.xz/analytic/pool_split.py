"""Split the analytic pool totals (S <= 1.8 S_min) by predicted vectors-per-sum N, and compare per-P
with the forecast's own E (frontier) where available."""
import os, sys, json, math, collections
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import numpy as np, gmodel, maxent
d = json.load(open("pool_cmp.json")); res = d["res"]
st = collections.Counter(); 
from pool_cmp_gen import gen, tau
C = gen(); cnt = collections.Counter(int(math.log2(tau(P))) for P in C)
ns = collections.Counter(r["k"] for r in res)
edges = [0, 1000, 3000, 8000, 20000, 60000, 1e12]
Tm = np.zeros(len(edges) - 1); Ts = np.zeros(len(edges) - 1)
for r in res:
    w = cnt[r["k"]] / ns[r["k"]]
    o = gmodel.eval_P(tuple(r["P"]), 6, 1e12, fmax=1.8, npts=30)
    if o is None: continue
    S = np.array(o["S"], float); N = np.exp(o["lN"])
    for i in range(len(edges) - 1):
        m = (N >= edges[i]) & (N < edges[i + 1])
        # weight each grid point by its share of the trapezoid: approximate by masking the integrand
        vm = np.where(m, o["lEm_lin"], -1e9); vs = np.where(m, o["lEs_lin"], -1e9)
        Tm[i] += w * gmodel.cum(S, vm, 1e12); Ts[i] += w * gmodel.cum(S, vs, 1e12)
    maxent._div_cache.clear()
print("N range: E_semi, E_magic (pool, S <= 1.8 S_min; masked-integrand approximation)")
for i in range(len(edges) - 1):
    print(f"  [{edges[i]:.0f},{edges[i+1]:.0f}): semi {Ts[i]:.3g}  magic {Tm[i]:.3g}")
print("  total semi %.3g magic %.3g" % (Ts.sum(), Tm.sum()))
