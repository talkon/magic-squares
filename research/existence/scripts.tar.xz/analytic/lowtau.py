"""Contribution of P below the gs3 tau cutoff at small X (n = 7, 8 near the N=1 crossing; n = 6 for completeness)."""
import os, sys, math, random
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import numpy as np, gmodel, maxent
from cands2 import gen2
from smin import save
from gs3 import tau
for n, Xs, tlo, thi, frac in ((5, (500, 1000, 2000, 5000), 60, 300, 1.0),):
    Xmax = max(Xs)
    C = [P for P in gen2(n, 50, Xmax, kmin=3, kmax=10, omax=6, max_primes=11, tau_min=tlo) if tau(P) < thi]
    random.seed(n); sub = C if frac >= 1 else random.sample(C, int(frac * len(C)))
    tot = np.zeros(len(Xs)); tots = np.zeros(len(Xs))
    for P in sub:
        r = gmodel.eval_P(P, n, Xmax * 1.0001, npts=40)
        if r is None: continue
        tot += np.array([gmodel.cum(r["S"], r["lEm_lin"], X) for X in Xs]); tots += np.array([gmodel.cum(r["S"], r["lEs_lin"], X) for X in Xs])
        maxent._div_cache.clear()
    tot *= len(C) / max(len(sub), 1); tots *= len(C) / max(len(sub), 1)
    print(f"n={n}: {len(C)} P with tau in [{tlo},{thi}) and scale <= {Xmax}: N_magic at X={Xs}: {np.round(tot,4)}; N_semi: {np.array([float('%.3g'%x) for x in tots])}", flush=True)
save()
