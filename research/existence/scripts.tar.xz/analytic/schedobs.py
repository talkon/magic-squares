"""Observed squares per sum vs scheduler model vs analytic model, binned by N (all n=6 sum records)."""
import os, sys, json, math, collections
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
sys.path.insert(0, "/home/user/magic-squares/scripts")
import numpy as np, scheduler as sch
from model import assemble
from gmodel import lK
SP = "/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad"
M = sch.Model.load(SP + "/forecast/state/model_6.json")
c = json.load(open("calib3.json"))
B = collections.defaultdict(lambda: [0, 0, 0.0, 0.0])
for r in c:
    a = assemble(r["comp"], edge=False)
    pa = math.exp(a["logEsemi"] + lK(r["comp"]["ld_n2"], 6, "lin"))
    ps = M.squares(list(r["P"]), r["S"], r["N"], r["smin"])
    N = r["N"]; k = 0 if N < 1000 else 1 if N < 2000 else 2 if N < 3000 else 3 if N < 5000 else 4
    b = B[k]; b[0] += 1; b[1] += r["sq"]; b[2] += pa; b[3] += ps
names = ["<1000", "1000-2000", "2000-3000", "3000-5000", "5000-8000"]
for k in sorted(B):
    b = B[k]; print(f"N {names[k]:10s} sums {b[0]:6d}  observed {b[1]:6d}  analytic {b[2]:9.1f}  scheduler {b[3]:9.1f}")
for r in sorted(c, key=lambda r: -r["N"])[:6]:
    a = assemble(r["comp"], edge=False)
    print(r["P"], r["S"], "N", r["N"], "obs", r["sq"], "analytic %.0f" % math.exp(a["logEsemi"] + lK(r["comp"]["ld_n2"], 6, "lin")), "sched %.0f" % M.squares(list(r["P"]), r["S"], r["N"], r["smin"]))
