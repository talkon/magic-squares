import json, math, numpy as np, collections
d = json.load(open("calib1.json"))
byP = collections.defaultdict(lambda: [0, 0.0, 0, 0.0])
for r in d:
    b = byP[tuple(r["P"])]
    b[0] += r["sq"]; b[1] += math.exp(r["logE_semi"]); b[2] += 1
rows = []
for P, (o, e, ns, _) in byP.items():
    ones = sum(1 for a in P if a == 1); twos = sum(1 for a in P if a == 2)
    rows.append((P, o, e, ns, ones, twos))
rows.sort(key=lambda t: t[1] / max(t[2], 1e-9))
for P, o, e, ns, ones, twos in rows:
    if o >= 5:
        print(f"{' '.join(map(str,P)):22s} obs {o:5d} pred {e:10.1f} ratio {o/e:.5f} ones {ones} twos {twos} k {sum(1 for a in P if a)}")
# group by number of a_p=1
g = collections.defaultdict(lambda: [0, 0.0])
for P, o, e, ns, ones, twos in rows:
    g[ones][0] += o; g[ones][1] += e
print({k: (v[0], round(v[1]), round(v[0]/v[1], 5)) for k, v in sorted(g.items())})
g = collections.defaultdict(lambda: [0, 0.0])
for P, o, e, ns, ones, twos in rows:
    g[sum(1 for a in P if a)][0] += o; g[sum(1 for a in P if a)][1] += e
print("by k", {k: (v[0], round(v[1]), round(v[0]/v[1], 5)) for k, v in sorted(g.items())})
