import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json, math, numpy as np
from model import assemble
d = json.load(open("calib3.json"))
sq = np.array([r["sq"] for r in d], float)
A = [assemble(r["comp"], edge=False) for r in d]
lE = np.array([a["logEsemi"] for a in A]); ld = np.array([r["comp"]["ld_n2"] for r in d])
N = np.array([r["N"] for r in d])
def poisson(X, y, off):
    b = np.zeros(X.shape[1]); b[0] = math.log(y.sum() / np.exp(off).sum())
    for it in range(200):
        mu = np.exp(X @ b + off)
        st = np.linalg.solve((X * mu[:, None]).T @ X + 1e-9 * np.eye(len(b)), X.T @ (y - mu))
        b += st
        if np.abs(st).max() < 1e-10: break
    mu = np.exp(X @ b + off)
    cov = np.linalg.inv((X * mu[:, None]).T @ X)
    dev = 2 * np.sum(np.where(y > 0, y * np.log(np.maximum(y, 1e-300) / mu), 0) - (y - mu))
    return b, np.sqrt(np.diag(cov)), dev
m = lE > -15
one = np.ones(m.sum())
for name, X in [("const", np.stack([one], 1)),
                ("ld", np.stack([one, ld[m]], 1)),
                ("ld^2", np.stack([one, ld[m] ** 2], 1)),
                ("ld, ld^2", np.stack([one, ld[m], ld[m] ** 2], 1)),
                ("ld^2, logE", np.stack([one, ld[m] ** 2, lE[m]], 1))]:
    b, s, dev = poisson(X, sq[m], lE[m])
    print(f"{name:12s} coef {np.round(b, 4)} se {np.round(s, 4)} deviance {dev:.1f}")
json.dump(dict(), open("/dev/null", "w"))
