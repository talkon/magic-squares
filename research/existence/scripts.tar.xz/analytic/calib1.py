import sys, math, json, time
import numpy as np
from load import load
from maxent import predict, norm
sums, squares = load()
out = []
t0 = time.time()
keys = sorted(sums)
for i, (P, S) in enumerate(keys):
    r = sums[(P, S)]
    o = predict(P, S)
    out.append(dict(P=P, S=S, N=r["nvecs_raw"], nred=r["nvecs"], labels=r.get("labels"), sq=r["squares"],
                    time=r["time"], **{k: float(v) for k, v in o.items()}))
    if i % 2000 == 0: print(i, time.time() - t0, file=sys.stderr)
json.dump(out, open("calib1.json", "w"))
