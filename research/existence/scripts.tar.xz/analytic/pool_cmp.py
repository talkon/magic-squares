"""Analytic model evaluated on the empirical forecast's candidate pool (scheduler.gen_candidates(6):
2^8-18 3^3-9 5^2-6 7^1-4 (nonincreasing), <= 2 of 11,13,17,19 with exponent 1, tau 800-12000),
sums S_min < S <= f S_min for f = 1.5, 1.8, 4. Stratified (floor log2 tau) random sample."""
import os, sys, json, math, random, collections, time
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import numpy as np, gmodel, maxent
from smin import save
def tau(P):
    t = 1
    for e in P: t *= e + 1
    return t
def norm_p(P):
    P = list(P)
    while P and P[-1] == 0: P.pop()
    return tuple(P)
def gen(tau_min=800, tau_max=12000, mb=2):
    out = set()
    for e2 in range(8, 19):
        for e3 in range(3, 10):
            if e3 > e2: continue
            for e5 in range(2, 7):
                if e5 > e3: continue
                for e7 in range(1, 5):
                    if e7 > e5: continue
                    for mask in range(16):
                        tail = [(mask >> i) & 1 for i in range(4)]
                        if sum(tail) > mb: continue
                        P = norm_p([e2, e3, e5, e7] + tail)
                        if tau_min <= tau(P) <= tau_max: out.add(P)
    return sorted(out)
frac = float(sys.argv[1]) if len(sys.argv) > 1 else 0.12
C = gen(); print("pool", len(C), file=sys.stderr)
st = collections.defaultdict(list)
for P in C: st[int(math.log2(tau(P)))].append(P)
random.seed(77); res = []; t0 = time.time()
FS = (1.3, 1.5, 1.8, 4.0)
for k in sorted(st):
    m = max(3, int(round(frac * len(st[k]))))
    for P in random.sample(st[k], min(m, len(st[k]))):
        r = gmodel.eval_P(P, 6, 1e12, fmax=4.0, npts=30)
        if r is None: continue
        s0 = r["smin"]
        row = dict(P=P, k=k, smin=s0)
        for f in FS:
            row["m%.1f" % f] = gmodel.cum(r["S"], r["lEm_lin"], f * s0)
            row["s%.1f" % f] = gmodel.cum(r["S"], r["lEs_lin"], f * s0)
        res.append(row); maxent._div_cache.clear()
        if len(res) % 100 == 0: print(len(res), round(time.time() - t0), file=sys.stderr, flush=True)
save()
out = {}
for f in FS:
    for kind in "ms":
        key = kind + "%.1f" % f; tot = 0.0; var = 0.0
        for k, Ps in st.items():
            v = np.array([r[key] for r in res if r["k"] == k])
            if len(v) == 0: continue
            tot += len(Ps) * v.mean()
            if len(v) > 1: var += len(Ps) ** 2 * v.var(ddof=1) / len(v) * (1 - len(v) / len(Ps))
        out[key] = (tot, math.sqrt(var))
print("pool size", len(C), "sampled", len(res))
for f in FS:
    a, b = out["m%.1f" % f], out["s%.1f" % f]
    print(f"S <= {f} S_min: E_magic = {a[0]:.4g} (se {a[1]:.2g}),  E_semi = {b[0]:.4g} (se {b[1]:.2g}),  mean P(magic|semi) = 1 in {b[0]/a[0]:.3g}")
json.dump(dict(pool=len(C), res=res, out=out), open("pool_cmp.json", "w"))
