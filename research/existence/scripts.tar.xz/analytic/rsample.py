import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import numpy as np, math
def p_disjoint(bits, n, samples=10**7, seed=2, chunk=10**6):
    """P(n distinct random vectors pairwise disjoint), bits: python ints (<=192 labels)"""
    N = len(bits)
    W = np.array([[(b >> (64 * w)) & ((1 << 64) - 1) for w in range(3)] for b in bits], dtype=np.uint64)
    rng = np.random.default_rng(seed)
    ok = 0; tot = 0
    while tot < samples:
        m = min(chunk, samples - tot)
        idx = np.stack([rng.integers(0, N, m) for _ in range(n)], 1)
        good = np.ones(m, bool)
        acc = W[idx[:, 0]].copy()
        for j in range(1, n):
            Wj = W[idx[:, j]]
            good &= ~np.any(acc & Wj, axis=1)
            acc |= Wj
        # exclude repeated indices (they'd overlap anyway since vectors nonempty)
        ok += int(good.sum()); tot += m
    return ok / tot, ok
