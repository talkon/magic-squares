"""All exponent vectors over the primes 2..PMAX (any order) with scale n*P^(1/n) <= X,
k >= kmin used primes, tau(P) >= tau_min.  Returns list of (logP, tau, P)."""
import math, sys
PR = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]
def gen3(n, X, tau_min, kmin=3, nprimes=12, amax=40):
    L = n * math.log(X / n)
    LP = [math.log(p) for p in PR[:nprimes]]
    out = []
    cur = [0] * nprimes
    def rec(i, lp, tau, k):
        if i == nprimes:
            if k >= kmin and tau >= tau_min:
                P = cur[:]
                while P and P[-1] == 0: P.pop()
                out.append((lp, tau, tuple(P)))
            return
        # prune: even with all remaining budget, tau can grow at most ... skip pruning on tau (cheap enough)
        a = 0
        while lp + a * LP[i] <= L + 1e-12 and a <= amax:
            cur[i] = a
            rec(i + 1, lp + a * LP[i], tau * (a + 1), k + (a > 0))
            a += 1
        cur[i] = 0
    rec(0, 0.0, 1, 0)
    return out
if __name__ == "__main__":
    import time
    n, X, tmin = int(sys.argv[1]), float(sys.argv[2]), int(sys.argv[3])
    np_ = int(sys.argv[4]) if len(sys.argv) > 4 else 12
    t = time.time(); c = gen3(n, X, tmin, nprimes=np_)
    print(n, X, tmin, len(c), round(time.time() - t, 1))
