import json, math, sys, collections, numpy as np
FIELDS = ("lEs_lin", "lEm_lin", "lEs_quad", "lEm_quad")
def est(d, field, perm=True):
    XG = np.array(d["XG"]); st = d["strata"]
    by = collections.defaultdict(list)
    for r in d["res"]: by["|".join(map(str, r["st"]))].append(np.array(r[field]))
    # permutation multiplier per field: ratio estimator over the perm subsample, per X
    num = np.zeros(len(XG)); den = np.zeros(len(XG))
    for r in d["res"]:
        if "perm" in r:
            num += np.array(r["perm"][field]); den += np.array(r[field])
    mult = np.where(den > 0, 1 + num / np.maximum(den, 1e-300), 1.0) if perm else np.ones(len(XG))
    tot = np.zeros(len(XG)); var = np.zeros(len(XG)); miss = 0
    hb = collections.defaultdict(list)
    for key, v in by.items(): hb[key.split("|")[0]].extend(v)
    for key, Nst in st.items():
        v = by.get(key)
        if not v:
            miss += Nst
            continue   # unsampled strata: only where phase-2 allocation was ~0 (negligible), counted as 0
        v = np.array(v); tot += Nst * v.mean(0)
        if len(v) > 1: var += Nst ** 2 * v.var(0, ddof=1) / len(v) * (1 - len(v) / Nst)
    return XG, tot * mult, np.sqrt(var) * mult, mult, miss
if __name__ == "__main__":
    d = json.load(open(sys.argv[1]))
    print("n", d["n"], "evaluated", len(d["res"]), "candidates", sum(d["strata"].values()),
          "perm subsample", sum(1 for r in d["res"] if "perm" in r))
    out = {}
    for f in FIELDS:
        XG, t, s, m, miss = est(d, f); out[f] = (t, s, m)
    print("   X      Nsemi(lin)   se     Nmagic(lin)   se     perm-mult(m)  Nsemi(quad)  Nmagic(quad)")
    for i, X in enumerate(XG):
        a = out["lEs_lin"]; b = out["lEm_lin"]; c = out["lEs_quad"]; e = out["lEm_quad"]
        if a[0][i] > 0:
            print(f"{X:8.0f}  {a[0][i]:10.3g} {a[1][i]:8.2g}  {b[0][i]:10.3g} {b[1][i]:8.2g}   {b[2][i]:5.2f}      {c[0][i]:10.3g}  {e[0][i]:10.3g}")
