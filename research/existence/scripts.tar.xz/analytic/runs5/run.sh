#!/bin/sh
cd "$(dirname "$0")"
rm -f all700.jsonl
while read -r line; do
  nice /home/user/magic-squares/bin/msearch --vec-size 5 --max-sum 700 --out all700.jsonl $line > /dev/null 2>> err.txt
done < list700.txt
echo done > done.txt
