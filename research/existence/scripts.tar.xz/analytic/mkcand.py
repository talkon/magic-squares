import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import sys, json, collections
from cands import gen
from screen import dnear
n, X, tmin, kmin, kmax, omax, mp, dmin, out = sys.argv[1:]
n, X, tmin, kmin, kmax, omax, mp, dmin = int(n), float(X), int(tmin), int(kmin), int(kmax), int(omax), int(mp), int(dmin)
c = gen(n, X, tmin, max_primes=mp)
c = [P for P in c if kmin <= sum(1 for a in P if a) <= kmax and sum(1 for a in P if a == 1) <= omax]
dn = [(dnear(P, n), P) for P in c]
dn = [t for t in dn if t[0] >= dmin]
print(n, X, len(c), "->", len(dn), sorted(collections.Counter(min(d // 20 * 20, 400) for d, P in dn).items()))
json.dump(dn, open(out, "w"))
