#!/bin/sh
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1
nice python3 gs3.py 6 50 50000 1000 50 110 0.12 gs3_n6.json 2> gs3_n6.err
nice python3 gs3.py 7 50 20000 2000 50 110 0.12 gs3_n7.json 2> gs3_n7.err
nice python3 gs3.py 8 50 10000 4000 50 110 0.12 gs3_n8.json 2> gs3_n8.err
nice python3 gs3.py 5 50 200000 300 50 110 0.12 gs3_n5.json 2> gs3_n5.err
echo queue2-done
