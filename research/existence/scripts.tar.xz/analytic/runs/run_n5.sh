#!/bin/sh
cd "$(dirname "$0")"
while read s0 rest; do
  nice /home/user/magic-squares/bin/msearch --vec-size 5 --min-sum $s0 --max-sum 3000 --time-limit 20 --out n5_survey.jsonl $rest > /dev/null 2>>n5.err
done < n5_list.txt
echo done
