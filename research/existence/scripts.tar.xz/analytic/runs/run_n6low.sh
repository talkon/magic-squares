#!/bin/sh
cd "$(dirname "$0")"
while read s0 rest; do
  nice /home/user/magic-squares/bin/msearch --vec-size 6 --min-sum $s0 --max-sum 400 --time-limit 30 --out n6low.jsonl $rest > /dev/null 2>>n6low.err
done < n6low_list.txt
echo done
