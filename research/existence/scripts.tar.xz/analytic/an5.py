import json, math, numpy as np, collections, sys
fn = sys.argv[1] if len(sys.argv) > 1 else "calib2.json"
d = json.load(open(fn))
N = np.array([r["N"] for r in d]); lN = np.log(N)
res = lN - np.array([r["logN"] for r in d])
print("vectors: log(N_obs/N_pred) mean %.3f sd %.3f" % (res.mean(), res.std()))
for lo, hi in [(5, 30), (30, 100), (100, 300), (300, 1000), (1000, 3000), (3000, 10000)]:
    mm = (N >= lo) & (N < hi)
    if mm.sum(): print(f"  N in [{lo},{hi}): n={mm.sum():5d} mean {res[mm].mean():+.3f} sd {res[mm].std():.3f}")
sq = np.array([r["sq"] for r in d]); E = np.exp([r["logEsemi"] for r in d])
print("squares obs/pred total %.4f  (obs %d, pred %.1f)" % (sq.sum() / E.sum(), sq.sum(), E.sum()))
def binrep(name, v, edges):
    print(name)
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (v >= lo) & (v < hi)
        if m.sum() and E[m].sum() > 0.5:
            print(f"   [{lo:8.3g},{hi:8.3g}) sums {m.sum():5d} obs {sq[m].sum():5d} pred {E[m].sum():9.1f} ratio {sq[m].sum()/E[m].sum():.4f}")
binrep("N", N, [0, 400, 700, 1000, 1500, 2500, 9000])
x = np.array([r["S"] / r["smin"] for r in d]); binrep("S/Smin", x, [1, 1.1, 1.2, 1.3, 1.45, 1.6, 1.8, 2.2, 4])
ld = np.array([r["ld_n2"] for r in d]); binrep("log P(36 distinct)", ld, [-40, -14, -12, -11, -10, -9, -8, -6])
lE = np.array([r["logEsemi"] for r in d]); binrep("log E_pred", lE, [-30, -6, -4, -3, -2, -1, 0, 1, 2, 3, 5])
g = collections.defaultdict(lambda: [0, 0.0]); gk = collections.defaultdict(lambda: [0, 0.0]); byP = collections.defaultdict(lambda: [0, 0.0])
for r, e in zip(d, E):
    P = tuple(r["P"]); ones = sum(1 for a in P if a == 1); k = sum(1 for a in P if a)
    g[ones][0] += r["sq"]; g[ones][1] += e; gk[k][0] += r["sq"]; gk[k][1] += e; byP[P][0] += r["sq"]; byP[P][1] += e
print("by #(a_p=1):", {k: (v[0], round(v[1]), round(v[0]/v[1], 4)) for k, v in sorted(g.items())})
print("by k:", {k: (v[0], round(v[1]), round(v[0]/v[1], 4)) for k, v in sorted(gk.items())})
rat = sorted((v[0] / v[1], P, v[0]) for P, v in byP.items() if v[0] >= 10)
lr = np.log([t[0] for t in rat])
print("per-P log ratio (>=10 squares): n=%d mean %.3f sd %.3f (Poisson-only sd ~ %.3f)" % (len(lr), lr.mean(), lr.std(), np.mean([1/math.sqrt(t[2]) for t in rat])))
# Poisson regression
m = lE > -12
X = np.stack([np.ones(m.sum()), lE[m], ld[m] - ld[m].mean()], axis=1); y = sq[m]
b = np.array([math.log(y.sum() / np.exp(lE[m]).sum()), 1.0, 0.0])
for it in range(60):
    mu = np.exp(X @ b); b += np.linalg.solve((X * mu[:, None]).T @ X + 1e-9 * np.eye(3), X.T @ (y - mu))
cov = np.linalg.inv((X * np.exp(X @ b)[:, None]).T @ X)
print("Poisson fit log mu = b0 + b1 logE + b2 (ld-mean):", np.round(b, 3), "se", np.round(np.sqrt(np.diag(cov)), 3))
