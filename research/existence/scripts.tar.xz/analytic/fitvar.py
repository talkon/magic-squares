import json, math, numpy as np, collections, sys
from model import assemble
d = json.load(open(sys.argv[1] if len(sys.argv) > 1 else "calib3.json"))
N = np.array([r["N"] for r in d]); sq = np.array([r["sq"] for r in d])
def poisson(X, y, off):
    b = np.zeros(X.shape[1]); b[0] = math.log(y.sum() / np.exp(off).sum())
    for it in range(100):
        mu = np.exp(X @ b + off)
        b += np.linalg.solve((X * mu[:, None]).T @ X + 1e-9 * np.eye(len(b)), X.T @ (y - mu))
    mu = np.exp(X @ b + off)
    cov = np.linalg.inv((X * mu[:, None]).T @ X)
    dev = 2 * np.sum(np.where(y > 0, y * np.log(np.maximum(y, 1e-300) / mu), 0) - (y - mu))
    return b, np.sqrt(np.diag(cov)), dev
for name, v in [("gauss+local", dict(edge=False)), ("gauss+edge+local", dict(edge=True)),
                ("gauss+local+condpairs", dict(edge=False, condpairs=True)),
                ("gauss only", dict(edge=False, local=False))]:
    A = [assemble(r["comp"], **v) for r in d]
    lNp = np.array([a["logN"] for a in A]); lE = np.array([a["logEsemi"] for a in A])
    res = np.log(N) - lNp
    ld = np.array([r["comp"]["ld_n2"] for r in d])
    m = lE > -15
    # fit 1: constant K only
    b0, s0, dev0 = poisson(np.ones((m.sum(), 1)), sq[m], lE[m])
    # fit 2: K + slope on logE + ld
    X = np.stack([np.ones(m.sum()), lE[m] - lE[m].mean(), ld[m] - ld[m].mean()], axis=1)
    b, s, dev = poisson(X, sq[m], lE[m])
    print(f"{name:24s} N: mean {res.mean():+.3f} sd {res.std():.3f} | squares: K={math.exp(b0[0]):.4f} dev {dev0:.0f} | "
          f"free: slope-1 {b[1]:+.3f}({s[1]:.3f}) ld-coef {b[2]:+.3f}({s[2]:.3f}) dev {dev:.0f}")
