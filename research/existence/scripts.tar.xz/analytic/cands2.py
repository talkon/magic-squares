"""Exponent tuples (nonincreasing over used primes, <=1 gap after the 4th prime) with
scale n*P^(1/n) in [Xlo, Xhi], k in [kmin,kmax], #(a=1) <= omax."""
import math
PR = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31]
LP = [math.log(p) for p in PR]
def gen2(n, Xlo, Xhi, kmin=4, kmax=8, omax=4, max_primes=10, tau_min=300):
    Llo = n * math.log(Xlo / n); Lhi = n * math.log(Xhi / n)
    out = []
    def rec(i, prev, L, tau, cur, gaps, k, ones):
        if k >= kmin and Llo <= L <= Lhi and tau >= tau_min and ones <= omax:
            P = list(cur)
            while P and P[-1] == 0: P.pop()
            out.append(tuple(P))
        if i == max_primes or k == kmax: return
        for a in range(min(prev, int((Lhi - L) / LP[i])), 0, -1):
            if ones + (a == 1) > omax: continue
            rec(i + 1, a, L + a * LP[i], tau * (a + 1), cur + [a], gaps, k + 1, ones + (a == 1))
        if gaps == 0 and i >= 4 and cur:
            rec(i + 1, prev, L, tau, cur + [0], 1, k, ones)
    rec(0, 10 ** 9, 0.0, 1, [], 0, 0, 0)
    return sorted(set(out))
if __name__ == "__main__":
    import sys, time
    t = time.time()
    c = gen2(int(sys.argv[1]), float(sys.argv[2]), float(sys.argv[3]), omax=int(sys.argv[4]))
    print(len(c), round(time.time() - t, 1))
