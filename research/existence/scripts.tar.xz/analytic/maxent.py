"""Maximum-entropy (saddle-point) estimates for vectors and squares.

For P = prod p^a_p and line sum S, put on the divisors d of P the tilted measure
  mu(d) ~ exp(-beta * d/(S/n) + sum_p lam_p e_p(d))
with (beta, lam) chosen so that E[d] = S/n and E[e_p] = a_p/n.  Then
  #(ordered n-tuples with sum S, product P) ~ e^{n H} / ((2pi)^{(1+k)/2} det(n C)^{1/2})
  #(ordered n x n grids, all lines sum S / product P) ~
      e^{n^2 H} / ((2pi)^{(2n-1)(1+k)/2} det(C)^{(2n-1)/2} n^{(n-1)(1+k)})
with H the entropy of mu and C the covariance of (d, e(d)) under mu.
"""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import math
import numpy as np

PRIMES = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53]


def norm(P):
    P = list(P)
    while P and P[-1] == 0:
        P.pop()
    return tuple(P)


_div_cache = {}


def divisors(P):
    """(d as float64 array, E exponent matrix tau x k over primes with a>0, a vector)"""
    P = norm(P)
    if P in _div_cache:
        return _div_cache[P]
    idx = [i for i, a in enumerate(P) if a > 0]
    ds = np.array([1.0])
    E = np.zeros((1, 0), dtype=np.int64)
    for i in idx:
        p, a = PRIMES[i], P[i]
        pw = np.array([float(p) ** j for j in range(a + 1)])
        ds = (ds[:, None] * pw[None, :]).ravel()
        E = np.concatenate([np.repeat(E, a + 1, axis=0),
                            np.tile(np.arange(a + 1), len(E))[:, None]], axis=1)
    a = np.array([P[i] for i in idx], dtype=float)
    _div_cache[P] = (ds, E.astype(float), a)
    return _div_cache[P]


def log_esym_distinct(logw, m):
    """log of m! * e_m(p) where p = exp(logw) is a probability vector:
    probability that m iid draws are all distinct."""
    # DP over items in log space on coefficients c_j = e_j(p), j<=m
    scale = logw.max()
    p = np.exp(logw - scale)
    p = p[p > 1e-14]
    # work with p scaled; e_m(p*s) = s^m e_m(p)
    c = np.zeros(m + 1)
    c[0] = 1.0
    logc_off = 0.0
    for x in p:
        if x < 1e-300:
            continue
        c[1:] = c[1:] + x * c[:-1]
        mx = c.max()
        if mx > 1e200:
            c /= mx
            logc_off += math.log(mx)
    # c[m] = e_m(p) * exp(-logc_off) where p were divided by exp(scale)? no: p = exp(logw-scale)
    if c[m] <= 0:
        return -np.inf
    log_em = math.log(c[m]) + logc_off + m * scale
    return math.lgamma(m + 1) + log_em


def solve(P, S, n=6, tol=1e-10, maxit=200):
    ds, E, a = divisors(P)
    k = len(a)
    u = ds / (S / n)
    keep = u < 60  # weights beyond are negligible once beta >~ 1
    X = np.concatenate([-u[:, None], E], axis=1)  # features
    target = np.concatenate([[-1.0], a / n])
    th = np.zeros(1 + k)
    th[0] = 1.0
    def f(th):
        z = X @ th
        zm = z.max()
        w = np.exp(z - zm)
        Z = w.sum()
        return math.log(Z) + zm - th @ target, w / Z
    val, w = f(th)
    for it in range(maxit):
        m = w @ X
        g = m - target
        Xc = X - m
        Hs = (Xc * w[:, None]).T @ Xc
        try:
            step = np.linalg.solve(Hs + 1e-12 * np.eye(1 + k), g)
        except np.linalg.LinAlgError:
            step = np.linalg.lstsq(Hs, g, rcond=None)[0]
        t = 1.0
        while True:
            nv, nw = f(th - t * step)
            if nv <= val - 1e-4 * t * (g @ step) or t < 1e-10:
                break
            t *= 0.5
        th = th - t * step
        val, w = nv, nw
        if np.abs(g).max() < tol:
            break
    # entropy H = -sum w log w = log Z - th.(E X) ; at optimum E X = target
    H = val  # since val = log Z - th.target and E[X]=target at optimum
    m = w @ X
    Xc = X - m
    Cs = (Xc * w[:, None]).T @ Xc  # covariance of (-u, e)
    # covariance of (d, e): d = (S/n) u
    D = np.diag(np.concatenate([[-S / n], np.ones(k)]))
    C = D @ Cs @ D
    logw = np.log(np.maximum(w, 1e-320))
    return dict(H=H, C=C, k=k, w=w, logw=logw, th=th, ds=ds, E=E, a=a,
                resid=float(np.abs(m - target).max()))


def predict(P, S, n=6, distinct=True):
    r = solve(P, S, n)
    k, C, H = r["k"], r["C"], r["H"]
    sign, logdetC = np.linalg.slogdet(C)
    L2P = math.log(2 * math.pi)
    log_tuples = n * H - 0.5 * (1 + k) * L2P - 0.5 * ((1 + k) * math.log(n) + logdetC)
    log_grids = (n * n * H - 0.5 * (2 * n - 1) * (1 + k) * L2P
                 - 0.5 * (2 * n - 1) * logdetC - (n - 1) * (1 + k) * math.log(n))
    out = dict(H=H, k=k, logdetC=logdetC, resid=r["resid"],
               varD=C[0, 0], log_tuples=log_tuples, log_grids=log_grids)
    ld_n = log_esym_distinct(r["logw"], n) if distinct else 0.0
    ld_n2 = log_esym_distinct(r["logw"], n * n) if distinct else 0.0
    out["ld_n"], out["ld_n2"] = ld_n, ld_n2
    out["logN"] = log_tuples + ld_n - math.lgamma(n + 1)
    out["logN_nodist"] = log_tuples - math.lgamma(n + 1)
    out["logE_semi"] = log_grids + ld_n2 - math.log(2) - 2 * math.lgamma(n + 1)
    out["logE_semi_nodist"] = log_grids - math.log(2) - 2 * math.lgamma(n + 1)
    # traversal probabilities (Gaussian, conditional on rows and cols)
    Ce = C[1:, 1:]
    ldCe = np.linalg.slogdet(Ce)[1] if k > 0 else 0.0
    out["log_pS"] = -0.5 * (math.log(2 * math.pi * (n - 1)) + math.log(C[0, 0]))
    out["log_pP"] = -0.5 * (k * math.log(2 * math.pi * (n - 1)) + ldCe)
    out["log_pSP"] = -0.5 * ((1 + k) * math.log(2 * math.pi * (n - 1)) + logdetC)
    out["perp"] = math.exp(H)
    return out


if __name__ == "__main__":
    import sys
    P = tuple(int(x) for x in sys.argv[1].split(","))
    for S in map(int, sys.argv[2:]):
        o = predict(P, S)
        print(S, {k: (round(v, 4) if isinstance(v, float) else v) for k, v in o.items()})
