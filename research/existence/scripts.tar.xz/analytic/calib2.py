import sys, math, json, time
from load import load
from model import model
from smin import smin, save
sums, squares = load()
out = []
t0 = time.time()
for i, (P, S) in enumerate(sorted(sums)):
    r = sums[(P, S)]
    o = model(P, S, 6)
    out.append(dict(P=P, S=S, N=r["nvecs_raw"], sq=r["squares"], smin=smin(P), time=r["time"],
                    **{k: float(v) for k, v in o.items()}))
    if i % 4000 == 0: print(i, time.time() - t0, file=sys.stderr)
save()
json.dump(out, open("calib2.json", "w"))
