"""Exhaustive 5x5 search (all sorted-exponent P with scale <= 700, every S <= 700) vs model."""
import json, math, collections, numpy as np
pred = {tuple(r["P"]): r for r in json.load(open("n5low_700.json"))}
sq = []; done = set(); tsum = 0.0; nsum = 0; Nmax = 0
for line in open("runs5/all700.jsonl"):
    r = json.loads(line); t = r.get("type")
    if t == "square": sq.append(r)
    elif t == "done": done.add(tuple(r["P"]))
    elif t == "sum": tsum += r["time"]; nsum += 1; Nmax = max(Nmax, r["nvecs_raw"])
print("P done", len(done), "of", len(pred), "; sums", nsum, "search time %.0f s" % tsum, "max N", Nmax)
print("squares found", len(sq))
for r in sorted(sq, key=lambda r: r["S"]):
    g = r["grid"]; mx = max(max(row) for row in g) if isinstance(g[0], list) else max(g)
    print("  S", r["S"], "P", r["P"], "max entry", mx, "s/p/sp", r.get("s_count"), r.get("p_count"), r.get("sp_count"), "best", r.get("best_score"))
# predicted vs observed by S threshold, using the model's per-P cum at 500 and 700
import gmodel
for X in (400, 500, 600, 700):
    o = sum(1 for r in sq if r["S"] <= X)
    print(f"S <= {X}: observed {o}")
tot700 = sum(r["Es"] for r in pred.values())
p500 = json.load(open("n5low_500.json")); tot500 = sum(r["Es"] for r in p500)
print("model (lin), same P set: N_semi(<=500) = %.2f, N_semi(<=700) = %.2f" % (tot500, tot700))
# traversal stats
S_ = sum(r.get("s_count", 0) for r in sq); P_ = sum(r.get("p_count", 0) for r in sq); SP_ = sum(r.get("sp_count", 0) for r in sq)
print("traversals with magic S / P / SP over all squares:", S_, P_, SP_, "(120 traversals per square)")
