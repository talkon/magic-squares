import json, math, numpy as np
d = json.load(open("calib1c.json"))
sq = np.array([r["sq"] for r in d]); E = np.exp([r["logE_c"] for r in d])
def binrep(name, v, edges):
    print(name)
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (v >= lo) & (v < hi)
        if m.sum() and E[m].sum() > 1:
            print(f"   [{lo:8.3g},{hi:8.3g}) sums {m.sum():5d} obs {sq[m].sum():5d} pred {E[m].sum():9.1f} ratio {sq[m].sum()/E[m].sum():.4f}")
ld = np.array([r["ld_n2"] for r in d]); binrep("log P(36 distinct)", ld, [-40, -20, -16, -14, -12, -11, -10, -9, -8, -6])
H = np.array([r["H"] for r in d]); binrep("entropy H (log perplexity)", H, [3, 3.8, 4.0, 4.2, 4.4, 4.6, 4.8, 5.0, 5.5])
S = np.array([r["S"] for r in d]); binrep("S", S, [0, 400, 500, 600, 700, 800, 900, 1100, 1500, 3000])
lE = np.array([r["logE_c"] for r in d]); binrep("log E_pred", lE, [-30, -6, -4, -3, -2, -1, 0, 1, 2, 4])
# Poisson regression of sq on log E_pred, ld, H
X = np.stack([np.ones(len(d)), lE, ld - ld.mean()], axis=1)
m = lE > -12
X = X[m]; y = sq[m]
b = np.zeros(X.shape[1]); b[1] = 1.0; b[0] = math.log(y.sum() / np.exp(lE[m]).sum())
for it in range(50):
    mu = np.exp(X @ b)
    g = X.T @ (y - mu); Hs = (X * mu[:, None]).T @ X
    b += np.linalg.solve(Hs + 1e-9 * np.eye(len(b)), g)
cov = np.linalg.inv((X * np.exp(X @ b)[:, None]).T @ X)
print("Poisson fit log mu = b0 + b1 logE + b2 (ld - mean):", np.round(b, 3), "se", np.round(np.sqrt(np.diag(cov)), 3))
