import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json, math, numpy as np, collections
from model import assemble
d = json.load(open("calib3.json"))
sq = np.array([r["sq"] for r in d], float)
A = [assemble(r["comp"], edge=False) for r in d]
lE = np.array([a["logEsemi"] for a in A]); ld = np.array([r["comp"]["ld_n2"] for r in d])
x = np.log(np.array([r["S"] / r["smin"] for r in d])); lN = np.log(np.array([r["N"] for r in d], float))
Ps = sorted({tuple(r["P"]) for r in d}); pidx = {P: i for i, P in enumerate(Ps)}
pi = np.array([pidx[tuple(r["P"])] for r in d])
m = (lE > -15)
# keep only P with >= 5 squares for FE
cnt = collections.Counter(); 
for i in np.nonzero(m)[0]: cnt[pi[i]] += sq[i]
m &= np.array([cnt[p] >= 5 for p in pi])
def poisson_fe(Xc, y, off, groups, iters=300):
    G = groups.max() + 1
    b = np.zeros(Xc.shape[1]); a = np.zeros(G)
    for it in range(iters):
        eta = Xc @ b + a[groups] + off
        mu = np.exp(eta)
        # update group effects exactly
        so = np.bincount(groups, y, G); se = np.bincount(groups, mu * np.exp(-a[groups]), G)
        a = np.log(np.maximum(so, 1e-300) / se)
        mu = np.exp(Xc @ b + a[groups] + off)
        # demeaned Newton for b
        W = mu
        gm = np.bincount(groups, W, G)
        Xbar = np.stack([np.bincount(groups, W * Xc[:, j], G) / np.maximum(gm, 1e-300) for j in range(Xc.shape[1])], 1)
        Xd = Xc - Xbar[groups]
        g = Xd.T @ (y - mu); H = (Xd * W[:, None]).T @ Xd
        st = np.linalg.solve(H + 1e-9 * np.eye(len(b)), g)
        b += st
        if np.abs(st).max() < 1e-9: break
    se_b = np.sqrt(np.diag(np.linalg.inv(H)))
    return b, se_b
gr = np.unique(pi[m], return_inverse=True)[1]
for name, cols in [("ld", [ld]), ("ld, x", [ld, x]), ("ld, lN", [ld, lN]), ("lE", [lE]), ("ld, lE", [ld, lE])]:
    Xc = np.stack([c[m] for c in cols], 1)
    b, s = poisson_fe(Xc, sq[m], lE[m], gr)
    print(f"FE {name:8s} coef {np.round(b, 3)} se {np.round(s, 3)}")
