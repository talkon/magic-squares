"""Analytic model evaluated on the empirical forecast's candidate pool (scheduler.gen_candidates(6):
2^8-18 3^3-9 5^2-6 7^1-4 (nonincreasing), <= 2 of 11,13,17,19 with exponent 1, tau 800-12000),
sums S_min < S <= f S_min for f = 1.5, 1.8, 4. Stratified (floor log2 tau) random sample."""
import os, sys, json, math, random, collections, time
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import numpy as np, gmodel, maxent
from smin import save
def tau(P):
    t = 1
    for e in P: t *= e + 1
    return t
def norm_p(P):
    P = list(P)
    while P and P[-1] == 0: P.pop()
    return tuple(P)
def gen(tau_min=800, tau_max=12000, mb=2):
    out = set()
    for e2 in range(8, 19):
        for e3 in range(3, 10):
            if e3 > e2: continue
            for e5 in range(2, 7):
                if e5 > e3: continue
                for e7 in range(1, 5):
                    if e7 > e5: continue
                    for mask in range(16):
                        tail = [(mask >> i) & 1 for i in range(4)]
                        if sum(tail) > mb: continue
                        P = norm_p([e2, e3, e5, e7] + tail)
                        if tau_min <= tau(P) <= tau_max: out.add(P)
    return sorted(out)
