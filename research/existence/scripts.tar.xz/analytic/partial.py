"""Exact counts of partial structures: R = n pairwise-disjoint rows,
(R, C1): plus a column vector meeting every row once,
(R, C1, C2): plus a second, disjoint column vector meeting every row once.
Compared with max-entropy predictions."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import sys, math, itertools, numpy as np
from smallcount import vectors
from maxent import solve, log_esym_distinct
from corr import logc

def build(V):
    labs = sorted({x for v in V for x in v}); idx = {x: i for i, x in enumerate(labs)}
    bits = [sum(1 << idx[x] for x in v) for v in V]
    return labs, idx, bits

def count_systems(Cbits, Vbits, n, other=None):
    """number of sets of n pairwise-disjoint vectors, each meeting C in exactly one
    element (distinct elements, so one per element of C); if other is given each must
    also meet `other` in exactly one element."""
    elems = [1 << i for i in range(Cbits.bit_length()) if Cbits >> i & 1]
    lists = []
    for e in elems:
        L = [b for b in Vbits if (b & Cbits) == e and (other is None or bin(b & other).count("1") == 1)]
        lists.append(L)
    order = sorted(range(n), key=lambda i: len(lists[i]))
    cnt = 0
    def rec(j, used):
        nonlocal cnt
        if j == n:
            cnt += 1; return
        for b in lists[order[j]]:
            if not (b & used):
                rec(j + 1, used | b)
    rec(0, 0)
    return cnt

def exact(P, S, n, samples=200000, seed=1):
    V = vectors(P, S, n); N = len(V)
    labs, idx, bits = build(V)
    # (R, C1): sum over C of systems
    RC1 = sum(count_systems(c, bits, n) for c in bits)
    # (R, C1, C2), C1 != C2 ordered, disjoint
    RC2 = 0
    for i, c1 in enumerate(bits):
        for j, c2 in enumerate(bits):
            if i != j and not (c1 & c2):
                RC2 += count_systems(c1, bits, n, other=c2)
    # R: sample
    rng = np.random.default_rng(seed)
    ok = 0
    barr = np.array(bits, dtype=object)
    for _ in range(samples):
        rows = rng.choice(N, n, replace=False)
        u = 0; good = True
        for r in rows:
            if bits[r] & u: good = False; break
            u |= bits[r]
        ok += good
    R = math.comb(N, n) * ok / samples
    return dict(N=N, R=R, R_ok=ok, RC1=RC1, RC2=RC2)

def predict(P, S, n):
    r = solve(P, S, n)
    k, C, H = r["k"], r["C"], r["H"]; q = 1 + k
    ldC = np.linalg.slogdet(C)[1]
    L2P = math.log(2 * math.pi)
    ld = log_esym_distinct(r["logw"], n * n)
    locv = sum(logc("vec", n, a) for a in P if a > 0)
    locT = sum(logc("T", n, a) for a in P if a > 0)
    base = n * n * H + ld
    out = {}
    # rows only: n independent lines
    g = -0.5 * n * q * L2P - 0.5 * n * ldC - 0.5 * q * n * math.log(n)
    out["R"] = base + g + n * locv - math.lgamma(n + 1) - n * math.lgamma(n + 1)
    # rows + 1 col
    g1 = -0.5 * (n + 1) * q * L2P - 0.5 * (n + 1) * ldC - 0.5 * q * (n * math.log(n) + math.log(n - 1))
    out["RC1"] = base + g1 + n * locv + locT - math.lgamma(n + 1) - n * math.lgamma(n)
    # rows + 2 cols
    g2 = -0.5 * (n + 2) * q * L2P - 0.5 * (n + 2) * ldC - 0.5 * q * (n * math.log(n) + math.log(n * (n - 2)))
    out["RC2"] = base + g2 + n * locv + 2 * locT - math.lgamma(n + 1) - n * math.lgamma(n - 1)
    return {k: math.exp(v) for k, v in out.items()}

if __name__ == "__main__":
    n = int(sys.argv[1]); P = tuple(int(x) for x in sys.argv[2].split(","))
    for S in map(int, sys.argv[3:]):
        ex = exact(P, S, n); pr = predict(P, S, n)
        print(S, "N", ex["N"], " ".join(f"{k}: exact {ex[k]:.4g} pred {pr[k]:.4g} ratio {ex[k]/pr[k]:.3f}" for k in ("R", "RC1", "RC2")),
              f"(R from {ex['R_ok']} hits)", flush=True)
