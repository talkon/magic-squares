#!/bin/sh
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1
while [ ! -s gs3_n6.json ]; do sleep 10; done
nice python3 gs3.py 7 50 20000 2000 40 80 0.10 gs3_n7.json 22 2> gs3_n7.err
nice python3 gs3.py 8 50 10000 4000 40 80 0.10 gs3_n8.json 22 2> gs3_n8.err
nice python3 gs3.py 5 50 200000 300 40 80 0.10 gs3_n5.json 22 2> gs3_n5.err
echo queue3-done
