import json, math, numpy as np, collections
from model import assemble
from gmodel import lK
c = json.load(open("calib3.json"))
rows = []
for r in c:
    a = assemble(r["comp"], edge=False)
    lE = a["logEsemi"] + lK(r["comp"]["ld_n2"], 6, "lin")
    rows.append((r["N"], r["S"] / r["smin"], r["sq"], math.exp(lE), r["P"], r["time"]))
def show(key, edges, label):
    print(label)
    for lo, hi in zip(edges[:-1], edges[1:]):
        sel = [x for x in rows if lo <= key(x) < hi]
        if not sel: continue
        o = sum(x[2] for x in sel); p = sum(x[3] for x in sel)
        print(f"  [{lo},{hi}): sums {len(sel):6d}  obs {o:6d}  pred {p:9.1f}  obs/pred {o/p if p else float('nan'):.2f}  (Poisson 1-sigma {1/math.sqrt(max(o,1)):.2f})")
show(lambda x: x[0], [0, 300, 1000, 2000, 3000, 4000, 5000, 6000, 8000, 12000, 1e9], "by N (vectors per sum)")
show(lambda x: x[1], [1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 1.7, 2.0, 9], "by S/S_min")
# large-N sums: per-P
big = collections.defaultdict(lambda: [0, 0.0, 0])
for x in rows:
    if x[0] >= 4000: b = big[tuple(x[4])]; b[0] += x[2]; b[1] += x[3]; b[2] += 1
print("P with N>=4000 sums: P, #sums, obs, pred")
for P, b in sorted(big.items(), key=lambda t: -t[1][1])[:25]: print("  ", P, b[2], b[0], round(b[1], 1))
