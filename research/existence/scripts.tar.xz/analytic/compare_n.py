"""Compare observed squares (msearch jsonl, any n) with the gauss+local model and
the packing-calibrated version."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import sys, json, math, collections, numpy as np
from batch import batch
def load_runs(files):
    sums = {}
    for f in files:
        for l in open(f):
            r = json.loads(l)
            if r["type"] == "sum" and not r.get("truncated"):
                sums[(tuple(r["P"]), r["S"], r["n"])] = (r["squares"], r["nvecs_raw"])
    return sums
def predict(sums, step=1):
    byP = collections.defaultdict(list)
    for (P, S, n) in sums: byP[(P, n)].append(S)
    out = {}
    for (P, n), Ss in byP.items():
        Ss = sorted(Ss)
        for i in range(0, len(Ss), 150):
            chunk = np.array(Ss[i:i + 150])
            o = batch(P, chunk, n)
            for j, S in enumerate(chunk):
                out[(P, int(S), n)] = dict(lE=float(o["logEsemi"][j]), ld=float(o["ld_n2"][j]), lN=float(o["logN"][j]),
                                           lEm=float(o["logEmagic"][j]), lpS=float(o["lpS"][j]), lpP=float(o["lpP"][j]),
                                           lpSP=float(o["lpSP"][j]))
    return out
if __name__ == "__main__":
    files = sys.argv[1:]
    sums = load_runs(files)
    pr = predict(sums)
    json.dump({"|".join(map(str, [",".join(map(str, k[0])), k[1], k[2]])): dict(obs=sums[k][0], N=sums[k][1], **pr[k]) for k in sums},
              open("compare_" + os.path.basename(files[0]) + ".json", "w"))
    obs = sum(v[0] for v in sums.values())
    E = np.array([math.exp(pr[k]["lE"]) for k in sums]); ld = np.array([pr[k]["ld"] for k in sums])
    o = np.array([sums[k][0] for k in sums])
    lN = np.array([pr[k]["lN"] for k in sums]); Nobs = np.array([sums[k][1] for k in sums])
    mN = Nobs >= 20
    print("sums", len(sums), "N: log(obs/pred) mean %.3f sd %.3f" % (np.mean(np.log(Nobs[mN]) - lN[mN]), np.std(np.log(Nobs[mN]) - lN[mN])))
    print("squares obs", obs, "pred gauss+local %.3f" % E.sum())
    for k0, k2 in ((-1.087, -0.0091),):
        K = np.exp(k0 + k2 * ld ** 2)
        print("  calibrated (k0=%.3f, k2=%.4f): pred %.3f   K-weighted mean ld %.1f" % (k0, k2, (E * K).sum(), (E * K * ld).sum() / (E * K).sum()))
    # ld distribution where predicted squares are
    w = E / E.sum()
    print("  ld quantiles weighted by pred:", np.round([ld[np.argsort(ld)][np.searchsorted(np.cumsum(w[np.argsort(ld)]), q)] for q in (0.1, 0.5, 0.9)], 1))
