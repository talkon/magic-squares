"""Sequential importance sampling estimate of P(n random vectors pairwise disjoint)
vs the iid-cell prediction exp(ld_{n^2} - n ld_n)."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import sys, math, numpy as np
from smallcount import vectors
from maxent import solve, log_esym_distinct
def sis(V, n, trials=4000, seed=3):
    labs = sorted({x for v in V for x in v}); idx = {x: i for i, x in enumerate(labs)}
    N = len(V)
    M = np.zeros((N, len(labs)), dtype=bool)
    for t, v in enumerate(V):
        for x in v: M[t, idx[x]] = True
    rng = np.random.default_rng(seed)
    logs = []
    for _ in range(trials):
        used = np.zeros(len(labs), bool)
        lw = 0.0
        avail = np.ones(N, bool)
        for j in range(n):
            if j > 0:
                avail = ~(M[:, used].any(1))
            c = int(avail.sum())
            if c == 0: lw = -np.inf; break
            lw += math.log(c / N)
            pick = rng.choice(np.nonzero(avail)[0])
            used |= M[pick]
        logs.append(lw)
    logs = np.array(logs)
    mx = logs[np.isfinite(logs)].max()
    est = mx + math.log(np.mean(np.exp(logs - mx)))
    # ordered sequences -> P(n iid uniform vectors pairwise disjoint) (distinct automatically)
    return est
if __name__ == "__main__":
    n = int(sys.argv[1]); P = tuple(int(x) for x in sys.argv[2].split(","))
    for S in map(int, sys.argv[3:]):
        V = vectors(P, S, n)
        est = sis(V, n)
        r = solve(P, S, n)
        pred = log_esym_distinct(r["logw"], n * n) - n * log_esym_distinct(r["logw"], n)
        print(n, P, S, "N", len(V), "log P(disjoint) SIS %.2f  iid-pred %.2f  diff %.2f" % (est, pred, est - pred), flush=True)
