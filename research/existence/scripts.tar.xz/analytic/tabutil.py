import json, math, sys, numpy as np
from gs3_est import est
def interp(XG, N, X):
    XG = np.asarray(XG); N = np.asarray(N)
    if X <= XG[0]: return N[0]
    if X >= XG[-1]: return N[-1]
    i = np.searchsorted(XG, X)
    a, b = N[i - 1], N[i]
    if a <= 0 or b <= 0: return a + (b - a) * (X - XG[i - 1]) / (XG[i] - XG[i - 1])
    t = math.log(X / XG[i - 1]) / math.log(XG[i] / XG[i - 1])
    return math.exp(math.log(a) + t * math.log(b / a))
def xcross(XG, N, target):
    for i in range(1, len(XG)):
        if N[i - 1] > 0 and N[i - 1] < target <= N[i]:
            t = math.log(target / N[i - 1]) / math.log(N[i] / N[i - 1])
            return math.exp(math.log(XG[i - 1]) + t * math.log(XG[i] / XG[i - 1]))
    return None
