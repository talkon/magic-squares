import json, math, numpy as np, sys
sys.path.insert(0, "/home/user/magic-squares/scripts")
import scheduler as sch
d = json.load(open("frontier_segs.json")); A = np.array(d["segs"])
w, Em, Es, ns, N = A.T
MULT = 1.77   # exponent-permutation multiplier (gs3 ratio estimator)
M = sch.Model.load("/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/forecast/state/model_6.json")
a0, al = -34.207, 4.722
q = [-62.5880689, 12.6569606, -0.55401924]
def t_pow(N): return np.exp(a0 + al * np.log(N))
def t_quad(N):
    L = np.log(np.minimum(N, 8000.0)); t = np.exp(q[0] + q[1] * L + q[2] * L * L)
    return t * np.where(N > 8000, (N / 8000.0) ** 2.7, 1.0)
def t_sched(N): return np.array([M.sum_time(x) for x in N])
def t_alpha(alpha, N0=2000.0):
    def f(N): return np.where(N <= N0, t_pow(N), t_pow(N0) * (N / N0) ** alpha)
    return f
models = [("power N^4.72 (fit, N<8k data)", t_pow), ("data-curved (N^2.7 at 8k)", t_quad), ("scheduler time model", t_sched),
          ("N^3.5 beyond 2000", t_alpha(3.5)), ("N^2.5 beyond 2000", t_alpha(2.5)), ("10x faster (all N), N^4.72", lambda N: t_pow(N) / 10)]
Cs = [1e2, 1e3, 8766, 87660, 876600, 8766000, 87660000]
print("E_magic total over S <= 2 S_min: %.3f (x perm mult %.2f = %.3f); semi total %.3g" % ((w * Em).sum(), MULT, MULT * (w * Em).sum(), MULT * (w * Es).sum()))
hdr = "| time model | " + " | ".join(["100 h", "1000 h", "1 CPU-yr", "10 CPU-yr", "100 CPU-yr", "1000 CPU-yr", "10^4 CPU-yr"]) + " | C for E=0.5 | C for E=1 |"
print(hdr); print("|" + "---|" * 10)
out = {}
for name, tf in models:
    t = tf(N); T = w * ns * t / 3600.0; E = w * Em
    o = np.argsort(-(Em / (ns * t)))
    cT = np.cumsum(T[o]) * MULT; cE = np.cumsum(E[o]) * MULT
    vals = [np.interp(C, cT, cE) for C in Cs]
    def cfor(e):
        if cE[-1] < e: return "never"
        c = np.interp(e, cE, cT); return f"{c/8766:.3g} CPU-yr"
    print(f"| {name} | " + " | ".join(f"{v:.3g}" for v in vals) + f" | {cfor(0.5)} | {cfor(1.0)} |")
    # where the yield at 1 and 100 CPU-yr sits (N of the marginal sum)
    for C in (8766, 876600):
        j = np.searchsorted(cT, C)
        if j < len(o): print(f"     at {C/8766:.0f} CPU-yr: marginal sum N ~ {N[o[min(j, len(o)-1)]]:.0f}, t/sum {t[o[min(j,len(o)-1)]]:.3g} s, marginal CPU-yr per magic {1/(Em[o[j]]/(ns[o[j]]*t[o[j]])*1)/3600/8766:.3g}")
    out[name] = dict(C=Cs, E=vals)
# E by N band (total, all S <= 2 S_min) and CPU to exhaust each band
print("\nE_magic and CPU by N band (power-law time):")
t = t_pow(N)
for lo, hi in ((0, 2000), (2000, 4000), (4000, 8000), (8000, 16000), (16000, 32000), (32000, 64000), (64000, 1e9)):
    m = (N >= lo) & (N < hi)
    Eb = MULT * (w * Em)[m].sum(); Tb = MULT * (w * ns * t)[m].sum() / 3600 / 8766; Sb = MULT * (w * Es)[m].sum()
    Tq = MULT * (w * ns * t_quad(N))[m].sum() / 3600 / 8766
    print(f"  N [{lo},{hi:.0f}): E_magic {Eb:.3g}  semi {Sb:.3g}  CPU-yr to search all: {Tb:.3g} (pow) {Tq:.3g} (curved)  -> CPU-yr per magic {Tb/max(Eb,1e-30):.3g} / {Tq/max(Eb,1e-30):.3g}")
json.dump(out, open("frontier_eval.json", "w"))
