"""Scan candidate P for a given n: model E_semi over S in [Smin, 2 Smin]."""
import sys, math, itertools, json
import numpy as np
from model import components, assemble
from smin import smin, save
n = int(sys.argv[1])
cands = [tuple(int(x) for x in s.split(",")) for s in sys.argv[2:]]
for P in cands:
    s0 = smin(P, n)
    best = []
    for S in np.unique(np.linspace(s0, 2.2 * s0, 45).astype(int)):
        o = components(P, int(S), n, pairs=False)
        a = assemble(o, edge=False)
        best.append((int(S), a["logN"], a["logEsemi"], a["logEmagic"]))
    tot = math.log(sum(math.exp(b[2]) for b in best) * (2.2 * s0 - s0) / len(best))
    top = max(best, key=lambda b: b[2])
    first = next((b for b in best if b[2] > math.log(0.05)), None)
    print(P, "Smin", s0, "sum_S E_semi(gauss+local) ~ e^%.1f" % tot, "max at S=%d N~%.0f E=%.2g" % (top[0], math.exp(top[1]), math.exp(top[2])),
          "first S with E>0.05:", (first[0], round(math.exp(first[1]))) if first else None)
save()
