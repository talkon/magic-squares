"""Pre-screen candidate P by the number of divisors within a factor f of P^(1/n)
(histogram convolution of log-divisors; no caching)."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import math, numpy as np
from cands import gen
PR = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31]
def log_div_hist(P, h=0.01):
    hist = np.array([1.0])
    for i, a in enumerate(P):
        if a == 0: continue
        step = math.log(PR[i]) / h
        idx = np.round(np.arange(a + 1) * step).astype(int)
        k = np.zeros(idx[-1] + 1); np.add.at(k, idx, 1.0)
        hist = np.convolve(hist, k)
    return hist
def dnear(P, n, f=2.0, h=0.01):
    hist = log_div_hist(P, h)
    c = (len(hist) - 1) / n
    lo = int(math.floor(c - math.log(f) / h)); hi = int(math.ceil(c + math.log(f) / h))
    return int(round(hist[max(lo, 0):hi + 1].sum()))
def screened(n, X, tau_min, top=None, min_near=None, Xlo=None):
    out = []
    for P in gen(n, X, tau_min):
        if sum(1 for a in P if a) < 2: continue
        if Xlo is not None:
            lp = sum(a * math.log(PR[i]) for i, a in enumerate(P))
            if n * math.exp(lp / n) < Xlo: continue
        dn = dnear(P, n)
        if min_near is not None and dn < min_near: continue
        out.append((dn, P))
    out.sort(reverse=True)
    return out[:top] if top else out
if __name__ == "__main__":
    import sys, time, collections
    n, X, tmin = int(sys.argv[1]), float(sys.argv[2]), int(sys.argv[3])
    t = time.time()
    s = screened(n, X, tmin)
    print(len(s), round(time.time() - t, 1))
    for dn, P in s[:8]: print(dn, P)
    print(sorted(collections.Counter(min(dn // 50 * 50, 1500) for dn, P in s).items()))
