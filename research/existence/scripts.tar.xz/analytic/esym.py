import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
import math, numpy as np
def log_pdist_saddle(W, mcells):
    """log( m! e_m(w) ) for each row of W (probability vectors), saddle point with
    first-order correction.  W: (rows x items)."""
    W = np.atleast_2d(W)
    out = np.zeros(W.shape[0])
    for r in range(W.shape[0]):
        w = W[r][W[r] > 1e-300]
        # solve sum w z/(1+wz) = m for log z
        lo, hi = -50.0, 50.0
        for _ in range(200):
            mid = 0.5 * (lo + hi); z = math.exp(mid)
            f = (w * z / (1 + w * z)).sum()
            if f < mcells: lo = mid
            else: hi = mid
        z = math.exp(0.5 * (lo + hi))
        wz = w * z
        V = (wz / (1 + wz) ** 2).sum()
        out[r] = (np.log1p(wz).sum() - mcells * math.log(z) - 0.5 * math.log(2 * math.pi * V)
                  + math.lgamma(mcells + 1))
    return out
if __name__ == "__main__":
    from maxent import solve, log_esym_distinct
    for P, S, n in (((10, 4, 3, 2), 327, 6), ((10, 4, 3, 2), 220, 6), ((14, 7, 5, 3, 1, 1), 2700, 6), ((10, 4, 2, 2, 1, 1), 310, 7), ((8,4,2,2,1,1,1), 400, 8)):
        r = solve(P, S, n if n < 8 else 8)
        for m in (n, n * n):
            ex = log_esym_distinct(r["logw"], m)
            sp = log_pdist_saddle(r["w"][None, :], m)[0]
            print(P, S, m, round(ex, 4), round(sp, 4))
