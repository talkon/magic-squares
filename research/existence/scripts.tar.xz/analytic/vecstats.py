"""Compare actual vector-label statistics with the max-entropy cell law."""
import sys, math, numpy as np
from smallcount import vectors
from maxent import solve, log_esym_distinct
def stats(P, S, n):
    V = vectors(P, S, n)
    N = len(V)
    labs = sorted({x for v in V for x in v})
    idx = {x: i for i, x in enumerate(labs)}
    deg = np.zeros(len(labs))
    M = np.zeros((N, len(labs)), dtype=np.uint8)
    for t, v in enumerate(V):
        for x in v:
            deg[idx[x]] += 1; M[t, idx[x]] = 1
    muV = deg / (n * N)
    # actual pair overlap distribution
    Mf = M.astype(np.float32)
    O = Mf @ Mf.T
    np.fill_diagonal(O, -1)
    off = O[O >= 0]
    p_disj = float((off == 0).mean()); mean_ov = float(off.mean())
    r = solve(P, S, n)
    mu = r["w"]; ds = r["ds"]
    # mu restricted to labels
    mu_lab = {int(round(d)): w for d, w in zip(ds, mu) if w > 1e-12}
    s2mu = float((mu ** 2).sum())
    # P(n rows pairwise disjoint): sample
    rng = np.random.default_rng(1)
    trials = 20000; ok = 0
    for _ in range(trials):
        rows = rng.choice(N, n, replace=False)
        if M[rows].sum(0).max() <= 1: ok += 1
    return dict(N=N, U=len(labs), s2_muV=float((muV**2).sum()), s2_mu=s2mu, perp_mu=math.exp(r["H"]),
                perp_muV=float(np.exp(-(muV[muV>0]*np.log(muV[muV>0])).sum())),
                mean_ov=mean_ov, n2s2muV=n*n*float((muV**2).sum()), p_disj=p_disj, exp_mean=math.exp(-mean_ov),
                p_rows_disj=ok/trials, pred_rows_disj_iid=math.exp(log_esym_distinct(r["logw"], n*n) - n*log_esym_distinct(r["logw"], n)),
                pred_rows_from_pairs=p_disj ** (n*(n-1)/2))
if __name__ == "__main__":
    n = int(sys.argv[1]); P = tuple(int(x) for x in sys.argv[2].split(","))
    for S in map(int, sys.argv[3:]):
        print(S, {k: (round(v, 5) if isinstance(v, float) else v) for k, v in stats(P, S, n).items()})
