#!/bin/sh
cd "$(dirname "$0")"
for spec in "5 0 12" "5 1 9" "5 2 7" "6 0 9" "6 1 6" "6 2 5" "7 0 7" "7 1 5" "7 2 4" "8 0 5" "8 1 4" "8 2 3"; do
  set -- $spec
  a=1
  while [ $a -le $3 ]; do
    ./ehr $1 $a $2
    a=$((a+1))
  done
done
