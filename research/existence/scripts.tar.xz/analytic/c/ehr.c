/* Count n x n nonnegative integer matrices with all row and column sums a
 * (mode 0), plus main diagonal sum a (mode 1), plus both diagonals (mode 2).
 * Cell-by-cell DP over (remaining column sums, remaining row sum[, diag, anti]).
 * Counts in long double (exact up to 2^64). usage: ehr n a mode */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef long double R;
int main(int argc, char **argv) {
  int n = atoi(argv[1]), a = atoi(argv[2]), mode = atoi(argv[3]);
  int B = a + 1;
  int nd = n + 1 + (mode >= 1) + (mode >= 2);
  size_t size = 1;
  for (int i = 0; i < nd; i++) size *= B;
  /* digit layout: cols 0..n-1, row = n, diag = n+1, anti = n+2 */
  size_t pw[16];
  pw[0] = 1;
  for (int i = 1; i <= nd; i++) pw[i] = pw[i - 1] * B;
  R *cur = calloc(size, sizeof(R)), *nxt = calloc(size, sizeof(R));
  if (!cur || !nxt) { fprintf(stderr, "oom\n"); return 1; }
  size_t start = 0;
  for (int i = 0; i < nd; i++) start += (size_t)a * pw[i];
  cur[start] = 1;
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      memset(nxt, 0, size * sizeof(R));
      int ondiag = (mode >= 1 && i == j), onanti = (mode >= 2 && i + j == n - 1);
      for (size_t s = 0; s < size; s++) {
        R v = cur[s];
        if (v == 0) continue;
        int col = (s / pw[j]) % B, row = (s / pw[n]) % B;
        int lim = col < row ? col : row;
        if (ondiag) { int d = (s / pw[n + 1]) % B; if (d < lim) lim = d; }
        if (onanti) { int d = (s / pw[n + 2]) % B; if (d < lim) lim = d; }
        /* last column: row remainder must go entirely here */
        int lo = 0;
        if (j == n - 1) { lo = row; if (lo > lim) continue; lim = lo; }
        for (int x = lo; x <= lim; x++) {
          size_t t = s - x * pw[j] - x * pw[n];
          if (ondiag) t -= x * pw[n + 1];
          if (onanti) t -= x * pw[n + 2];
          nxt[t] += v;
        }
      }
      R *tmp = cur; cur = nxt; nxt = tmp;
    }
    /* end of row: row remainder is 0, reset to a */
    memset(nxt, 0, size * sizeof(R));
    for (size_t s = 0; s < size; s++) {
      if (cur[s] == 0) continue;
      if ((s / pw[n]) % B != 0) continue;
      nxt[s + (i < n - 1 ? (size_t)a * pw[n] : 0)] += cur[s];
    }
    R *tmp = cur; cur = nxt; nxt = tmp;
  }
  printf("%d %d %d %.21Lg\n", n, a, mode, cur[0]);
  return 0;
}
