"""Ehrhart polynomial H_n(t) of the Birkhoff polytope from exact small values + reciprocity."""
from fractions import Fraction as F
import math, collections, os
HERE = os.path.dirname(os.path.abspath(__file__))
def exact_vals(n):
    v = {0: 1}
    for line in open(os.path.join(HERE, "c/ehr.txt")):
        nn, a, mode, c = line.split()
        if int(nn) == n and int(mode) == 0:
            v[int(a)] = int(round(float(c)))
    return v
def poly(n):
    deg = (n - 1) ** 2
    v = exact_vals(n)
    pts = dict(v)
    for t, c in v.items():
        pts[-t - n] = (-1) ** deg * c
    for t in range(1, n):
        pts[-t] = 0
    xs = sorted(pts)[: deg + 1] if len(pts) >= deg + 1 else None
    if xs is None:
        return None
    # Lagrange via solving Vandermonde in Fractions (Newton divided differences)
    X = [F(x) for x in xs]; Y = [F(pts[x]) for x in xs]
    m = len(X); coef = Y[:]
    for j in range(1, m):
        for i in range(m - 1, j - 1, -1):
            coef[i] = (coef[i] - coef[i - 1]) / (X[i] - X[i - j])
    def H(t):
        t = F(t); r = coef[-1]
        for i in range(m - 2, -1, -1):
            r = r * (t - X[i]) + coef[i]
        return r
    # check against unused points
    for x in pts:
        assert H(x) == pts[x], (n, x)
    return H
if __name__ == "__main__":
    for n in (5, 6):
        H = poly(n)
        print(n, "check unused points ok", [str(H(t)) for t in (11, 12, 15, 20)][:2])
        lead = None
