"""Evaluate the gauss+local model over S in [S_min, min(X, fmax*S_min)] for many P.
Saves per-P arrays: S grid, logEsemi, ld_n2, lpair, lpS, lpP, lpSP, logN."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import sys, json, math, time
import numpy as np
from batch import batch
from smin import smin, save
from screen import screened
def run(n, X, tau_min, top, fmax=3.0, npts=28, out=None, min_near=None):
    t0 = time.time()
    cl = screened(n, X, tau_min, top=top, min_near=min_near)
    res = []
    for i, (dn, P) in enumerate(cl):
        s0 = smin(P, n)
        if s0 >= X: continue
        hi = min(X, fmax * s0)
        # grid dense near s0
        u = np.concatenate([[0.0], np.geomspace(1e-3, hi / s0 - 1, npts - 1)])
        S = np.unique(np.round(s0 * (1 + u)).astype(int))
        S = S[S > s0]
        if len(S) < 3: continue
        try:
            o = batch(P, S, n)
        except Exception as e:
            print("fail", P, e, file=sys.stderr); continue
        rec = dict(P=P, smin=s0, dnear=dn, S=S.tolist())
        for k in ("logEsemi", "ld_n2", "lpair", "lpS", "lpP", "lpSP", "logN", "H"):
            rec[k] = [float(x) for x in o[k]]
        res.append(rec)
        if i % 100 == 0:
            print(i, len(cl), P, round(time.time() - t0, 1), file=sys.stderr, flush=True)
            save()
    save()
    if out:
        json.dump(res, open(out, "w"))
    return res
def integrate(rec, X, field="logEsemi", K=1.0, gamma=1.0, extra=None):
    """sum over integer S <= X of K * exp(field + (gamma-1)*ld_n2 [+ extra])"""
    S = np.array(rec["S"], float); v = np.array(rec[field], float)
    v = v + (gamma - 1) * np.array(rec["ld_n2"])
    if extra is not None: v = v + extra
    v = np.where(np.isfinite(v), v, -1e9)
    if X <= S[0]: return 0.0
    m = S <= X
    Sx = S[m]; vx = v[m]
    if X > Sx[-1] and len(Sx) < len(S):
        j = len(Sx)
        t = (X - S[j - 1]) / (S[j] - S[j - 1])
        Sx = np.append(Sx, X); vx = np.append(vx, v[j - 1] + t * (v[j] - v[j - 1]))
    # trapezoid in S of exp(v) with log-linear interpolation
    tot = 0.0
    for a, b, va, vb in zip(Sx[:-1], Sx[1:], vx[:-1], vx[1:]):
        h = b - a
        if abs(vb - va) < 1e-9: tot += h * math.exp(va)
        else: tot += h * (math.exp(vb) - math.exp(va)) / (vb - va)
    return K * tot
if __name__ == "__main__":
    n, X, tmin, top = int(sys.argv[1]), float(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
    out = sys.argv[5]
    run(n, X, tmin, top, out=out)
