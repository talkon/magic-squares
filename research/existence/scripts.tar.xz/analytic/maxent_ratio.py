"""Distribution of (largest entry)/S in the observed semi-magic squares, by n, vs S/S_min."""
import json, glob, collections, numpy as np, sys
from load import load
from smin import smin
out = {}
def stats(rs, label):
    rs = np.array(rs)
    q = np.percentile(rs, [5, 25, 50, 75, 95])
    print(f"{label}: {len(rs)} squares, max/S quantiles 5/25/50/75/95% = {np.round(q,3)}")
    return rs.tolist()
# n = 6
sums, squares = load()
r6 = []; byx = collections.defaultdict(list)
for (P, S, h), r in squares.items():
    g = r["grid"]; m = max(max(row) for row in g) if isinstance(g[0], list) else max(g)
    s0 = smin(P, 6); x = S / s0
    r6.append(m / S); byx[min(int((x - 1) * 10), 6)].append(m / S)
out[6] = stats(r6, "n=6 near S_min")
for k in sorted(byx): print("   S/Smin in [%.1f,%.1f): median max/S %.3f (n=%d)" % (1 + k / 10, 1 + (k + 1) / 10, np.median(byx[k]), len(byx[k])))
for n, pat in ((5, "runs/n5_survey.jsonl"), (7, "runs/n7all.jsonl"), (6, "runs/n6low.jsonl")):
    rs = []
    for f in glob.glob(pat):
        for line in open(f):
            r = json.loads(line)
            if r.get("type") != "square": continue
            g = r["grid"]; m = max(max(row) for row in g) if isinstance(g[0], list) else max(g)
            rs.append(m / r["S"])
    out[str(n) + pat] = stats(rs, f"n={n} {pat}")
# known magic / semi-magic examples
print("Miquel 7x7 magic: 252/465 =", round(252 / 465, 3), "; Horner 8x8: 261/840 =", round(261 / 840, 3), "; Boyer 8x8: 225/600 =", round(225 / 600, 3))
json.dump(out, open("maxent_ratio.json", "w"))
