import os, sys, json, time
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import gs3, gmodel, maxent
from smin import save
fn = sys.argv[1]
if len(sys.argv) > 2: gmodel.NPTS = int(sys.argv[2])
d = json.load(open(fn)); n = d["n"]
gs3.UNIV["Xlo"], gs3.UNIV["Xhi"] = d["Xlo"], d["Xhi"]
t0 = time.time(); c = 0
for r in d["res"]:
    if "perm" in r:
        ex, cnt = gs3.perms_extra(tuple(r["P"]), n, d["XG"]); r["perm"] = ex; r["nperm"] = cnt
        maxent._div_cache.clear(); c += 1
        if c % 50 == 0: print(c, round(time.time() - t0), file=sys.stderr, flush=True)
save()
d["perm_fixed"] = True
json.dump(d, open(fn, "w"))
print("fixed", c, round(time.time() - t0), file=sys.stderr)
