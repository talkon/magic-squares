import sys, math, json, time
from load import load
from model import components
from smin import smin, save
sums, squares = load()
out = []
t0 = time.time()
for i, (P, S) in enumerate(sorted(sums)):
    r = sums[(P, S)]
    o = components(P, S, 6)
    out.append(dict(P=P, S=S, N=r["nvecs_raw"], sq=r["squares"], smin=smin(P), time=r["time"], comp=o))
    if i % 5000 == 0: print(i, time.time() - t0, file=sys.stderr)
save()
json.dump(out, open("calib3.json", "w"))
