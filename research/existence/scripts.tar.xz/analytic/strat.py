"""Two-phase stratified estimate of N_semi(X), N_magic(X) over a candidate list."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import sys, json, math, random, time, collections
import numpy as np
from gsum import eval_P, cum
from smin import save
XGRID = [300, 400, 500, 700, 1000, 1400, 2000, 2800, 4000, 5600, 8000, 11000, 16000, 22000, 32000]
def stratum(P, dn, n):
    k = sum(1 for a in P if a); ones = sum(1 for a in P if a == 1)
    lp = sum(a * math.log(p) for a, p in zip(P, [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31]))
    sscale = n * math.exp(lp / n)
    sb = int(math.log(sscale) / math.log(2) * 2)   # half-octave bins of S-scale
    return (k, min(ones, 4), min(dn // 40, 8), sb)
def evaluate(cands, n, Xmax, log=None):
    out = []
    t0 = time.time()
    for i, (dn, P) in enumerate(cands):
        P = tuple(P)
        try:
            r = eval_P(P, n, Xmax)
        except Exception as e:
            r = None
        if r is None:
            out.append(dict(P=P, dn=dn, Fs=[0.0] * len(XGRID), Fm=[0.0] * len(XGRID)))
        else:
            out.append(dict(P=P, dn=dn, smin=r["smin"], Fs=[cum(r, X, "lEs") for X in XGRID], Fm=[cum(r, X, "lEm") for X in XGRID]))
        if log and i % 200 == 0:
            print(i, len(cands), round(time.time() - t0), file=log, flush=True); save()
    save()
    return out
if __name__ == "__main__":
    n, Xmax, candfile, n1, n2, outfile = int(sys.argv[1]), float(sys.argv[2]), sys.argv[3], int(sys.argv[4]), int(sys.argv[5]), sys.argv[6]
    cands = [(dn, tuple(P)) for dn, P in json.load(open(candfile))]
    strata = collections.defaultdict(list)
    for dn, P in cands: strata[stratum(P, dn, n)].append((dn, P))
    random.seed(7)
    # phase 1: uniform sample
    ph1 = random.sample(cands, min(n1, len(cands)))
    res1 = evaluate(ph1, n, Xmax, log=sys.stderr)
    done = {r["P"] for r in res1}
    # Neyman allocation on the magic total at Xmax (index -1 of usable X)
    byst = collections.defaultdict(list)
    for r in res1: byst[stratum(r["P"], r["dn"], n)].append(r["Fm"][-1])
    # coarse strata for allocation: (k, ones, dn bin)
    coarse = collections.defaultdict(list)
    for key, v in byst.items(): coarse[key[:3]].extend(v)
    alloc = {}
    tot_w = 0.0
    for key, lst in strata.items():
        v = byst.get(key) or coarse.get(key[:3]) or [0.0]
        sd = math.sqrt(np.mean(np.square(v))) + 1e-12
        alloc[key] = len(lst) * sd; tot_w += alloc[key]
    ph2 = []
    for key, lst in strata.items():
        m = int(round(n2 * alloc[key] / tot_w))
        rest = [c for c in lst if c[1] not in done]
        ph2 += random.sample(rest, min(m, len(rest)))
    res2 = evaluate(ph2, n, Xmax, log=sys.stderr)
    json.dump(dict(n=n, Xmax=Xmax, XGRID=XGRID, strata={"|".join(map(str, k)): len(v) for k, v in strata.items()},
                   res=[dict(r, P=list(r["P"]), st="|".join(map(str, stratum(r["P"], r["dn"], n)))) for r in res1 + res2]),
              open(outfile, "w"))
