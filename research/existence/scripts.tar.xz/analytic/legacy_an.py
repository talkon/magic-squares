import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json, math, numpy as np, collections
from globalsum import integrate
R = json.load(open("legacy_pred.json"))
CAL = {"raw": (0.0, 0.0, 0.0), "A_lin": (2.2, 0.38, 0.0), "B_quad": (-1.087, 0.0, -0.0091), "n6_lin": (-0.5946, 0.1371, 0.0)}
def logK(cal, ld):
    a, b, c = CAL[cal]
    return a + b * ld + c * ld * ld
rows = []
for r in R:
    ld = np.array(r["ld_n2"])
    rec = dict(P=tuple(r["P"]), sols=r["sols"], nS=r["nS"], nP=r["nP"], nSP=r["nSP"], smin=r["smin"], hi=r["hi"], maxS=r["maxS"])
    for cal in CAL:
        ex = np.array([logK(cal, x) for x in ld])
        rec["E_" + cal] = integrate(r, r["hi"], extra=ex)
        for t in ("lpS", "lpP", "lpSP"):
            rec[t + "_" + cal] = integrate(r, r["hi"], extra=ex + np.array(r[t]) + math.log(720))
        rec["ldw_" + cal] = integrate(r, r["hi"], extra=ex + np.log(np.maximum(-ld, 1e-9))) / max(rec["E_" + cal], 1e-300)
    rows.append(rec)
json.dump(rows, open("legacy_an.json", "w"))
obs = sum(r["sols"] for r in rows)
print("P", len(rows), "observed squares", obs, "(in P with S range modelled)")
for cal in CAL:
    E = sum(r["E_" + cal] for r in rows)
    tS = sum(r["lpS_" + cal] for r in rows); tP = sum(r["lpP_" + cal] for r in rows); tSP = sum(r["lpSP_" + cal] for r in rows)
    print(f"{cal:7s} pred squares {E:12.0f} obs/pred {obs/E:.3f} | traversals per predicted square: S {tS/E:.3f} P {tP/E:.4f} SP {tSP/E*1e3:.3f}e-3")
oS = sum(r["nS"] for r in rows); oP = sum(r["nP"] for r in rows); oSP = sum(r["nSP"] for r in rows)
print(f"observed traversals per square: S {oS/obs:.3f} P {oP/obs:.4f} SP {oSP/obs*1e3:.3f}e-3  (nSP={oSP})")
# trends: bin P by weighted ld (A) and by smin
for cal in ("A_lin", "B_quad"):
    print("calibration", cal)
    bins = collections.defaultdict(lambda: [0, 0.0, 0])
    for r in rows:
        if r["E_" + cal] <= 0: continue
        L = r["ldw_" + cal]   # weighted mean of log(-ld)
        key = round(math.exp(L) / 2) * 2
        b = bins[min(key, 30)]; b[0] += r["sols"]; b[1] += r["E_" + cal]; b[2] += 1
    for k in sorted(bins):
        b = bins[k]
        if b[1] > 1: print(f"   -ld~{k:3d}: P {b[2]:4d} obs {b[0]:7d} pred {b[1]:10.0f} ratio {b[0]/b[1]:.3f}")
    bins = collections.defaultdict(lambda: [0, 0.0, 0])
    for r in rows:
        key = int(r["smin"] // 250 * 250)
        b = bins[key]; b[0] += r["sols"]; b[1] += r["E_" + cal]; b[2] += 1
    for k in sorted(bins):
        b = bins[k]
        if b[1] > 1: print(f"   smin {k:5d}: P {b[2]:4d} obs {b[0]:7d} pred {b[1]:10.0f} ratio {b[0]/b[1]:.3f}")
