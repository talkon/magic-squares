"""Conditional coincidence factors for pairs of cells under the Gaussian
(max-entropy) conditional distribution given the line constraints.
For a pair (c, c'): P(x_c = x_c' = y | lines) / mu(y)^2 = D * exp(-G/2 * chi2(y)),
D = det(I - V^T V)^{-q/2} (V = whitened contributions of the two cells),
G = u^T (A'A'^T)^+ u with u = A_c + A_c' (lines through the pair) and A' = A minus the two cells."""
import numpy as np
from functools import lru_cache
from edge import lines

@lru_cache(maxsize=None)
def pair_classes(n, kind):
    """list of (count, det2, G) over unordered pairs of cells, grouped by class"""
    A = lines(n, kind)
    m = A.shape[1]
    M = A @ A.T
    Mp = np.linalg.pinv(M)
    H = A.T @ Mp @ A
    out = {}
    for c in range(m):
        for c2 in range(c + 1, m):
            h1, h2, h12 = H[c, c], H[c2, c2], H[c, c2]
            det2 = (1 - h1) * (1 - h2) - h12 ** 2
            u = A[:, c] + A[:, c2]
            Ap = M - np.outer(A[:, c], A[:, c]) - np.outer(A[:, c2], A[:, c2])
            G = float(u @ np.linalg.pinv(Ap) @ u)
            key = (round(det2, 9), round(G, 9))
            out[key] = out.get(key, 0) + 1
    return [(cnt, d, G) for (d, G), cnt in sorted(out.items())]

if __name__ == "__main__":
    for n in (4, 5, 6, 7, 8):
        for kind in ("vec", "semi"):
            if kind == "semi" and n > 7: pass
            print(n, kind, pair_classes(n, kind))
