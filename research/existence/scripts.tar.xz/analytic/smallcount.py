"""Exact count of n x n additive-multiplicative semi-magic squares (n = 3, 4)
for given P and S, up to row/col permutations and transposition."""
import subprocess, sys, os, tempfile, itertools
ENUM = "/home/user/magic-squares/bin/enumerate"
def vectors(P, S, n):
    with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as f:
        fn = f.name
    subprocess.run([ENUM, "--vec-size", str(n), "--reduce", "none", "--min-sum", str(S), "--max-sum", str(S),
                    "--file", fn, *map(str, P)], capture_output=True)
    vs = []
    for line in open(fn):
        xs = tuple(sorted(int(x) for x in line.split()))
        if len(xs) == n and sum(xs) == S:
            vs.append(xs)
    os.unlink(fn)
    return vs
def count(P, S, n):
    V = vectors(P, S, n)
    labels = sorted({x for v in V for x in v})
    idx = {x: i for i, x in enumerate(labels)}
    B = [sum(1 << idx[x] for x in v) for v in V]
    bylab = {}
    for b in B:
        for i in range(len(labels)):
            if b >> i & 1:
                bylab.setdefault(i, []).append(b)
    total = 0
    # canonical: x = smallest label of the square; R1 and C1 are the two vectors through x
    # with R1 < C1 (as bitsets) to kill transposition; all labels of square >= x.
    for x in range(len(labels)):
        cand = [b for b in bylab.get(x, []) if (b & ((1 << x) - 1)) == 0]
        hi = ~((1 << x) - 1)
        for R1, C1 in itertools.combinations(cand, 2):
            if R1 & C1 != (1 << x):
                continue
            # remaining vectors: only labels > x
            total += complete(R1, C1, B, x, n)
    return total, len(V), len(labels)
def popc(b): return bin(b).count("1")
def complete(R1, C1, B, x, n):
    """count ways to add rows R2..Rn (each meeting C1 once outside x, disjoint from R1)
    and cols C2..Cn (each meeting R1 once outside x, disjoint from C1), all orthogonal."""
    low = (1 << x) - 1
    rows_c = [b for b in B if not (b & low) and not (b & R1) and popc(b & C1) == 1]
    cols_c = [b for b in B if not (b & low) and not (b & C1) and popc(b & R1) == 1]
    c1rest = [1 << i for i in range(C1.bit_length()) if (C1 >> i & 1) and i != x]
    r1rest = [1 << i for i in range(R1.bit_length()) if (R1 >> i & 1) and i != x]
    # rows: one through each element of c1rest, pairwise disjoint
    rows_by = [[b for b in rows_c if b & e] for e in c1rest]
    cols_by = [[b for b in cols_c if b & e] for e in r1rest]
    rowsets = []
    def rec(i, used, acc, by, out):
        if i == len(by):
            out.append(acc); return
        for b in by[i]:
            if not (b & used):
                rec(i + 1, used | b, acc + [b], by, out)
    rec(0, 0, [], rows_by, rowsets)
    if not rowsets: return 0
    colsets = []
    rec(0, 0, [], cols_by, colsets)
    cnt = 0
    for rs in rowsets:
        U = R1 | sum(rs)
        for cs in colsets:
            if (C1 | sum(cs)) != U: continue
            if all(popc(r & c) == 1 for r in rs for c in cs):
                cnt += 1
    return cnt
if __name__ == "__main__":
    n = int(sys.argv[1]); P = tuple(int(x) for x in sys.argv[2].split(","))
    for S in map(int, sys.argv[3:]):
        print(S, *count(P, S, n))
