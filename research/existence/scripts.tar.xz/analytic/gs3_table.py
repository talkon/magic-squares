import json, math, sys, numpy as np
from gs3_est import est
def interp(XG, N, X):
    XG = np.asarray(XG); N = np.asarray(N)
    if X <= XG[0]: return N[0]
    if X >= XG[-1]: return N[-1]
    i = np.searchsorted(XG, X)
    a, b = N[i - 1], N[i]
    if a <= 0 or b <= 0: return a + (b - a) * (X - XG[i - 1]) / (XG[i] - XG[i - 1])
    t = math.log(X / XG[i - 1]) / math.log(XG[i] / XG[i - 1])
    return math.exp(math.log(a) + t * math.log(b / a))
def xcross(XG, N, target):
    for i in range(1, len(XG)):
        if N[i - 1] > 0 and N[i - 1] < target <= N[i]:
            t = math.log(target / N[i - 1]) / math.log(N[i] / N[i - 1])
            return math.exp(math.log(XG[i - 1]) + t * math.log(XG[i] / XG[i - 1]))
    return None
fn = sys.argv[1]; Xs = [float(x) for x in sys.argv[2].split(",")]
bias = float(sys.argv[3]) if len(sys.argv) > 3 else 1.0
d = json.load(open(fn)); n = d["n"]
R = {f: est(d, f) for f in ("lEs_lin", "lEm_lin", "lEs_quad", "lEm_quad")}
XG = R["lEm_lin"][0]
print(f"n={n}  (grid-bias factor {bias} applied)")
print("| X | N_semi | N_magic (se) | g_magic | N_magic quad | P(>=1 magic) |")
print("|---|---|---|---|---|---|")
for X in Xs:
    ns = interp(XG, R["lEs_lin"][1], X) * bias; nm = interp(XG, R["lEm_lin"][1], X) * bias
    se = interp(XG, R["lEm_lin"][2], X) * bias; nq = interp(XG, R["lEm_quad"][1], X) * bias
    x0, x1 = X / 1.25, min(X * 1.25, XG[-1])
    g = math.log(interp(XG, R["lEm_lin"][1], x1) / interp(XG, R["lEm_lin"][1], x0)) / math.log(x1 / x0) if interp(XG, R["lEm_lin"][1], x0) > 0 else float('nan')
    gs_ = math.log(interp(XG, R["lEs_lin"][1], x1) / interp(XG, R["lEs_lin"][1], x0)) / math.log(x1 / x0) if interp(XG, R["lEs_lin"][1], x0) > 0 else float('nan')
    print(f"| {X:.0f} | {ns:.3g} (g {gs_:.1f}) | {nm:.3g} ({se:.2g}) | {g:.1f} | {nq:.3g} | {1-math.exp(-nm):.3g} |")
for f in ("lEs_lin", "lEm_lin", "lEm_quad"):
    N = np.array(R[f][1]) * bias
    print(f, "X at N=1:", xcross(XG, N, 1.0), " N=0.1:", xcross(XG, N, 0.1), " N=ln2:", xcross(XG, N, math.log(2)), " N=3:", xcross(XG, N, 3.0), " N(Xmax)=%.3g" % N[-1])
