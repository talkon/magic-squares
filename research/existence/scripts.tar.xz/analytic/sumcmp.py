import json, math, sys, numpy as np, collections
for fn in sys.argv[1:]:
    d = json.load(open(fn))
    obs = np.array([v["obs"] for v in d.values()], float)
    lE = np.array([v["lE"] for v in d.values()]); ld = np.array([v["ld"] for v in d.values()])
    N = np.array([v["N"] for v in d.values()], float); lN = np.array([v["lN"] for v in d.values()])
    E = np.exp(lE); K = np.exp(-1.087 - 0.0091 * ld ** 2)
    m = N >= 20
    print(fn, "sums", len(d), "obs", obs.sum(), "pred raw %.2f" % E.sum(), "pred Kquad %.2f" % (E*K).sum(),
          "log(obs/predKquad) %.2f" % math.log(max(obs.sum(),0.5) / (E*K).sum()),
          "| N: log(obs/pred) %.3f sd %.3f" % (np.mean(np.log(N[m]) - lN[m]), np.std(np.log(N[m]) - lN[m])))
    w = E*K/(E*K).sum()
    print("   weighted mean ld %.2f; obs-weighted? " % (w @ ld))
    # bins in ld
    for lo, hi in [(-40,-14),(-14,-12),(-12,-10),(-10,-8),(-8,-6),(-6,-4),(-4,0)]:
        mm = (ld>=lo)&(ld<hi)
        if mm.sum(): print(f"   ld [{lo},{hi}) sums {mm.sum():6d} obs {obs[mm].sum():6.0f} predK {(E*K)[mm].sum():9.2f} raw {E[mm].sum():9.2f}")
