import json, math, numpy as np
from gmodel import lK, cum, KAPPA
from model import ndiag_pairs, assemble
LD = math.log(ndiag_pairs(6)) + math.log(KAPPA)
R = json.load(open("legacy_pred.json")); E = 0.0; Es = 0.0
for r in R:
    S = np.array(r["S"], float); ld = np.array(r["ld_n2"])
    les = np.array(r["logEsemi"]) + np.array([lK(x, 6, "lin") for x in ld])
    E += cum(S, les + LD + np.array(r["lpair"]), r["maxS"]); Es += cum(S, les, r["maxS"])
print("first search: E_semi %.0f  E_magic %.4f" % (Es, E))
c = json.load(open("calib3.json")); E2 = 0.0; E2s = 0.0; Eobs = 0.0
for r in c:
    a = assemble(r["comp"], edge=False)
    les = a["logEsemi"] + lK(r["comp"]["ld_n2"], 6, "lin")
    lp = a.get("lpair")
    E2s += math.exp(les)
    if lp is not None: E2 += math.exp(les + LD + lp)
print("near-S_min runs: E_semi %.0f  E_magic %.5f" % (E2s, E2), "keys", [k for k in a.keys() if 'pair' in k])
