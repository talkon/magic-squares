import os, sys, math, json
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import numpy as np
from batch2 import batch
from gmodel import lK, KAPPA
from model import ndiag_pairs
P = tuple(int(x) for x in sys.argv[1].split(","))
S = np.array([float(x) for x in sys.argv[2].split(",")])
o = batch(P, S, 6)
for i, s in enumerate(S):
    les = o["logEsemi"][i] + lK(o["ld_n2"][i], 6, "lin")
    print(P, int(s), "N_pred %.0f" % math.exp(o["logN"][i]), "squares_pred %.1f" % math.exp(les), "P(magic|semi) 1 in %.3g" % (1 / math.exp(math.log(ndiag_pairs(6)) + o["lpair"][i] + math.log(KAPPA))))
