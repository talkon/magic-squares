import json, math, sys, collections, numpy as np
def estimate(fn, field):
    d = json.load(open(fn))
    XG = d["XGRID"]; st = d["strata"]
    by = collections.defaultdict(list)
    for r in d["res"]: by[r["st"]].append(r[field])
    tot = np.zeros(len(XG)); var = np.zeros(len(XG)); missing = 0
    coarse = collections.defaultdict(list)
    for key, v in by.items(): coarse[tuple(key.split("|")[:3])].extend(v)
    for key, Nst in st.items():
        v = by.get(key)
        if not v:
            v = coarse.get(tuple(key.split("|")[:3])); missing += Nst
            if not v: continue
        v = np.array(v)
        tot += Nst * v.mean(0)
        if len(v) > 1: var += Nst ** 2 * v.var(0, ddof=1) / len(v)
        else: var += (Nst * v.mean(0)) ** 2
    return XG, tot, np.sqrt(var), missing, len(d["res"])
if __name__ == "__main__":
    fn = sys.argv[1]
    for field in ("Fs", "Fm"):
        XG, tot, se, miss, nev = estimate(fn, field)
        print(field, "evaluated", nev, "candidates in unsampled strata", miss)
        for X, t, s in zip(XG, tot, se):
            print(f"   X={X:6d}  N={t:.4g}  (se {s:.2g})")
