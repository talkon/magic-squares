"""E_magic (n = 6) attainable with C CPU-hours under the analytic model: every sum S in
(S_min, 2 S_min] of every P of the global universe (gs3_n6 stratified sample, subsampled), with
search time per sum t(N); sums are taken greedily by E_magic / t (ideal scheduler, sums independent).
Saves per-segment arrays so different time models can be applied cheaply."""
import os, sys, json, math, random, collections
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import numpy as np, gmodel, maxent
from smin import save
frac = float(sys.argv[1]) if len(sys.argv) > 1 else 0.3
g = json.load(open("gs3_n6.json")); st = g["strata"]
by = collections.defaultdict(list)
for r in g["res"]: by["|".join(map(str, r["st"]))].append(tuple(r["P"]))
random.seed(21)
segs = []   # (weight, E_magic, E_semi, n_sums, N_mid)
nP = 0
for key, Nst in st.items():
    v = by.get(key)
    if not v: continue
    m = max(1, int(round(frac * len(v))))
    sub = random.sample(v, min(m, len(v)))
    w = Nst / len(v) * len(v) / len(sub)
    for P in sub:
        o = gmodel.eval_P(P, 6, 1e12, fmax=2.0, npts=30)
        nP += 1
        if o is None: continue
        S = np.array(o["S"], float); lm = np.array(o["lEm_lin"]); ls = np.array(o["lEs_lin"]); lN = np.array(o["lN"])
        for i in range(1, len(S)):
            a, b = S[i - 1], S[i]
            Em = gmodel.cum(S[i-1:i+1], lm[i-1:i+1], b); Es = gmodel.cum(S[i-1:i+1], ls[i-1:i+1], b)
            segs.append((w, Em, Es, b - a, math.exp(0.5 * (lN[i - 1] + lN[i])) / 1.05))
        maxent._div_cache.clear()
save()
json.dump(dict(segs=segs, nP=nP), open("frontier_segs.json", "w"))
print("P evaluated", nP, "segments", len(segs))
