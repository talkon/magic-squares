"""First search (legacy) per-P totals vs analytic model, binned by the model-weighted N (vectors per sum)."""
import json, math, numpy as np, collections
from gmodel import lK, cum
R = json.load(open("legacy_pred.json"))
bins = collections.defaultdict(lambda: [0, 0.0, 0, 0.0, 0.0])
edges = [0, 1000, 2000, 3000, 5000, 8000, 12000, 20000, 40000, 1e12]
tot_o = tot_p = 0
for r in R:
    S = np.array(r["S"], float); ld = np.array(r["ld_n2"]); lE = np.array(r["logEsemi"]) + np.array([lK(x, 6, "lin") for x in ld])
    lN = np.array(r["logN"])
    hi = r["maxS"]
    E = cum(S, lE, hi)
    if E <= 0: continue
    # predicted-weighted split by N
    for i in range(len(edges) - 1):
        m = (np.exp(lN) >= edges[i]) & (np.exp(lN) < edges[i + 1])
        Ei = cum(S, np.where(m, lE, -1e9), hi)
        b = bins[i]; b[1] += Ei; b[4] += Ei / E * r["sols"]   # obs allocated pro rata
    tot_o += r["sols"]; tot_p += E
    # P-level: dominant N bin
    w = np.exp(lE - lE.max()); lNw = (w * lN).sum() / w.sum()
    j = np.searchsorted(edges, math.exp(lNw)) - 1
    bb = bins[100 + j]; bb[0] += r["sols"]; bb[1] += E; bb[2] += 1
print("total obs %d pred %.0f ratio %.3f" % (tot_o, tot_p, tot_o / tot_p))
print("P binned by model-weighted N of their predicted squares: #P obs pred obs/pred")
for j in range(len(edges) - 1):
    b = bins[100 + j]
    if b[2]: print(f"  N~[{edges[j]:.0f},{edges[j+1]:.0f}): P {b[2]:4d}  obs {b[0]:7d}  pred {b[1]:10.0f}  ratio {b[0]/max(b[1],1e-9):.2f}")
print("predicted squares by N of the sum (all legacy P):")
for i in range(len(edges) - 1):
    b = bins[i]
    print(f"  N [{edges[i]:.0f},{edges[i+1]:.0f}): pred {b[1]:10.0f}")
