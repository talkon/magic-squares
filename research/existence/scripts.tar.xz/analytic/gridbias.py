import json, sys, random, numpy as np, gmodel
from gmodel import eval_P, cum
fn, npts0 = sys.argv[1], int(sys.argv[2])
d = json.load(open(fn)); n = d["n"]; XG = d["XG"]
R = [r for r in d["res"] if r["lEm_lin"][-1] > 0]
R.sort(key=lambda r: -r["lEm_lin"][-1]); random.seed(5)
pick = R[:10] + random.sample(R[10:], min(10, len(R) - 10))
num = {f: np.zeros(len(XG)) for f in ("lEm_lin", "lEs_lin")}; den = {f: np.zeros(len(XG)) for f in num}
for r in pick:
    a = eval_P(tuple(r["P"]), n, XG[-1] * 1.0001, npts=npts0); b = eval_P(tuple(r["P"]), n, XG[-1] * 1.0001, npts=48)
    for f in num:
        den[f] += np.array([cum(a["S"], a[f], X) for X in XG]); num[f] += np.array([cum(b["S"], b[f], X) for X in XG])
for f in num:
    rr = num[f] / np.maximum(den[f], 1e-300)
    print(n, f, "F(48 pts)/F(%d pts) at X-grid quartiles:" % npts0, [round(float(rr[i]), 3) for i in (len(XG) // 4, len(XG) // 2, 3 * len(XG) // 4, -1)])
