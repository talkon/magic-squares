import subprocess, json, os, sys
CACHE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "smin_cache.json")
_c = json.load(open(CACHE)) if os.path.exists(CACHE) else {}
def smin(P, n=6):
    key = f"{n}:" + " ".join(map(str, P))
    if key not in _c:
        out = subprocess.run(["/home/user/magic-squares/bin/enumerate", "--vec-size", str(n), "--print-min-sum", *map(str, P)],
                             capture_output=True, text=True).stdout
        _c[key] = int(out.split()[0])
    return _c[key]
def save():
    json.dump(_c, open(CACHE, "w"))
