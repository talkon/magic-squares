import json, math, sys, collections, numpy as np
def est(fn, field):
    d = json.load(open(fn)); st = d["strata"]; XG = d["XGRID"]
    by = collections.defaultdict(list); c3 = collections.defaultdict(list)
    for r in d["res"]:
        by[r["st"]].append(r[field]); a = r["st"].split("|"); c3[(a[0], a[1], a[3])].append(r[field])
    tot = np.zeros(len(XG)); var = np.zeros(len(XG))
    for key, Nst in st.items():
        v = by.get(key)
        if not v:
            a = key.split("|"); v = c3.get((a[0], a[1], a[3]))
            if not v: continue
            v = np.array(v); tot += Nst * v.mean(0); continue
        v = np.array(v); tot += Nst * v.mean(0)
        if len(v) > 1: var += Nst ** 2 * v.var(0, ddof=1) / len(v)
    return XG, tot, np.sqrt(var)
if __name__ == "__main__":
    fns = sys.argv[1:]
    for field in ("Fs", "Fm"):
        XG = None; T = 0; V = 0
        for fn in fns:
            XG, t, s = est(fn, field); T = T + t; V = V + s ** 2
        print(field, fns)
        for X, t, s in zip(XG, T, np.sqrt(V)):
            if t > 0: print(f"   X={X:6d}  N={t:.4g}  (se {s:.2g})")
