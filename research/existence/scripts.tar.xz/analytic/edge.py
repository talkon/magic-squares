"""Exponentiated first-order Edgeworth correction for the local CLT of a linear
constraint system A x = b on iid cells (cells are (1+k)-vectors).

delta = (1/8) S_h2 K4 - (1/8) S_hHh K33a - (1/12) S_H3 K33b
with H = A^T (A A^T)^+ A the hat matrix, h = diag(H), and K* the standardized
cumulant contractions of one cell."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import numpy as np, math
from functools import lru_cache

def lines(n, kind):
    rows = [[(i, j) for j in range(n)] for i in range(n)]
    cols = [[(i, j) for i in range(n)] for j in range(n)]
    if kind == "vec":
        L = [[(0, j) for j in range(n)]]
        cells = [(0, j) for j in range(n)]
    else:
        L = rows + cols
        if kind in ("T", "M"):
            L.append([(i, i) for i in range(n)])
        if kind == "M":
            L.append([(i, n - 1 - i) for i in range(n)])
        cells = [(i, j) for i in range(n) for j in range(n)]
    idx = {c: t for t, c in enumerate(cells)}
    A = np.zeros((len(L), len(cells)))
    for r, l in enumerate(L):
        for c in l:
            A[r, idx[c]] = 1
    return A

@lru_cache(maxsize=None)
def struct(n, kind):
    A = lines(n, kind)
    H = A.T @ np.linalg.pinv(A @ A.T) @ A
    h = np.diag(H)
    return (float((h ** 2).sum()), float(h @ H @ h), float((H ** 3).sum()))

def cumulants(vals, w):
    """standardized 3rd and 4th cumulant contractions of a weighted point set
    vals (m x q), weights w (sum 1)"""
    m = w @ vals
    X = vals - m
    C = (X * w[:, None]).T @ X
    ev, U = np.linalg.eigh(C)
    keep = ev > 1e-12 * ev.max()
    Wh = U[:, keep] / np.sqrt(ev[keep])
    Z = X @ Wh
    q = Z.shape[1]
    # third cumulant tensor = E[z z z]
    k3 = np.einsum("t,ta,tb,tc->abc", w, Z, Z, Z)
    # K4 = sum_ab k4_aabb = E[|z|^4] - (q^2 + 2q)
    K4 = float(w @ (Z ** 2).sum(1) ** 2) - (q * q + 2 * q)
    v = np.einsum("aab->b", k3)
    K33a = float(v @ v)
    K33b = float((k3 ** 2).sum())
    return K4, K33a, K33b

def delta(n, kind, K):
    Sh2, ShHh, SH3 = struct(n, kind)
    K4, K33a, K33b = K
    return Sh2 * K4 / 8 - ShHh * K33a / 8 - SH3 * K33b / 12

if __name__ == "__main__":
    from corr import corrections, maxent_entry, logc
    for n in (5, 6, 7, 8):
        for a in (1, 2, 3, 4, 6, 10):
            xs = np.arange(a + 1, dtype=float)
            # truncated geometric with mean a/n
            lo, hi = -50, 50
            for _ in range(200):
                t = (lo + hi) / 2
                w = np.exp(t * xs - (t * xs).max()); w /= w.sum()
                if w @ xs < a / n: lo = t
                else: hi = t
            K = cumulants(xs[:, None], w)
            out = []
            for kind in ("vec", "semi", "T", "M"):
                dv = delta(n, kind, K)
                if kind in ("T", "M"):
                    dv -= delta(n, "semi", K)
                try:
                    ex = math.exp(logc(kind, n, a))
                except Exception:
                    ex = float("nan")
                out.append(f"{kind} edge {math.exp(dv):.3f} exact {ex:.3f}")
            print(n, a, " | ".join(out))
