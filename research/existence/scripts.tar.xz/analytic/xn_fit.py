import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json, math, numpy as np, collections
from model import assemble
from globalsum import integrate
X = json.load(open("xn_comp.json")); c3 = json.load(open("calib3.json"))
rows = []
for k, r in X.items():
    tag = "n5" if "n5_survey" in k else ("n6low" if "n6low" in k else "n7")
    a = assemble(r["comp"], edge=False)
    rows.append((tag, r["comp"]["n"], r["obs"], r["w"], a["logEsemi"], r["comp"]["ld_n2"]))
for r in c3:
    a = assemble(r["comp"], edge=False)
    rows.append(("n6near", 6, r["sq"], 1.0, a["logEsemi"], r["comp"]["ld_n2"]))
tag = np.array([r[0] for r in rows]); n = np.array([r[1] for r in rows], float)
y = np.array([r[2] for r in rows], float); w = np.array([r[3] for r in rows]); lE = np.array([r[4] for r in rows]); ld = np.array([r[5] for r in rows])
keep = lE > -20
tag, n, y, w, lE, ld = tag[keep], n[keep], y[keep], w[keep], lE[keep], ld[keep]
def fit(X):
    b = np.zeros(X.shape[1]); b[0] = math.log((w * y).sum() / (w * np.exp(lE)).sum())
    for it in range(300):
        mu = np.exp(X @ b + lE)
        g = X.T @ (w * (y - mu)); H = (X * (w * mu)[:, None]).T @ X
        st = np.linalg.solve(H + 1e-10 * np.eye(len(b)), g)
        # damp
        s = 1.0
        while np.abs(s * st).max() > 2: s /= 2
        b += s * st
        if np.abs(st).max() < 1e-10: break
    mu = np.exp(X @ b + lE)
    # sandwich-free simple se
    se = np.sqrt(np.diag(np.linalg.inv((X * (w * mu)[:, None]).T @ X)))
    dev = 2 * np.sum(w * (np.where(y > 0, y * np.log(np.maximum(y, 1e-300) / mu), 0) - (y - mu)))
    return b, se, dev
one = np.ones(len(y)); d5 = (n == 5).astype(float); d7 = (n == 7).astype(float)
models = {
 "c+b ld": np.stack([one, ld], 1),
 "c+b ld+e ld^2": np.stack([one, ld, ld ** 2], 1),
 "c+b ld+d(n-6)": np.stack([one, ld, n - 6], 1),
 "c+b ld+e ld^2+d(n-6)": np.stack([one, ld, ld ** 2, n - 6], 1),
 "c_n (5,6,7)+b ld": np.stack([one, ld, d5, d7], 1),
 "c_n + b ld + e ld^2": np.stack([one, ld, ld ** 2, d5, d7], 1),
 "c+b ld+g ld*(n-6)": np.stack([one, ld, ld * (n - 6)], 1),
}
res = {}
for name, Xm in models.items():
    b, se, dev = fit(Xm)
    res[name] = b
    out = []
    for t in ("n5", "n6low", "n6near", "n7"):
        m = tag == t
        mu = np.exp(Xm[m] @ b + lE[m])
        out.append(f"{t} {(w[m]*y[m]).sum()/(w[m]*mu).sum():.2f}")
    print(f"{name:24s} b={np.round(b,4)} se={np.round(se,4)} dev={dev:.0f} | obs/fit: " + " ".join(out))
json.dump({k: v.tolist() for k, v in res.items()}, open("xn_fit.json", "w"))
