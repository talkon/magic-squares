"""Global expected counts N_semi(X), N_magic(X) for n x n additive-multiplicative squares.
Universe: exponent vectors from cands2.gen2 (nonincreasing over used primes, <= 1 gap), scale
n P^(1/n) in [Xlo, Xhi], tau >= tau_min; strata (half-octave of scale, floor log2 tau).
Two-phase stratified sampling per scale bin; a subsample also evaluates all exponent permutations
with scale <= PR_MAX x sorted (permutation multiplier)."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import sys, json, math, random, time, collections, itertools
import numpy as np
from gmodel import eval_P, cum, logP
from smin import save
from cands2 import gen2
import maxent
PR_MAX = 1.3
def scale(P, n): return n * math.exp(logP(P) / n)
def tau(P):
    t = 1
    for a in P: t *= a + 1
    return t
def stratum(P, n): return (int(2 * math.log2(scale(P, n))), int(math.log2(tau(P))))
FIELDS = ("lEs_lin", "lEm_lin", "lEs_quad", "lEm_quad")
def Farr(P, n, XG):
    r = eval_P(P, n, XG[-1] * 1.0001)
    if r is None: return None, None
    out = {f: [cum(r["S"], r[f], X) for X in XG] for f in FIELDS}
    # diagnostics: magic-weighted mean ld, S/smin at the peak
    w = np.exp(r["lEm_lin"] - np.max(r["lEm_lin"]))
    out["ld_w"] = float((w * r["ld"]).sum() / w.sum())
    out["lN_w"] = float((w * r["lN"]).sum() / w.sum())
    out["smin"] = r["smin"]
    return out, r
UNIV = dict(Xlo=0.0, Xhi=1e300)
def in_universe(q, n):
    """membership in the gen2 universe (shape rules; k, ones, tau are permutation invariant)"""
    q = list(q)
    while q and q[-1] == 0: q.pop()
    if len(q) > 11: return False
    nz = [a for a in q if a > 0]
    if any(nz[i] < nz[i + 1] for i in range(len(nz) - 1)): return False
    zi = [i for i, a in enumerate(q) if a == 0]
    if len(zi) > 1 or (zi and zi[0] < 4): return False
    sc = scale(tuple(q), n)
    return UNIV["Xlo"] <= sc <= UNIV["Xhi"]
def bounded_perms(P, n, lmax):
    """distinct permutations q of the tuple P with logP(q) <= lmax (branch and bound)"""
    import collections as _c
    from gmodel import PR as _PR
    LPr = [math.log(p) for p in _PR[:len(P)]]
    cnt = _c.Counter(P); L = len(P); out = []; cur = []
    def minrest(i, rem):
        vals = sorted(rem.elements(), reverse=True)
        return sum(v * LPr[i + j] for j, v in enumerate(vals))
    def rec(i, lp):
        if i == L:
            out.append(tuple(cur)); return
        for v in sorted(cnt):
            if cnt[v] == 0: continue
            cnt[v] -= 1
            nl = lp + v * LPr[i]
            if nl + minrest(i + 1, +cnt) <= lmax + 1e-9:
                cur.append(v); rec(i + 1, nl); cur.pop()
            cnt[v] += 1
    rec(0, 0.0)
    return out
def perms_extra(P, n, XG):
    l0 = logP(P); tot = {f: np.zeros(len(XG)) for f in FIELDS}; cnt = 0
    L = len(P); gapped = 0 in P
    wgt = 1.0 / max(L - 5, 1) if gapped else 1.0   # members sharing the multiset (zero at index 4..L-2)
    cand = [q for q in bounded_perms(P, n, l0 + n * math.log(PR_MAX))
            if not (gapped and q[-1] == 0) and q != tuple(P) and not in_universe(q, n)]
    if len(cand) > 40:   # unbiased subsample of the permutations
        rs = random.Random(hash(tuple(P)) & 0xffff)
        wgt *= len(cand) / 40.0; cand = rs.sample(cand, 40)
    for q in cand:
        q = tuple(q)
        o, _ = Farr(q, n, XG)
        cnt += 1
        if o is None: continue
        for f in FIELDS: tot[f] += wgt * np.array(o[f])
    return {f: tot[f].tolist() for f in FIELDS}, cnt
if __name__ == "__main__":
    n, Xlo, Xhi, tmin, n1, n2, pfrac, out = sys.argv[1:9]
    if len(sys.argv) > 9:
        import gmodel; gmodel.NPTS = int(sys.argv[9])
    n, Xlo, Xhi, tmin, n1, n2, pfrac = int(n), float(Xlo), float(Xhi), int(tmin), int(n1), int(n2), float(pfrac)
    XG = [float(x) for x in np.unique(np.round(np.geomspace(100, Xhi, 44)))]
    UNIV["Xlo"], UNIV["Xhi"] = Xlo, Xhi
    t0 = time.time()
    cands = gen2(n, Xlo, Xhi, kmin=3, kmax=10, omax=6, max_primes=11, tau_min=tmin)
    strata = collections.defaultdict(list)
    for P in cands: strata[stratum(P, n)].append(P)
    byh = collections.defaultdict(list)
    for key in strata: byh[key[0]].append(key)
    print("n", n, "candidates", len(cands), "strata", len(strata), round(time.time() - t0, 1), file=sys.stderr, flush=True)
    random.seed(1000 + n)
    res = []
    def run(P, st):
        o, _ = Farr(P, n, XG)
        rec = dict(P=list(P), st=list(st))
        if o is None: rec.update({f: [0.0] * len(XG) for f in FIELDS})
        else: rec.update(o)
        if random.random() < pfrac:
            ex, c = perms_extra(P, n, XG); rec["perm"] = ex; rec["nperm"] = c
        res.append(rec)
        maxent._div_cache.clear()
        if len(res) % 200 == 0:
            print(len(res), round(time.time() - t0), file=sys.stderr, flush=True); save()
    for h in sorted(byh):
        keys = byh[h]; Nh = sum(len(strata[k]) for k in keys)
        done = set()
        # phase 1: proportional
        for k in keys:
            m = min(len(strata[k]), max(1, int(round(n1 * len(strata[k]) / Nh))))
            for P in random.sample(strata[k], m):
                run(P, k); done.add(P)
        # phase 2: Neyman on the magic total at the top of the grid
        rms = {}
        for k in keys:
            v = [r["lEm_lin"][-1] for r in res if tuple(r["st"]) == k]
            rms[k] = math.sqrt(np.mean(np.square(v))) if v else None
        pooled = [rms[k] for k in keys if rms[k] is not None]
        fb = max(pooled) if pooled else 1.0
        w = {k: len(strata[k]) * (rms[k] if rms[k] is not None else fb) for k in keys}
        tw = sum(w.values())
        if tw <= 0: continue
        for k in keys:
            m = int(round(n2 * w[k] / tw))
            rest = [P for P in strata[k] if P not in done]
            for P in random.sample(rest, min(m, len(rest))):
                run(P, k)
        json.dump(dict(n=n, XG=XG, Xlo=Xlo, Xhi=Xhi, tmin=tmin, partial_upto_bin=h,
                       strata={"|".join(map(str, kk)): len(v) for kk, v in strata.items() if kk[0] <= h},
                       res=res, perm_fixed=True), open(out + ".partial", "w"))
    save()
    json.dump(dict(n=n, XG=XG, Xlo=Xlo, Xhi=Xhi, tmin=tmin, strata={"|".join(map(str, k)): len(v) for k, v in strata.items()},
                   res=res, perm_fixed=True), open(out, "w"))
    print("done", len(res), round(time.time() - t0), file=sys.stderr)
