"""Compare the scheduler's fitted model (forecast/state/model_6.json) with the analytic model at the same
(P, S, N) points: squares per sum and P(magic | semi), on the forecast pool sample and on large global P.
N = exact vector count from bin/enumerate --counts."""
import os, sys, json, math, random, subprocess, collections
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
sys.path.insert(0, "/home/user/magic-squares/scripts")
import numpy as np
import scheduler as sch
from batch2 import batch
from gmodel import lK, KAPPA
from model import ndiag_pairs
from smin import smin
SP = "/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad"
M = sch.Model.load(SP + "/forecast/state/model_6.json")
def counts(P, lo, hi):
    f = SP + "/existence/analytic/_cnt.txt"
    subprocess.run(["/home/user/magic-squares/bin/enumerate", "--counts", "--min-sum", str(lo), "--max-sum", str(hi), *map(str, P), "--file", f], capture_output=True)
    d = {}
    for line in open(f):
        a = line.split()
        if len(a) >= 2: d[int(a[0])] = int(a[1])
    return d
pool = json.load(open("pool_cmp.json"))["res"]
random.seed(11)
pick = [tuple(r["P"]) for r in random.sample(pool, 40)]
rows = []
for P in pick:
    s0 = smin(P, 6)
    Ss = sorted(set(int(round(s0 * x)) for x in (1.1, 1.2, 1.35, 1.5, 1.7)))
    c = counts(P, Ss[0], Ss[-1])
    Ss = [s for s in Ss if c.get(s, 0) > 0]
    if not Ss: continue
    o = batch(P, np.array(Ss, float), 6)
    for i, S in enumerate(Ss):
        N = c[S]
        a_sq = math.exp(o["logEsemi"][i] + lK(o["ld_n2"][i], 6, "lin"))
        a_pm = math.exp(math.log(ndiag_pairs(6)) + o["lpair"][i] + math.log(KAPPA))
        s_sq = M.squares(list(P), S, N, s0)
        s_pm = M.p_magic(6, M.p_s(list(P), S, s0), M.p_p(list(P), S, s0))
        rows.append(dict(P=P, S=S, x=S / s0, N=N, a_sq=a_sq, s_sq=s_sq, a_pm=a_pm, s_pm=s_pm))
json.dump(rows, open("schedcmp.json", "w"))
def summ(sel, label):
    if not sel: return
    r_sq = np.array([math.log(r["a_sq"] / max(r["s_sq"], 1e-300)) for r in sel])
    r_pm = np.array([math.log(r["a_pm"] / r["s_pm"]) for r in sel])
    asq = sum(r["a_sq"] for r in sel); ssq = sum(r["s_sq"] for r in sel)
    am = sum(r["a_sq"] * r["a_pm"] for r in sel); sm = sum(r["s_sq"] * r["s_pm"] for r in sel)
    print(f"{label:22s} sums {len(sel):4d}  squares analytic/sched: total {asq/ssq:6.2f} median {math.exp(np.median(r_sq)):6.2f} | P(magic|semi) analytic/sched median {math.exp(np.median(r_pm)):5.2f} | E_magic total ratio {am/sm:6.2f}")
for lo, hi in ((0, 3000), (3000, 6000), (6000, 10000), (10000, 20000), (20000, 1e9)):
    summ([r for r in rows if lo <= r["N"] < hi], f"N [{lo},{hi:.0f})")
for lo, hi in ((1.0, 1.15), (1.15, 1.3), (1.3, 1.45), (1.45, 1.6), (1.6, 2)):
    summ([r for r in rows if lo <= r["x"] < hi], f"S/Smin [{lo},{hi})")
summ(rows, "all")
