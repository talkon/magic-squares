"""Global sums: evaluate the calibrated model for candidate P over an S grid."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import sys, json, math, time, random
import numpy as np
from batch import batch
from smin import smin, save
from screen import screened, PR
K0, K2 = -1.087, -0.0091
DELTA = {5: 2.6, 6: 0.0, 7: -0.58, 8: -1.2}
KAPPA_PAIR = 0.72 ** 2 * 1.1
def logP(P): return sum(a * math.log(PR[i]) for i, a in enumerate(P))
def eval_P(P, n, X, fmax=3.0, npts=22):
    lp = logP(P)
    if lp < 63 * math.log(2) - 0.01:
        s0 = smin(P, n)
    else:
        s0 = None
    lo = s0 if s0 else n * math.exp(lp / n)
    if lo >= X: return None
    hi = min(X, fmax * lo)
    u = np.concatenate([[0.0], np.geomspace(2e-3, max(hi / lo - 1, 3e-3), npts - 1)])
    S = np.unique(np.round(lo * (1 + u)).astype(int)); S = S[S > lo]
    if len(S) < 2: return None
    o = batch(P, S, n)
    ld = o["ld_n2"]
    lK = K0 + K2 * ld ** 2 + DELTA[n]
    lEs = o["logEsemi"] + lK
    lEm = lEs + math.log(ndiag(n)) + o["lpair"] + math.log(KAPPA_PAIR)
    return dict(P=P, smin=int(lo), exact_smin=s0 is not None, S=S.tolist(), lEs=[float(x) for x in lEs],
                lEm=[float(x) for x in lEm], ld=[float(x) for x in ld], lN=[float(x) for x in o["logN"]])
def ndiag(n):
    from model import ndiag_pairs
    return ndiag_pairs(n)
def cum(rec, X, field):
    S = np.array(rec["S"], float); v = np.array(rec[field], float)
    v = np.where(np.isfinite(v), v, -1e9)
    if X <= S[0]: return 0.0
    m = S <= X; Sx = S[m]; vx = v[m]
    if m.sum() < len(S) and X > Sx[-1]:
        j = m.sum(); t = (X - S[j - 1]) / (S[j] - S[j - 1])
        Sx = np.append(Sx, X); vx = np.append(vx, v[j - 1] + t * (v[j] - v[j - 1]))
    tot = 0.0
    for a, b, va, vb in zip(Sx[:-1], Sx[1:], vx[:-1], vx[1:]):
        h = b - a
        if abs(vb - va) < 1e-9: tot += h * math.exp(va)
        else: tot += h * (math.exp(vb) - math.exp(va)) / (vb - va)
    return tot
if __name__ == "__main__":
    n, X, tmin, nsamp, out = int(sys.argv[1]), float(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]), sys.argv[5]
    dmin = int(sys.argv[6]) if len(sys.argv) > 6 else 18
    cl = screened(n, X, tmin, min_near=dmin)
    random.seed(1)
    pick = cl if nsamp <= 0 or nsamp >= len(cl) else random.sample(cl, nsamp)
    res = []
    t0 = time.time()
    for i, (dn, P) in enumerate(pick):
        try:
            r = eval_P(P, n, X)
        except Exception as e:
            print("fail", P, e, file=sys.stderr); continue
        if r: r["dnear"] = dn; res.append(r)
        if i % 100 == 0:
            print(i, len(pick), round(time.time() - t0), file=sys.stderr, flush=True); save()
    save()
    json.dump(dict(n=n, X=X, ncand=len(cl), nsamp=len(pick), res=res), open(out, "w"))
