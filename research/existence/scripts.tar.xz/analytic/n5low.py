"""n = 5: model N_semi(S <= X) per P for small X; rank P (to test the prediction that 5x5 AM semi-magic
squares exist with S ~ 360-480)."""
import os, sys, json, math
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import numpy as np, gmodel, maxent
from cands2 import gen2
from smin import save
from gs3 import tau
X = float(sys.argv[1]) if len(sys.argv) > 1 else 500
C = gen2(5, 50, X, kmin=3, kmax=10, omax=6, max_primes=11, tau_min=100)
rows = []
for P in C:
    r = gmodel.eval_P(P, 5, X * 1.0001, npts=40)
    if r is None: continue
    rows.append((gmodel.cum(r["S"], r["lEs_lin"], X), gmodel.cum(r["S"], r["lEm_lin"], X), P, r["smin"]))
    maxent._div_cache.clear()
save()
rows.sort(key=lambda t: -t[0])
tot = sum(t[0] for t in rows)
print(len(C), "P (sorted exponents, scale <= X); total N_semi(S <= %d) = %.3g, N_magic = %.3g" % (X, tot, sum(t[1] for t in rows)))
c = 0
for t in rows[:40]:
    c += t[0]; print("  ", t[2], "smin", int(t[3]), "E_semi %.3g" % t[0], "cum share %.2f" % (c / tot))
json.dump([dict(P=t[2], Es=t[0], Em=t[1], smin=t[3]) for t in rows], open("n5low_%d.json" % X, "w"))
