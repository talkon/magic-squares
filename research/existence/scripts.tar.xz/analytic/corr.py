"""Per-prime 'local' correction factors: exact lattice counts of exponent matrices
divided by their Gaussian (max-entropy) approximations."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import math, collections, os
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
EX = collections.defaultdict(dict)  # EX[(n,mode)][a] = count
for line in open(os.path.join(HERE, "c/ehr.txt")):
    n, a, mode, c = line.split()
    EX[(int(n), int(mode))][int(a)] = float(c)

def maxent_entry(a, n):
    """truncated geometric on 0..a with mean a/n: (entropy, variance)"""
    xs = np.arange(a + 1, dtype=float)
    m = a / n
    lo, hi = -50.0, 50.0
    for _ in range(200):
        t = (lo + hi) / 2
        w = np.exp(t * xs - (t * xs).max()); w /= w.sum()
        if w @ xs < m: lo = t
        else: hi = t
    var = w @ xs**2 - (w @ xs)**2
    H = -(w[w > 0] * np.log(w[w > 0])).sum()
    return H, var

def gauss(a, n):
    h, v = maxent_entry(a, n)
    L = math.log(2 * math.pi)
    g_semi = n * n * h - 0.5 * (2 * n - 1) * (L + math.log(v)) - (n - 1) * math.log(n)
    g_vec = n * h - 0.5 * (L + math.log(n * v))
    g_T = -0.5 * (L + math.log((n - 1) * v))
    if n % 2 == 0:
        g_M = -(L + math.log(v)) - 0.5 * math.log((n - 1) ** 2 - 1)
    else:
        g_M = -(L + math.log(v)) - math.log(n - 1)
    return dict(semi=g_semi, vec=g_vec, T=g_T, M=g_M)

def corrections(n, a):
    """log correction factors (exact/Gaussian) for line sum a; None where unknown"""
    g = gauss(a, n)
    out = {}
    out["vec"] = math.log(math.comb(a + n - 1, n - 1)) - g["vec"]
    H = EX[(n, 0)].get(a)
    out["semi"] = math.log(H) - g["semi"] if H else None
    T = EX[(n, 1)].get(a)
    out["T"] = math.log(T / H) - g["T"] if (T and H) else None
    M = EX[(n, 2)].get(a)
    out["M"] = math.log(M / H) - g["M"] if (M and H) else None
    return out

if __name__ == "__main__":
    for n in (4, 5, 6, 7, 8):
        print("n =", n)
        for a in range(1, 13):
            c = corrections(n, a)
            f = lambda v: "   -   " if v is None else f"{math.exp(v):7.4f}"
            print(f"  a={a:2d} vec {f(c['vec'])} semi {f(c['semi'])} T {f(c['T'])} M {f(c['M'])}")

# ---- general access with extrapolation ------------------------------------
from functools import lru_cache
@lru_cache(maxsize=None)
def _fit(kind, n):
    from extrap import fit_LAB
    try:
        from ehrpoly import poly
        Hp = poly(n) if n in (3, 4, 5, 6) else None
    except Exception:
        Hp = None
    vals = {}
    for a in range(1, 40):
        if kind == "semi" and Hp is not None:
            vals[a] = math.log(float(Hp(a))) - gauss(a, n)["semi"]
        else:
            c = corrections(n, a)[kind]
            if c is not None:
                vals[a] = c
    a = np.array(sorted(x for x in vals if x >= 2), dtype=float)
    y = np.array([vals[int(x)] for x in a])
    p = fit_LAB(a, y) if len(a) >= 3 else None
    return vals, p

@lru_cache(maxsize=None)
def logc(kind, n, a):
    """log of exact/Gaussian correction for one prime with exponent a"""
    if a <= 0:
        return 0.0
    if kind == "vec":
        return corrections(n, a)["vec"]
    vals, p = _fit(kind, n)
    if a in vals:
        return vals[a]
    if p is None:
        am = max(vals)
        return vals[am] * am / a
    L, A, B = p
    return min(0.0, L - A / (a + B))
