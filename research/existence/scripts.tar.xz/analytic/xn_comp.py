"""components() for n=5 and n=7 observed sums (subsample n=5 by predicted weight)."""
import os, sys
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json, math, numpy as np, random, time
from model import components
out = {}
for fn, n in (("compare_n7all.jsonl.json", 7), ("compare_n7_10_4_2_2_1_1.jsonl.json", 7), ("compare_n5_survey.jsonl.json", 5), ("compare_n6low.jsonl.json", 6)):
    d = json.load(open(fn))
    keys = list(d)
    if len(keys) > 3000:
        lE = np.array([d[k]["lE"] for k in keys]); obs = np.array([d[k]["obs"] for k in keys])
        # take every sum with obs>0 and the top 2500 by predicted weight, plus 500 random others (weights tracked)
        order = np.argsort(-lE)
        top = set(order[:2500].tolist()) | set(np.nonzero(obs > 0)[0].tolist())
        rest = [i for i in range(len(keys)) if i not in top]
        random.seed(3); rs = random.sample(rest, 500)
        sel = [(i, 1.0) for i in top] + [(i, len(rest) / 500) for i in rs]
    else:
        sel = [(i, 1.0) for i in range(len(keys))]
    t0 = time.time()
    for i, wgt in sel:
        k = keys[i]; Ps, S, nn = k.split("|")
        P = tuple(int(x) for x in Ps.split(",")); S = int(S)
        try: c = components(P, S, n, pairs=False)
        except Exception as e: print("fail", k, e, file=sys.stderr); continue
        out[fn + "|" + k] = dict(obs=d[k]["obs"], N=d[k]["N"], w=wgt, comp={a: (float(b) if not isinstance(b, int) else b) for a, b in c.items()})
    print(fn, len(sel), round(time.time() - t0, 1), file=sys.stderr, flush=True)
json.dump(out, open("xn_comp.json", "w"))
