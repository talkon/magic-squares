"""Per-scale (half-octave) totals of F(P) = sum over all S (<= 3 S_min) of E_semi, E_magic,
by two-phase stratified sampling over a candidate list."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import sys, json, math, random, time, collections
import numpy as np
from gsum import eval_P, cum
from smin import save
from screen import dnear
from cands2 import gen2
PRL = [math.log(p) for p in [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31]]
def scale(P, n): return n * math.exp(sum(a * l for a, l in zip(P, PRL)) / n)
def stratum(P, dn, n):
    k = sum(1 for a in P if a); ones = sum(1 for a in P if a == 1)
    return (k, min(ones, 4), min(dn // 40, 8), int(math.log2(scale(P, n)) * 2))
def F(P, n):
    r = eval_P(P, n, 1e12)
    if r is None: return 0.0, 0.0, None
    return cum(r, 1e12, "lEs"), cum(r, 1e12, "lEm"), r
if __name__ == "__main__":
    n, Xlo, Xhi, omax, n1, n2, out = int(sys.argv[1]), float(sys.argv[2]), float(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5]), int(sys.argv[6]), sys.argv[7]
    kmax = int(sys.argv[8]) if len(sys.argv) > 8 else 8
    mp = int(sys.argv[9]) if len(sys.argv) > 9 else 10
    t0 = time.time()
    cands = gen2(n, Xlo, Xhi, omax=omax, kmax=kmax, max_primes=mp)
    cands = [(dnear(P, n), P) for P in cands]
    print("candidates", len(cands), round(time.time() - t0), file=sys.stderr, flush=True)
    strata = collections.defaultdict(list)
    for dn, P in cands: strata[stratum(P, dn, n)].append((dn, P))
    random.seed(11)
    def run(lst):
        res = []
        for i, (dn, P) in enumerate(lst):
            try: fs, fm, r = F(P, n)
            except Exception: fs, fm = 0.0, 0.0
            res.append(dict(P=list(P), dn=dn, Fs=fs, Fm=fm, st="|".join(map(str, stratum(P, dn, n)))))
            if i % 200 == 0: print(i, len(lst), round(time.time() - t0), file=sys.stderr, flush=True); save()
        return res
    ph1 = random.sample(cands, min(n1, len(cands)))
    res = run(ph1)
    done = {tuple(r["P"]) for r in res}
    byst = collections.defaultdict(list); coarse = collections.defaultdict(list)
    for r in res:
        byst[r["st"]].append(r["Fm"]); coarse[tuple(r["st"].split("|")[:3])].append(r["Fm"])
    alloc = {}
    for key, lst in strata.items():
        ks = "|".join(map(str, key))
        v = byst.get(ks) or coarse.get(tuple(ks.split("|")[:3])) or [0.0]
        alloc[key] = len(lst) * (math.sqrt(np.mean(np.square(v))) + 1e-15)
    tw = sum(alloc.values())
    ph2 = []
    for key, lst in strata.items():
        m = int(round(n2 * alloc[key] / tw))
        rest = [c for c in lst if c[1] not in done]
        ph2 += random.sample(rest, min(m, len(rest)))
    res += run(ph2)
    save()
    json.dump(dict(n=n, strata={"|".join(map(str, k)): len(v) for k, v in strata.items()}, res=res), open(out, "w"))
