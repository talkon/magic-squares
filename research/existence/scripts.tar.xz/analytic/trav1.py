import json, math, numpy as np, collections
from load import load
from maxent import predict, PRIMES
sums, squares = load()
cache = {}
rows = []
for (P, S, h), r in squares.items():
    if (P, S) not in cache:
        cache[(P, S)] = predict(P, S)
    o = cache[(P, S)]
    g = np.array(r["grid"], dtype=float)
    # within-square stats
    v = g.var() * 36 / 35
    k = len(P)
    E = np.zeros((36, k))
    for c, x in enumerate(g.ravel()):
        x = int(x)
        for i in range(k):
            p = PRIMES[i]
            while x % p == 0:
                x //= p; E[c, i] += 1
    idx = [i for i in range(k) if P[i] > 0]
    E = E[:, idx]
    Cfull = np.cov(np.concatenate([g.ravel()[:, None], E], axis=1).T)
    ldC = np.linalg.slogdet(Cfull)[1]
    ldCe = np.linalg.slogdet(Cfull[1:, 1:])[1]
    kk = len(idx)
    sq_pS = -0.5 * (math.log(2 * math.pi * 5) + math.log(v))
    sq_pP = -0.5 * (kk * math.log(2 * math.pi * 5) + ldCe)
    sq_pSP = -0.5 * ((1 + kk) * math.log(2 * math.pi * 5) + ldC)
    rows.append(dict(P=P, S=S, s=r["s_count"], p=r["p_count"], sp=r["sp_count"],
                     me_pS=o["log_pS"], me_pP=o["log_pP"], me_pSP=o["log_pSP"],
                     sq_pS=sq_pS, sq_pP=sq_pP, sq_pSP=sq_pSP, ones=sum(1 for a in P if a == 1),
                     k=kk))
json.dump(rows, open("trav1.json", "w"))
def rep(sel, name):
    s = sum(r["s"] for r in sel); p = sum(r["p"] for r in sel); sp = sum(r["sp"] for r in sel)
    T = 720 * len(sel)
    print(f"{name}: squares {len(sel)}  obs pS {s/T:.2e} pP {p/T:.2e} pSP {sp/T:.2e} ({sp} SP)")
    for src in ("me", "sq"):
        eS = sum(math.exp(r[src + "_pS"]) for r in sel) / len(sel)
        eP = sum(math.exp(r[src + "_pP"]) for r in sel) / len(sel)
        eSP = sum(math.exp(r[src + "_pSP"]) for r in sel) / len(sel)
        print(f"   {src}: pS {eS:.2e} (obs/pred {s/T/eS:.3f})  pP {eP:.2e} ({p/T/eP:.3f})  pSP {eSP:.2e} ({sp/T/eSP:.3f})  rho_pred {eSP/eS/eP:.2f}")
rep(rows, "all")
for o in range(4):
    rep([r for r in rows if r["ones"] == o], f"ones={o}")
for k in (4, 5, 6):
    rep([r for r in rows if r["k"] == k], f"k={k}")
