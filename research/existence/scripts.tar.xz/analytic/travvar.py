import json, math, numpy as np, collections
from load import load
from model import assemble
sums, squares = load()
d = json.load(open("calib3.json"))
comp = {(tuple(r["P"]), r["S"]): r["comp"] for r in d}
for name, v in [("gauss", dict(edge=False, local=False)), ("gauss+local", dict(edge=False)), ("gauss+edge+local", dict(edge=True))]:
    tot = collections.Counter(); pred = collections.Counter()
    grp = collections.defaultdict(lambda: collections.Counter())
    for (P, S, h), r in squares.items():
        a = assemble(comp[(P, S)], **v)
        ones = sum(1 for x in P if x == 1)
        for key, obs, lp in (("S", r["s_count"], a["lpS"]), ("P", r["p_count"], a["lpP"]), ("SP", r["sp_count"], a["lpSP"])):
            tot[key] += obs; pred[key] += 720 * math.exp(lp)
            grp[ones][key] += obs; grp[ones]["pred" + key] += 720 * math.exp(lp)
        # pair predictions for S+S, P+P (one fixed diagonal pair) -> compare with s_count choose 2 style later
    print(f"{name:18s}", "  ".join(f"{k}: obs {tot[k]} pred {pred[k]:.1f} ratio {tot[k]/pred[k]:.3f}" for k in ("S", "P", "SP")),
          " rho_pred %.2f" % ((pred["SP"] / 720) / ((pred["S"] / 720) * (pred["P"] / 720)) / len(squares)))
    for o in sorted(grp):
        g = grp[o]
        print("     ones=%d" % o, "  ".join(f"{k} {g[k]/g['pred'+k]:.3f}" for k in ("S", "P", "SP")))
