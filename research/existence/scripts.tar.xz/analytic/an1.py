import json, math, numpy as np, collections
from smin import smin, save
d = json.load(open("calib1.json"))
for r in d: r["smin"] = smin(tuple(r["P"]))
save()
N = np.array([r["N"] for r in d]); lN = np.log(np.maximum(N, 1))
lNp = np.array([r["logN"] for r in d])
x = np.array([r["S"] / r["smin"] for r in d])
m = N >= 5
res = lN[m] - lNp[m]
print("log(N_obs/N_pred): mean %.3f sd %.3f  (N>=5, %d sums)" % (res.mean(), res.std(), m.sum()))
for lo, hi in [(5, 30), (30, 100), (100, 300), (300, 1000), (1000, 3000), (3000, 10000)]:
    mm = (N >= lo) & (N < hi)
    if mm.sum(): print(f"  N in [{lo},{hi}): n={mm.sum():5d} mean {np.mean(lN[mm]-lNp[mm]):+.3f} sd {np.std(lN[mm]-lNp[mm]):.3f}")
for lo, hi in [(1, 1.1), (1.1, 1.2), (1.2, 1.4), (1.4, 1.7), (1.7, 2.2), (2.2, 4)]:
    mm = (x >= lo) & (x < hi) & m
    if mm.sum(): print(f"  S/Smin in [{lo},{hi}): n={mm.sum():5d} mean {np.mean(lN[mm]-lNp[mm]):+.3f} sd {np.std(lN[mm]-lNp[mm]):.3f}")
# squares
sq = np.array([r["sq"] for r in d]); E = np.exp([r["logE_semi"] for r in d])
print("total squares obs %d, pred %.1f (ratio %.3f)" % (sq.sum(), E.sum(), sq.sum() / E.sum()))
for lo, hi in [(0, 200), (200, 400), (400, 700), (700, 1000), (1000, 1500), (1500, 2500), (2500, 4000), (4000, 9000)]:
    mm = (N >= lo) & (N < hi)
    if mm.sum(): print(f"  N in [{lo},{hi}): sums {mm.sum():5d} obs {sq[mm].sum():5d} pred {E[mm].sum():9.2f} ratio {sq[mm].sum()/E[mm].sum():.3f}")
for lo, hi in [(1, 1.1), (1.1, 1.2), (1.2, 1.3), (1.3, 1.45), (1.45, 1.6), (1.6, 1.8), (1.8, 2.2), (2.2, 4)]:
    mm = (x >= lo) & (x < hi)
    if mm.sum(): print(f"  S/Smin in [{lo},{hi}): sums {mm.sum():5d} obs {sq[mm].sum():5d} pred {E[mm].sum():9.2f} ratio {sq[mm].sum()/max(E[mm].sum(),1e-9):.3f}")
