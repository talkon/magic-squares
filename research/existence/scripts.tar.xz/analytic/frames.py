"""Exact count of ordered 2x2 'frames' (R1,R2 disjoint rows; C1,C2 disjoint cols;
|Ri & Cj| = 1) from the vector set, vs the max-entropy prediction."""
import sys, math, numpy as np
from smallcount import vectors
from model import components
from maxent import solve, log_esym_distinct
from corr import logc
def exact_frames(V, n):
    labs = sorted({x for v in V for x in v}); idx = {x: i for i, x in enumerate(labs)}
    M = np.zeros((len(V), len(labs)), dtype=np.float32)
    for t, v in enumerate(V):
        for x in v: M[t, idx[x]] = 1
    O = M @ M.T
    E1 = (O == 1).astype(np.float32); Z = (O == 0).astype(np.float32)
    np.fill_diagonal(Z, 0)
    tot = 0.0
    for r1 in range(len(V)):
        disj = np.nonzero(Z[r1])[0]
        if len(disj) == 0: continue
        A = E1[disj] * E1[r1][None, :]       # A[r2, c] = c meets r1 once and r2 once
        tot += float(((A @ Z) * A).sum())
    return tot
def pred_frames(P, S, n):
    r = solve(P, S, n)
    k, C, H = r["k"], r["C"], r["H"]; q = 1 + k
    AA = np.array([[n, 0, 1, 1], [0, n, 1, 1], [1, 1, n, 0], [1, 1, 0, n]], dtype=float)
    ldC = np.linalg.slogdet(C)[1]
    lg = (4 * n - 4) * H - 2 * q * math.log(2 * math.pi) - 0.5 * q * math.log(np.linalg.det(AA)) - 2 * ldC
    ld = log_esym_distinct(r["logw"], 4 * n - 4)
    loc = 4 * sum(logc("vec", n, a) for a in P if a > 0)
    return lg + ld + loc - 4 * math.lgamma(n - 1)
if __name__ == "__main__":
    n = int(sys.argv[1]); P = tuple(int(x) for x in sys.argv[2].split(","))
    for S in map(int, sys.argv[3:]):
        V = vectors(P, S, n)
        ex = exact_frames(V, n)
        lp = pred_frames(P, S, n)
        o = components(P, S, n, pairs=False)
        lN = o["base_tup"] + o["loc_vec"] + o["ld_n"] - o["lfact"]
        print(S, "N", len(V), "pred N %.0f" % math.exp(lN), "frames exact %.4g pred %.4g ratio %.3f" % (ex, math.exp(lp), ex / math.exp(lp)), flush=True)
