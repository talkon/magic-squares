import math, numpy as np
def log_pdist_saddle_vec(W, m, iters=60):
    """Vectorized log(m! e_m(w)) per row of W (rows = probability vectors): saddle point
    over all rows at once (Newton in log z, bracketed)."""
    W = np.atleast_2d(W)
    R = W.shape[0]
    lo = np.full(R, -60.0); hi = np.full(R, 60.0)
    t = np.full(R, math.log(m))
    # initial guess: z ~ m / (1 - m * sum w^2)?  start from bisection-ish
    for it in range(iters):
        z = np.exp(t)[:, None]
        wz = W * z
        f = (wz / (1 + wz)).sum(1) - m
        fp = (wz / (1 + wz) ** 2).sum(1)
        lo = np.where(f < 0, t, lo); hi = np.where(f >= 0, t, hi)
        tn = t - f / np.maximum(fp, 1e-300)
        if np.abs(tn - t).max() < 1e-9: t = tn; break
        bad = (tn < lo) | (tn > hi) | ~np.isfinite(tn)
        tn = np.where(bad, 0.5 * (lo + hi), tn)
        t = tn
    z = np.exp(t)[:, None]
    wz = W * z
    V = (wz / (1 + wz) ** 2).sum(1)
    return np.log1p(wz).sum(1) - m * t - 0.5 * np.log(2 * math.pi * V) + math.lgamma(m + 1)
if __name__ == "__main__":
    import time
    from esym import log_pdist_saddle
    rng = np.random.default_rng(1)
    W = rng.exponential(size=(22, 5000)) ** 3; W /= W.sum(1, keepdims=True)
    t = time.time(); a = log_pdist_saddle(W, 36); t1 = time.time() - t
    t = time.time(); b = log_pdist_saddle_vec(W, 36); t2 = time.time() - t
    print(np.abs(a - b).max(), t1, t2)
