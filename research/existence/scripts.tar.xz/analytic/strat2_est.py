import json, math, sys, collections, numpy as np
def est(fn, field):
    d = json.load(open(fn)); st = d["strata"]
    by = collections.defaultdict(list); coarse = collections.defaultdict(list)
    for r in d["res"]:
        by[r["st"]].append(r[field]); coarse[tuple(r["st"].split("|")[:3])].append(r[field])
    tot = collections.Counter(); var = collections.Counter(); cnt = collections.Counter(); miss = collections.Counter()
    for key, Nst in st.items():
        h = int(key.split("|")[3]); cnt[h] += Nst
        v = by.get(key)
        if not v:
            v = coarse.get(tuple(key.split("|")[:3])); miss[h] += Nst
            if not v: continue
        v = np.array(v); tot[h] += Nst * v.mean()
        var[h] += Nst ** 2 * (v.var(ddof=1) / len(v) if len(v) > 1 else v.mean() ** 2)
    return cnt, tot, var, miss
if __name__ == "__main__":
    for fn in sys.argv[1:]:
        for field in ("Fs", "Fm"):
            cnt, tot, var, miss = est(fn, field)
            print(fn, field)
            for h in sorted(cnt):
                print(f"   scale 2^{h/2:4.1f}={2**(h/2):8.0f}  #P {cnt[h]:7d} (unsampled strata {miss[h]:6d})  total {tot[h]:.4g} se {math.sqrt(var[h]):.2g}")
