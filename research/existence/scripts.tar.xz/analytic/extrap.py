import math, numpy as np
def fit_LAB(a, y):
    """fit y = L - A/(a+B) by grid over B and linear LS for (L, A)"""
    best = None
    for B in np.linspace(-0.9, 10, 1200):
        X = np.stack([np.ones_like(a, dtype=float), -1.0 / (a + B)], axis=1)
        c, *_ = np.linalg.lstsq(X, y, rcond=None)
        r = ((X @ c - y) ** 2).sum()
        if best is None or r < best[0]:
            best = (r, c[0], c[1], B)
    return best[1:]
