"""Vectorized gauss+local model over many S for one P (no Edgeworth)."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import math
import numpy as np
from maxent import divisors, norm
from corr import logc
from model import ndiag_pairs

def divisors_capped(P, cap):
    """divisors d <= cap of P (float64) with exponent matrix; pruned prime by prime."""
    from maxent import PRIMES
    idx = [i for i, a in enumerate(P) if a > 0]
    ds = np.array([1.0]); E = np.zeros((1, 0))
    for i in idx:
        p, a = PRIMES[i], P[i]
        pw = np.array([float(p) ** j for j in range(a + 1)])
        nd = (ds[:, None] * pw[None, :])
        ok = nd <= cap
        rows, cols = np.nonzero(ok)
        E = np.concatenate([E[rows], cols[:, None].astype(float)], axis=1)
        ds = nd[rows, cols]
    a = np.array([P[i] for i in idx], dtype=float)
    return ds, E, a

def batch(P, S, n=6, want_dist=True):
    P = norm(P)
    S = np.asarray(S, dtype=float)
    ds, E, a = divisors_capped(P, 80 * S.max() / n)
    k = len(a); q = 1 + k; m = len(S)
    X = np.concatenate([-ds[:, None], E], axis=1)          # tau x q
    T = np.concatenate([-(S / n)[:, None], np.tile(a / n, (m, 1))], axis=1)  # m x q
    XX = (X[:, :, None] * X[:, None, :]).reshape(len(ds), q * q)
    th = np.zeros((m, q)); th[:, 0] = n / S                  # beta / (S/n) start
    def evalf(th):
        Z = th @ X.T                                         # m x tau
        zm = Z.max(1, keepdims=True)
        W = np.exp(Z - zm); Zs = W.sum(1, keepdims=True)
        W /= Zs
        val = (np.log(Zs[:, 0]) + zm[:, 0]) - (th * T).sum(1)
        return val, W
    val, W = evalf(th)
    scale = np.concatenate([(S / n)[:, None], np.ones((m, k))], 1)
    for it in range(60):
        M = W @ X                                            # m x q
        g = M - T
        conv = np.abs(g / scale).max(1) < 1e-10
        if conv.all():
            break
        Hs = (W @ XX).reshape(m, q, q) - M[:, :, None] * M[:, None, :]
        step = np.linalg.solve(Hs + 1e-14 * np.eye(q)[None], g[:, :, None])[:, :, 0]
        step[conv] = 0.0
        t = np.ones(m)
        for _ in range(30):
            nv, nW = evalf(th - t[:, None] * step)
            bad = (nv > val - 1e-4 * t * (g * step).sum(1) + 1e-12 * np.abs(val)) & ~conv
            if not bad.any(): break
            t = np.where(bad, t * 0.5, t)
        th = th - t[:, None] * step
        val, W = nv, nW
    H = val
    M = W @ X
    C = (W @ XX).reshape(m, q, q) - M[:, :, None] * M[:, None, :]   # cov of (-d, e)
    ldC = np.linalg.slogdet(C)[1]
    ldCe = np.linalg.slogdet(C[:, 1:, 1:])[1] if k > 0 else np.zeros(m)
    varD = C[:, 0, 0]
    L2P = math.log(2 * math.pi)
    loc = {kk: sum(logc(kk, n, x) for x in P if x > 0) for kk in ("vec", "semi", "T", "M")}
    base_tup = n * H - 0.5 * q * L2P - 0.5 * (q * math.log(n) + ldC)
    base_grid = n * n * H - 0.5 * (2 * n - 1) * q * L2P - 0.5 * (2 * n - 1) * ldC - (n - 1) * q * math.log(n)
    lpS = -0.5 * (math.log(2 * math.pi * (n - 1)) + np.log(varD))
    lpP = -0.5 * (k * math.log(2 * math.pi * (n - 1)) + ldCe) + loc["T"]
    lpSP = -0.5 * (q * math.log(2 * math.pi * (n - 1)) + ldC) + loc["T"]
    cdd = -1.0 if n % 2 == 0 else 0.0
    ldpair = math.log((n - 1) ** 2 - cdd ** 2)
    lpair = -(q * L2P + ldC + 0.5 * q * ldpair) + loc["M"]
    out = dict(H=H, varD=varD, lpS=lpS, lpP=lpP, lpSP=lpSP, lpair=lpair,
               tup=base_tup + loc["vec"], grid=base_grid + loc["semi"])
    if want_dist:
        from esym2 import log_pdist_saddle_vec as log_pdist_saddle
        sel = W.max(0) > 1e-16
        ld_n = log_pdist_saddle(W[:, sel], n)
        ld_n2 = log_pdist_saddle(W[:, sel], n * n)
        out["ld_n"], out["ld_n2"] = ld_n, ld_n2
        out["logN"] = out["tup"] + ld_n - math.lgamma(n + 1)
        out["logEsemi"] = out["grid"] + ld_n2 - math.log(2) - 2 * math.lgamma(n + 1)
        out["logEmagic"] = out["logEsemi"] + math.log(ndiag_pairs(n)) + lpair
    return out

if __name__ == "__main__":
    import time
    from model import components, assemble
    t = time.time()
    o = batch((10, 4, 3, 2), [200, 250, 327, 400])
    print(time.time() - t, o["logN"], o["logEsemi"], o["lpSP"], o["lpair"])
    for S in [200, 250, 327, 400]:
        a = assemble(components((10, 4, 3, 2), S, 6, pairs=False), edge=False)
        print(S, a["logN"], a["logEsemi"], a["lpSP"], a["lpair"])
    t = time.time(); o = batch((14, 7, 5, 3, 1, 1), np.arange(1500, 3000, 15)); print("100 S big P", time.time() - t)
