import itertools, math, sys, json, numpy as np, time
from gmodel import eval_P, cum, logP
from smin import save
n = int(sys.argv[1]); base = tuple(int(x) for x in sys.argv[2].split(",")); fac = float(sys.argv[3])
srt = tuple(sorted(base, reverse=True)); l0 = logP(srt)
t = time.time(); res = []; nskip = 0
for perm in sorted(set(itertools.permutations(base))):
    if (logP(perm) - l0) / n > math.log(fac): nskip += 1; continue
    r = eval_P(perm, n, 1e9)
    if r is None: continue
    res.append((perm, r["smin"], cum(r["S"], r["lEs_lin"], 1e9), cum(r["S"], r["lEm_lin"], 1e9), math.exp((logP(perm) - l0) / n)))
save()
res.sort(key=lambda x: -x[3])
tot_s = sum(x[2] for x in res); tot_m = sum(x[3] for x in res)
s0 = [x for x in res if x[0] == srt][0]
print(base, "perms evaluated", len(res), "skipped (scale >", fac, "x sorted)", nskip, "time %.1f" % (time.time() - t))
print("  sorted: smin %.0f Fs %.3g Fm %.3g" % (s0[1], s0[2], s0[3]))
print("  all evaluated perms: Fs %.3g (x%.2f)  Fm %.3g (x%.2f)" % (tot_s, tot_s / s0[2], tot_m, tot_m / s0[3]))
for lo, hi in [(1, 1.05), (1.05, 1.1), (1.1, 1.2), (1.2, 1.4), (1.4, 2)]:
    sel = [x for x in res if lo <= x[4] < hi + 1e-9]
    print(f"   scale ratio [{lo},{hi}) perms {len(sel):4d} Fm sum/sorted {sum(x[3] for x in sel)/s0[3]:.3f} Fs {sum(x[2] for x in sel)/s0[2]:.3f}")
for x in res[:5]: print("   ", x[0], round(x[1]), "%.3g %.3g" % (x[2], x[3]))
