"""Candidate P (exponent vectors over 2,3,5,...,) with n*P^(1/n) <= X."""
import math, itertools
PR = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31]
LP = [math.log(p) for p in PR]
def gen(n, X, tau_min=1, max_primes=9, allow_gap=True):
    """exponent tuples (trailing zeros stripped), with a_i nonincreasing in i over
    the nonzero entries, at most one zero 'gap' among the first nonzero primes."""
    Lmax = n * math.log(X / n)
    out = []
    def rec(i, prev, logP, tau, cur, gaps):
        if i == max_primes:
            if cur and tau >= tau_min: out.append(tuple(cur))
            return
        # option: stop here
        if cur and tau >= tau_min:
            out.append(tuple(cur))
        for a in range(min(prev, int((Lmax - logP) / LP[i])), 0, -1):
            rec(i + 1, a, logP + a * LP[i], tau * (a + 1), cur + [a], gaps)
        if allow_gap and gaps == 0 and i >= 3 and cur:
            # skip prime i (exponent 0) and continue
            rec(i + 1, prev, logP, tau, cur + [0], 1)
    rec(0, 10 ** 9, 0.0, 1, [], 0)
    # strip trailing zeros & dedupe
    res = set()
    for P in out:
        P = list(P)
        while P and P[-1] == 0: P.pop()
        res.add(tuple(P))
    return sorted(res)
if __name__ == "__main__":
    import sys
    n, X, tmin = int(sys.argv[1]), float(sys.argv[2]), int(sys.argv[3])
    c = gen(n, X, tmin)
    print(len(c), c[:5], c[-5:])
