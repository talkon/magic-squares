import json, math, numpy as np, collections
from corr import logc
from smin import smin
d = json.load(open("calib1.json"))
def cs(P, kind, n=6): return sum(logc(kind, n, a) for a in P if a > 0)
for r in d:
    P = tuple(r["P"]); r["smin"] = smin(P)
    r["logN_c"] = r["logN"] + cs(P, "vec")
    r["logE_c"] = r["logE_semi"] + cs(P, "semi")
N = np.array([r["N"] for r in d]); lN = np.log(N)
for key in ("logN", "logN_c"):
    res = lN - np.array([r[key] for r in d])
    print(key, "log(obs/pred) mean %.3f sd %.3f" % (res.mean(), res.std()))
sq = np.array([r["sq"] for r in d])
for key in ("logE_semi", "logE_c"):
    E = np.exp([r[key] for r in d])
    print(key, "obs/pred total %.4f" % (sq.sum() / E.sum()))
E = np.exp([r["logE_c"] for r in d])
x = np.array([r["S"] / r["smin"] for r in d])
for lo, hi in [(0, 400), (400, 700), (700, 1000), (1000, 1500), (1500, 2500), (2500, 9000)]:
    mm = (N >= lo) & (N < hi)
    print(f"  N in [{lo},{hi}): sums {mm.sum():5d} obs {sq[mm].sum():5d} pred {E[mm].sum():9.1f} ratio {sq[mm].sum()/E[mm].sum():.4f}")
for lo, hi in [(1, 1.1), (1.1, 1.2), (1.2, 1.3), (1.3, 1.45), (1.45, 1.6), (1.6, 1.8), (1.8, 2.2), (2.2, 4)]:
    mm = (x >= lo) & (x < hi)
    print(f"  S/Smin in [{lo},{hi}): sums {mm.sum():5d} obs {sq[mm].sum():5d} pred {E[mm].sum():9.1f} ratio {sq[mm].sum()/max(E[mm].sum(),1e-9):.4f}")
g = collections.defaultdict(lambda: [0, 0.0])
gk = collections.defaultdict(lambda: [0, 0.0])
byP = collections.defaultdict(lambda: [0, 0.0])
for r, e in zip(d, E):
    P = tuple(r["P"]); ones = sum(1 for a in P if a == 1); k = sum(1 for a in P if a)
    g[ones][0] += r["sq"]; g[ones][1] += e
    gk[k][0] += r["sq"]; gk[k][1] += e
    byP[P][0] += r["sq"]; byP[P][1] += e
print("by #(a_p=1):", {k: (v[0], round(v[1]), round(v[0]/v[1], 4)) for k, v in sorted(g.items())})
print("by k:", {k: (v[0], round(v[1]), round(v[0]/v[1], 4)) for k, v in sorted(gk.items())})
rat = sorted((v[0] / v[1], P, v[0]) for P, v in byP.items() if v[0] >= 10)
lr = np.log([t[0] for t in rat])
print("per-P log ratio (P with >=10 squares): n=%d mean %.3f sd %.3f; min %.4f max %.4f" % (len(lr), lr.mean(), lr.std(), rat[0][0], rat[-1][0]))
for t in rat[:5] + rat[-5:]: print("   ", t)
json.dump(d, open("calib1c.json", "w"))
