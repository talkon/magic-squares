import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json, math, numpy as np, collections
from model import assemble
X = json.load(open("xn_comp.json"))
c3 = json.load(open("calib3.json"))
groups = collections.defaultdict(list)
for k, r in X.items():
    tag = "n5" if "n5_survey" in k else ("n6low" if "n6low" in k else "n7")
    groups[tag].append((r["obs"], r["w"], r["comp"]))
groups["n6near"] = [(r["sq"], 1.0, r["comp"]) for r in c3]
for v in [dict(edge=False), dict(edge=True)]:
    print(v)
    for tag in ("n5", "n6low", "n6near", "n7"):
        g = groups[tag]
        obs = np.array([a for a, w, c in g]); w = np.array([w for a, w, c in g])
        A = [assemble(c, **v) for a, ww, c in g]
        E = np.exp([a["logEsemi"] for a in A]); ld = np.array([c["ld_n2"] for a, ww, c in g])
        tot_o = (obs * w).sum(); tot_e = (E * w).sum()
        wl = (E * w * ld).sum() / tot_e
        Eedge = np.array([c["edge_grid"] for a, ww, c in g]); Eloc = np.array([c["loc_semi"] for a, ww, c in g])
        print(f"  {tag:6s} sums {len(g):5d} obs {tot_o:7.0f} pred {tot_e:9.1f} log(obs/pred) {math.log(tot_o/tot_e):+.2f}  pred-weighted ld {wl:6.1f}"
              f"  edge_grid {(E*w*Eedge).sum()/tot_e:+.2f} loc_semi {(E*w*Eloc).sum()/tot_e:+.2f}")
