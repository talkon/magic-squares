"""Calibrated per-P model for global sums (n = 5..8).
log E_semi(P,S) = batch.logEsemi + C0 + B*ld + DN*(n-6)        (cross-n Poisson fit, xn_fit.py)
log E_magic     = log E_semi + log D_n + lpair + log KAPPA        (traversal calibration)
Alternative calibration 'quad' = previous run's K0 + K2 ld^2 + DELTA[n]."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import math, numpy as np
from batch2 import batch
from smin import smin
from model import ndiag_pairs
PR = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]
C0, B, DN = -0.597, 0.1365, -2.455
K0, K2, DELTA = -1.087, -0.0091, {5: 2.6, 6: 0.0, 7: -0.58, 8: -1.2}
KAPPA = 0.57
def logP(P): return sum(a * math.log(PR[i]) for i, a in enumerate(P))
def lK(ld, n, cal="lin"):
    if cal == "lin": return C0 + B * ld + DN * (n - 6)
    return K0 + K2 * ld ** 2 + DELTA[n]
NPTS = 26
def eval_P(P, n, Xmax, fmax=4.0, npts=None, exact_smin=True):
    npts = npts or NPTS
    P = tuple(P)
    lp = logP(P)
    s0 = None
    if exact_smin and lp < 62 * math.log(2):
        try: s0 = smin(P, n)
        except Exception: s0 = None
    if s0 is not None and s0 <= 0: s0 = None
    lo = s0 if s0 else 1.005 * n * math.exp(lp / n)
    if lo >= Xmax: return None
    hi = min(Xmax, fmax * lo)
    u = np.concatenate([[0.0], np.geomspace(2e-3, max(hi / lo - 1, 3e-3), npts - 1)])
    S = np.unique(np.round(lo * (1 + u)).astype(int)); S = S[S > lo]
    if len(S) < 2: return None
    o = batch(P, S.astype(float), n)
    ld = o["ld_n2"]
    base = o["logEsemi"]
    pair = math.log(ndiag_pairs(n)) + o["lpair"] + math.log(KAPPA)
    r = dict(P=P, smin=float(lo), exact=s0 is not None, S=S.tolist())
    for cal in ("lin", "quad"):
        les = base + lK(ld, n, cal)
        r["lEs_" + cal] = les; r["lEm_" + cal] = les + pair
    r["ld"] = ld; r["lpair"] = o["lpair"]; r["lN"] = o["logN"]
    return r
def cum(S, v, X):
    """sum over integer S' <= X of exp(v(S')) by log-linear interpolation on the grid S."""
    S = np.asarray(S, float); v = np.where(np.isfinite(v), v, -1e9)
    if X <= S[0]: return 0.0
    m = S <= X; Sx = S[m]; vx = v[m]
    if m.sum() < len(S) and X > Sx[-1]:
        j = m.sum(); t = (X - S[j - 1]) / (S[j] - S[j - 1])
        Sx = np.append(Sx, X); vx = np.append(vx, v[j - 1] + t * (v[j] - v[j - 1]))
    h = np.diff(Sx); dv = np.diff(vx)
    ea, eb = np.exp(vx[:-1]), np.exp(vx[1:])
    with np.errstate(divide="ignore", invalid="ignore"):
        seg = np.where(np.abs(dv) < 1e-9, h * ea, h * (eb - ea) / dv)
    return float(seg.sum())
