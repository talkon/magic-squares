"""Local slope d log E_semi / d log N along S within P (analytic model), by N range; and the magic-weighted
N distribution of the global n=6 total."""
import os, json, math, collections, numpy as np
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import gmodel, maxent
from gs3_est import est
d = json.load(open("pool_cmp.json")); res = d["res"]
import random; random.seed(4); pick = random.sample(res, 120)
sl = collections.defaultdict(list); slm = collections.defaultdict(list)
for r in pick:
    o = gmodel.eval_P(tuple(r["P"]), 6, 1e12, fmax=3.0, npts=30)
    if o is None: continue
    lN = np.array(o["lN"]); les = np.array(o["lEs_lin"]); lem = np.array(o["lEm_lin"]); S = np.array(o["S"], float)
    x = S / o["smin"]
    for i in range(1, len(S)):
        if x[i] < 1.05 or lN[i] - lN[i - 1] < 0.02: continue
        N = math.exp(0.5 * (lN[i] + lN[i - 1]))
        b = 0 if N < 3000 else 1 if N < 8000 else 2 if N < 20000 else 3
        sl[b].append((les[i] - les[i - 1]) / (lN[i] - lN[i - 1])); slm[b].append((lem[i] - lem[i - 1]) / (lN[i] - lN[i - 1]))
    maxent._div_cache.clear()
names = ["N<3000", "3000-8000", "8000-20000", ">20000"]
for b in sorted(sl):
    print(f"{names[b]:11s}: d logE_semi/d logN median {np.median(sl[b]):.2f} (IQR {np.percentile(sl[b],25):.2f}..{np.percentile(sl[b],75):.2f}); magic {np.median(slm[b]):.2f}  [n={len(sl[b])}]")
# global n=6: magic-weighted N of each sampled P (lN_w), stratified totals by bins
g = json.load(open("gs3_n6.json")); st = g["strata"]
by = collections.defaultdict(list)
for r in g["res"]: by["|".join(map(str, r["st"]))].append(r)
T = collections.Counter(); TT = 0.0
for key, Nst in st.items():
    v = by.get(key)
    if not v: continue
    for r in v:
        f = r["lEm_lin"][-1] * Nst / len(v)
        lw = r.get("lN_w")
        if lw is None or not np.isfinite(lw): continue
        N = math.exp(lw); b = 0 if N < 3000 else 1 if N < 8000 else 2 if N < 20000 else 3 if N < 60000 else 4
        T[b] += f; TT += f
print("global n=6 N_magic(inf) by magic-weighted N of the P:", {(names + ['>60000'])[b] if b < 4 else '>60000': round(T[b] / TT, 3) for b in sorted(T)})
