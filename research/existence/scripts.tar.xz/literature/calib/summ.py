import json, math, sys
import numpy as np
R = [json.loads(l) for l in open('gauss_out.jsonl')]
N = len(R)
print('N squares', N)
# consistency of recomputed exact counts with records
bad = sum(1 for r in R if (r['s'], r['p'], r['sp']) != (r['s_rec'], r['p_rec'], r['sp_rec']))
print('mismatch exact vs record:', bad)
print('lattice covol S != 1:', sum(r['covS'] != 1 for r in R), ' covP dist:', sorted(set(r['covP'] for r in R))[:10], ' covSP!=covP:', sum(r['covSP'] != r['covP'] for r in R))
s = np.array([r['s'] for r in R]); p = np.array([r['p'] for r in R]); sp = np.array([r['sp'] for r in R])
pS = np.array([r['pS'] for r in R]); pP = np.array([r['pP'] for r in R]); pSP = np.array([r['pSP'] for r in R])
print('S-trav: obs %d  pred %.1f  ratio %.3f' % (s.sum(), 720 * pS.sum(), s.sum() / (720 * pS.sum())))
print('P-trav: obs %d  pred %.1f  ratio %.3f' % (p.sum(), 720 * pP.sum(), p.sum() / (720 * pP.sum())))
print('SP-trav: obs %d  pred %.2f  ratio %.3f' % (sp.sum(), 720 * pSP.sum(), sp.sum() / (720 * pSP.sum())))
# independence prediction for SP using per-square EMPIRICAL p_S p_P (what scheduler-like models do)
print('SP pred from per-square empirical s*p/720: %.2f' % (np.sum(s * p) / 720))
print('SP pred from per-square Gaussian pS*pP (rho=1): %.2f' % (720 * np.sum(pS * pP)))
rho = np.array([r['rhoG_lat'] for r in R])
print('Gaussian rho per square: mean %.3f median %.3f  weighted by pS*pP %.3f' % (rho.mean(), np.median(rho), np.sum(rho * pS * pP) / np.sum(pS * pP)))
# bins by predicted pS
for name, obs, pr in [('S', s, pS), ('P', p, pP)]:
    q = np.quantile(pr, [0, .2, .4, .6, .8, 1])
    print(name, 'calibration by quintile of predicted p:')
    for lo, hi in zip(q[:-1], q[1:]):
        m = (pr >= lo) & (pr <= hi)
        print('   pred p %.2e-%.2e  n=%d  obs %d  pred %.1f  ratio %.2f' % (lo, hi, m.sum(), obs[m].sum(), 720 * pr[m].sum(), obs[m].sum() / (720 * pr[m].sum())))
# pair statistics (5400 diagonal pairs per square)
SS = np.array([r['SS'] for r in R]); PP = np.array([r['PP'] for r in R]); SPS = np.array([r['SPS'] for r in R]); SPP = np.array([r['SPP'] for r in R]); SpP = np.array([r['SpP'] for r in R])
print('pairs: S+S %d, P+P %d, S+P(any) %d, SP+S %d, SP+P %d' % (SS.sum(), PP.sum(), SpP.sum(), SPS.sum(), SPP.sum()))
# expected under within-square independence given the square's own counts: 5400 * (s/720)^2 approx; exact: number of pairs among hits if pairs were random among 5400 of C(720,2)
def exp_pairs(a, b=None):
    if b is None:
        return 5400 * a * (a - 1) / (720 * 719)
    return 5400 * 2 * a * b / (720 * 719)  # ordered both ways ~
print('S+S expected given own s (random pairs): %.1f  obs/exp %.3f' % (exp_pairs(s).sum(), SS.sum() / exp_pairs(s).sum()))
print('P+P expected given own p: %.1f  obs/exp %.3f' % (exp_pairs(p).sum(), PP.sum() / exp_pairs(p).sum()))
# expected using Gaussian per-square p (heterogeneity included, no within-square corr)
print('S+S expected 5400*sum pS^2: %.1f  obs/exp %.3f' % (5400 * np.sum(pS ** 2), SS.sum() / (5400 * np.sum(pS ** 2))))
print('P+P expected 5400*sum pP^2: %.1f  obs/exp %.3f' % (5400 * np.sum(pP ** 2), PP.sum() / (5400 * np.sum(pP ** 2))))
# heterogeneity factors within (P,S) groups
from collections import defaultdict
g = defaultdict(list)
for i, r in enumerate(R): g[(tuple(r['P']), r['S'])].append(i)
num = den = numP = denP = numSP = denSP = 0
for k, idx in g.items():
    a = pS[idx]; b = pP[idx]; c = pSP[idx]
    num += np.sum(a ** 2); den += np.sum(a) ** 2 / len(a)
    numP += np.sum(b ** 2); denP += np.sum(b) ** 2 / len(b)
    numSP += np.sum(c ** 2); denSP += np.sum(c) ** 2 / len(c)
print('heterogeneity within (P,S): E[pS^2]/E[pS]^2 = %.3f, pP %.3f, pSP %.3f' % (num / den, numP / denP, numSP / denSP))
rp = np.array([r['rpair'] for r in R])
print('corr of sum-deviation between the two diagonals of a diagonal pair: mean %.4f' % rp.mean())
# magic expectation per square under Gaussian model, pair-independent: 5400 pSP^2
print('sum over squares of 5400*pSP^2 (Gaussian) = %.3e ; per square mean %.3e = 1 in %.3g' % (5400 * np.sum(pSP ** 2), 5400 * np.mean(pSP ** 2), 1 / (5400 * np.mean(pSP ** 2))))
print('same with empirical-calibrated: 5400*(sp/720)^2 sum = %.3e' % (5400 * np.sum((sp / 720.) ** 2)))
