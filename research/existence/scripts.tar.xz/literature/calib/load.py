import json, glob, os
D = '/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad'
def load_squares():
    files = glob.glob(D + '/forecast/state/units/*.jsonl') + \
            [f for f in glob.glob(D + '/verify-forecast/**/*.jsonl', recursive=True)]
    seen = {}
    src = {}
    for f in files:
        with open(f) as fh:
            for line in fh:
                if '"square"' not in line: continue
                try: r = json.loads(line)
                except Exception: continue
                if r.get('type') != 'square' or r.get('n', 6) != 6: continue
                key = (tuple(r['P']), r['S'], r.get('hash') or json.dumps(r['grid']))
                if key in seen: continue
                seen[key] = r
                src[key] = 'main' if '/forecast/state/units/' in f and 'verify' not in f else 'verify'
    return list(seen.values()), src
if __name__ == '__main__':
    sq, src = load_squares()
    from collections import Counter
    print(len(sq), Counter(src.values()))
    print(sum(r['s_count'] for r in sq), sum(r['p_count'] for r in sq), sum(r['sp_count'] for r in sq))
    print(len(set(tuple(r['P']) for r in sq)), 'distinct P')
