"""Check a Gaussian local-limit model for traversal rates against our squares.

For each semi-magic square (6x6, all line sums S, products P):
  p_S(obs)   = s_count/720 (recomputed here from the grid)
  p_S(gauss) = 1/sqrt(2 pi Var_S), Var_S = n^2/(n-1) * var(entries)   (exact variance of the
               sum over a uniformly random traversal of a semi-magic square)
  per prime q: exact marginal m_q = P(traversal exponent sum = e_q), Gaussian g_q likewise
  p_P(indep) = prod_q m_q,  p_P(gauss) = prod_q g_q,  p_P(obs) = p_count/720
Aggregates over squares: sum of predicted vs observed counts.
"""
import json, glob, math, itertools, sys
from collections import defaultdict
PR = [2,3,5,7,11,13,17,19,23,29,31]
base = '/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/'
files = glob.glob(base+'forecast/state/units/*.jsonl') + glob.glob(base+'verify-forecast/*/*.jsonl')
seen=set(); sq=[]
for f in files:
    for line in open(f):
        try: r=json.loads(line)
        except Exception: continue
        if 'grid' in r and len(r['grid'])==6:
            key=(tuple(r['P']), r['S'], r.get('hash') or str(r['grid']))
            if key in seen: continue
            seen.add(key); sq.append(r)
print('squares', len(sq), file=sys.stderr)
perms = list(itertools.permutations(range(6)))
def val(e, x):
    c=0
    while x % e == 0: x//=e; c+=1
    return c
tot = defaultdict(float)
by_bin = defaultdict(lambda: defaultdict(float))
for r in sq:
    g=r['grid']; n=6; S=r['S']; P=r['P']
    ent=[x for row in g for x in row]
    mu=sum(ent)/36; var=sum((x-mu)**2 for x in ent)/36
    VS = n*n/(n-1)*var
    pS_g = 1/math.sqrt(2*math.pi*VS)
    primes=[PR[i] for i,e in enumerate(P) if e>0]
    E={q:[[val(q,x) for x in row] for row in g] for q in primes}
    s_ok=0; p_ok=0; sp_ok=0
    marg={q:0 for q in primes}
    for s in perms:
        ssum=sum(g[i][s[i]] for i in range(6))
        allp=True
        for q,eq in zip(primes,[e for e in P if e>0]):
            t=sum(E[q][i][s[i]] for i in range(6))
            if t==eq: marg[q]+=1
            else: allp=False
        s_ok += ssum==S; p_ok += allp; sp_ok += (allp and ssum==S)
    pP_ind=1.0; pP_g=1.0
    for q,eq in zip(primes,[e for e in P if e>0]):
        ex=[x for row in E[q] for x in row]; m=sum(ex)/36; v=sum((x-m)**2 for x in ex)/36
        pP_g *= 1/math.sqrt(2*math.pi*n*n/(n-1)*v)
        pP_ind *= marg[q]/720
    # sanity vs stored counts
    if r.get('s_count') is not None: tot['mismatch_s'] += (r['s_count']!=s_ok)
    if r.get('p_count') is not None: tot['mismatch_p'] += (r['p_count']!=p_ok)
    smin=None
    rel = 'all'
    for d in (tot, by_bin[len(primes)]):
        d['n']+=1
        d['S_obs']+=s_ok; d['S_gauss']+=720*pS_g
        d['P_obs']+=p_ok; d['P_indep']+=720*pP_ind; d['P_gauss']+=720*pP_g
        d['SP_obs']+=sp_ok; d['SP_indep']+=720*(s_ok/720)*(p_ok/720)
        d['SP_model_gauss']+=720*pS_g*pP_g
print('TOTAL', dict(tot))
for k in sorted(by_bin): print('nprimes',k, dict(by_bin[k]))
