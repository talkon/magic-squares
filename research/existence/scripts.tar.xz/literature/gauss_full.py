"""Multivariate Gaussian (local CLT) prediction of S-, P- and SP-traversal counts.
Traversal T = (sum, exponent sums for each prime) over a uniform random permutation.
For a semi-magic add-mult square all row/col means are equal, so
Cov(T_a, T_b) = 1/(n-1) * sum_ij (A_ij - mean A)(B_ij - mean B)   (exact).
Predicted density at the target lattice point = (2pi)^(-d/2) det(Cov)^(-1/2).
Compares with the exact counts over the 720 traversals (stored s_count, p_count, sp_count).
"""
import json, glob, math, sys
from collections import defaultdict
import numpy as np
PR = [2,3,5,7,11,13,17,19,23,29,31]
base = '/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/'
files = glob.glob(base+'forecast/state/units/*.jsonl') + glob.glob(base+'verify-forecast/*/*.jsonl')
seen=set(); sq=[]
for f in files:
    for line in open(f):
        try: r=json.loads(line)
        except Exception: continue
        if 'grid' in r and len(r['grid'])==6:
            key=(tuple(r['P']), r['S'], r.get('hash') or str(r['grid']))
            if key in seen: continue
            seen.add(key); sq.append(r)
def val(q,x):
    c=0
    while x%q==0: x//=q; c+=1
    return c
agg=defaultdict(float); byS=defaultdict(lambda: defaultdict(float))
for r in sq:
    g=np.array(r['grid'],dtype=float); n=6
    primes=[PR[i] for i,e in enumerate(r['P']) if e>0]
    rows=[g.flatten()]
    for q in primes:
        rows.append(np.array([val(q,int(x)) for x in g.flatten()],dtype=float))
    X=np.array(rows); Xc=X-X.mean(axis=1,keepdims=True)
    C=Xc@Xc.T/(n-1)
    d=len(primes)
    pS=1/math.sqrt(2*math.pi*C[0,0])
    CP=C[1:,1:]
    pP_diag=np.prod([1/math.sqrt(2*math.pi*CP[i,i]) for i in range(d)])
    pP_full=(2*math.pi)**(-d/2)/math.sqrt(np.linalg.det(CP))
    pSP_full=(2*math.pi)**(-(d+1)/2)/math.sqrt(np.linalg.det(C))
    s,p,sp=r['s_count'],r['p_count'],r['sp_count']
    # bin by S relative to smallest S seen for this P (proxy for S/S_min)
    for D in (agg,):
        D['n']+=1; D['S_obs']+=s; D['S_pred']+=720*pS
        D['P_obs']+=p; D['P_diag']+=720*pP_diag; D['P_full']+=720*pP_full
        D['SP_obs']+=sp; D['SP_full']+=720*pSP_full; D['SP_from_marg']+=s*p/720
        D['SP_gauss_indep']+=720*pS*pP_full
        D['rho_gauss_wsum']+=720*pSP_full  # same as SP_full
    k=len(primes)
    D=byS[k]
    D['n']+=1; D['P_obs']+=p; D['P_diag']+=720*pP_diag; D['P_full']+=720*pP_full; D['SP_obs']+=sp; D['SP_full']+=720*pSP_full; D['SP_gauss_indep']+=720*pS*pP_full
print('ALL', {k:round(v,2) for k,v in agg.items()})
for k in sorted(byS): print('nprimes',k,{a:round(b,2) for a,b in byS[k].items()})
