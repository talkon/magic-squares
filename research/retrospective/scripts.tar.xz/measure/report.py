#!/usr/bin/env python3
"""Generate the tables of measure.md from times.json and verify_sampling.json, and the
ratio model (ratio_model.json) for the retro forecasts.

usage: python3 analyze.py && python3 verify_sampling.py && python3 report.py
measure.md = measure_head.md (hand-written narrative) + generated tables.

ratio_model.json: per version, R_v(N) = t_v / t_current at N, piecewise linear in ln N
through the geometric-mean ratios of the N bins (knot at the geometric-mean N of each
bin's sums, constant beyond the end knots), from the sums measured by all main
versions, plus the per-version power-law fits; and t_v(N) = R_v(N) * t_current(N) is
the intended use (t_current from the existence time model).
"""
import json
import math
import os

HERE = os.path.dirname(os.path.abspath(__file__))
T = json.load(open(os.path.join(HERE, "times.json")))
V = json.load(open(os.path.join(HERE, "verify_sampling.json")))
VERS = ["legacy", "df352df", "8d07935", "a72cef3", "7cd9bc5", "2d2bc6d", "d023d32", "f61e719", "fdb77fc"]
MAIN = ["legacy", "df352df", "8d07935", "a72cef3", "2d2bc6d", "f61e719", "fdb77fc"]
CUR = T["current"]
BENCH = {"quick": "bench/quick.txt", "full": "bench/full.txt", "prod": "bench/prod.txt"}


def fmt_s(x):
    if x is None:
        return "-"
    if x >= 1e5:
        return "%.3g" % x
    if x >= 100:
        return "%.0f" % x
    if x >= 10:
        return "%.1f" % x
    if x >= 1:
        return "%.2f" % x
    if x >= 0.1:
        return "%.3f" % x
    return "%.4f" % x


def bench_sets():
    sets = {}
    for name, path in BENCH.items():
        keys = []
        for line in open(os.path.join("/home/user/magic-squares", path)):
            if line.startswith("#") or not line.strip():
                continue
            f = [x.strip() for x in line.split("|")]
            if f[0] != "6":
                continue
            keys.append((f[1], int(f[2])))
        sets[name] = keys
    return sets


def main():
    recs = T["records"]
    by = {(r["version"], r["P"], r["S"]): r for r in recs}
    sums = sorted(set((r["P"], r["S"], r["N"]) for r in recs), key=lambda x: x[2])
    out = []
    w = out.append

    # --- bench totals
    w("### Benchmark files (6x6 instances; full searches; CPU s, min of 1-3 repeats)\n")
    w("| version | " + " | ".join("%s (%d sums)" % (k, len(v)) for k, v in bench_sets().items()) + " | nodes, prod | ratio to current, prod |")
    w("|---|" + "---:|" * 5)
    bs = bench_sets()
    cur_prod = sum(by[(CUR, P, S)]["seconds"] for P, S in bs["prod"])
    for v in VERS:
        cells = []
        for name, keys in bs.items():
            if all((v, P, S) in by for P, S in keys):
                cells.append(fmt_s(sum(by[(v, P, S)]["seconds"] for P, S in keys)))
            else:
                cells.append("-")
        nodes = sum(by[(v, P, S)]["nodes"] for P, S in bs["prod"]) if all((v, P, S) in by for P, S in bs["prod"]) else None
        tp = sum(by[(v, P, S)]["seconds"] for P, S in bs["prod"])
        w("| %s | %s | %s | %.1f |" % (v, " | ".join(cells), "%.3gM" % (nodes / 1e6) if nodes else "-", tp / cur_prod))
    w("")

    # --- per sum times
    w("### Time per sum (CPU s; `~` = r1-sampled estimate, with its relative standard error)\n")
    w("| P | S | N | squares | " + " | ".join(VERS) + " |")
    w("|---|---:|---:|---:|" + "---:|" * len(VERS))
    for P, S, N in sums:
        anyr = next(r for r in recs if r["P"] == P and r["S"] == S)
        sq = anyr["squares_best"]
        sqs = ("%d" % sq) if anyr["squares_source"].startswith("full") else ("~%.0f" % sq)
        cells = []
        for v in VERS:
            r = by.get((v, P, S))
            if not r:
                cells.append("")
            elif r["full"]:
                cells.append(fmt_s(r["seconds"]))
            else:
                cells.append("~%s (%.0f%%)" % (fmt_s(r["seconds"]), 100 * r["rel_se"]))
        w("| %s | %d | %d | %s | %s |" % (P, S, N, sqs, " | ".join(cells)))
    w("")

    # --- strides used
    w("### Sampling of the large sums (stride k / r1 sampled, per version)\n")
    w("| P | S | N | " + " | ".join(MAIN) + " |")
    w("|---|---:|---:|" + "---|" * len(MAIN))
    for P, S, N in sums:
        if N < 3000:
            continue
        cells = []
        for v in MAIN:
            r = by.get((v, P, S))
            if not r:
                cells.append("")
            elif r["full"]:
                cells.append("full")
            else:
                cells.append(", ".join("%d/%d" % (p["k"], p["m"]) for p in r["parts"]))
        w("| %s | %d | %d | %s |" % (P, S, N, " | ".join(cells)))
    w("")

    # --- ratios
    w("### Ratio to the current code (fdb77fc) per sum: direct [paired on common r1]\n")
    w("Direct = ratio of the two estimates; paired = ratio of the summed per-r1 times over the r1 both versions sampled "
      "(nested samples); `*` = the one used (smaller standard error). Full searches: N < 3,000, and 14 7 5 3 S = 1656 "
      "for 2d2bc6d, f61e719, fdb77fc.\n")
    rat = {(r["version"], r["P"], r["S"]): r for r in T["ratios_to_current"]}
    vv = [v for v in VERS if v != CUR]
    w("| P | S | N | " + " | ".join(vv) + " |")
    w("|---|---:|---:|" + "---:|" * len(vv))
    for P, S, N in sums:
        cells = []
        for v in vv:
            r = rat.get((v, P, S))
            if not r:
                cells.append("")
                continue
            s = "%.2f" % r["ratio"]
            if r["paired"]:
                s += " [%.2f]" % r["paired"]["ratio"]
            if r.get("best_kind") == "paired":
                s += "*"
            cells.append(s)
        w("| %s | %d | %d | %s |" % (P, S, N, " | ".join(cells)))
    w("")

    # --- bins
    w("### By N: geometric-mean ratio to current, and CPU s per semi-magic square\n")
    w("Sums measured by all main versions; CPU s per square = total time of the bin's sums / their squares "
      "(full counts, or pooled sampled estimates for N > 10k).\n")
    w("Cells: geometric-mean ratio (range over the bin's sums) / CPU s per square.\n")
    w("| N range (sums, squares) | " + " | ".join(VERS) + " |")
    w("|---|" + "---:|" * len(VERS))
    for b in T["bins"]:
        cells = []
        for v in VERS:
            if v in b["ratio_gm"]:
                sps = b["seconds_per_square"].get(v)
                lo, hi = b["ratio_range"][v]
                cells.append("%.2f (%.1f-%.1f) / %s" % (b["ratio_gm"][v], lo, hi, fmt_s(sps) if sps else "-"))
            else:
                cells.append("")
        w("| %d-%d (%d, %s) | %s |" % (b["N_lo"], b["N_hi"], len(b["sums"]),
                                       ("%.0f" % b["squares"]), " | ".join(cells)))
    w("")

    # --- fits
    w("### Fits t(N) = a (N/4000)^b (CPU s per sum; least squares in ln t; resid sd in ln)\n")
    keys = ["N>=1000", "N<3000", "N>=3000", "N 3000-10000", "N>=10000"]
    w("| version | " + " | ".join(keys) + " |")
    w("|---|" + "---|" * len(keys))
    for v in VERS:
        f = T["fits"].get(v, {})
        cells = []
        for k in keys:
            g = f.get(k)
            cells.append("a %s, b %.2f (sd %.2f, n %d)" % (fmt_s(g["a"]), g["b"], g["resid_sd"], g["n"]) if g else "")
        w("| %s | %s |" % (v, " | ".join(cells)))
    w("")
    w("Sums with N < 25,000 (<= 256 labels); per-version times use `seconds_best`. Time per sum depends on P as well as N "
      "(resid sd 0.3-0.5 in ln), so these fits depend on the mix of P; the N >= 10,000 fits (3 sums of 2 P) are not "
      "meaningful. 7cd9bc5 and d023d32 were measured on the bench sums only.\n")
    w("Ratio fits R(N) = c (N/4000)^d (best ratio to current per sum, N >= 1000 / N >= 3000, N < 25,000):\n")
    w("| version | N >= 1000 | N >= 3000 |")
    w("|---|---|---|")
    for v in VERS:
        f = T["ratio_fits"].get(v)
        if not f:
            continue
        cells = []
        for k in ("N>=1000", "N>=3000"):
            g = f.get(k)
            cells.append("c %.2f, d %+.2f (sd %.2f, n %d)" % (g["a"], g["b"], g["resid_sd"], g["n"]) if g else "")
        w("| %s | %s |" % (v, " | ".join(cells)))
    w("")

    # --- comparison with the existence time model and runs
    big = {}
    for line in open(os.path.join(HERE, "inst", "big.txt")):
        if line.startswith("#") or not line.strip():
            continue
        f = [x.strip() for x in line.split("|")]
        big[(f[0], int(f[1]))] = float(f[4])
    w("### Current code vs the existence study's time model and runs (N >= 3,000)\n")
    w("Model: 51.3 s (N/4000)^3.92 (\"a = 3.92\"; the steep variant has slope 5.2 above N = 2x10^4). "
      "Existence runs: msearch / sampled msearch with the f61e719 search code, wall time on the loaded machine.\n")
    w("| P | S | N | labels | fdb77fc (CPU s) | f61e719 (CPU s) | existence run (f61e719 code, wall s) | model a = 3.92 | model steep | fdb77fc / model |")
    w("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|")
    for P, S, N in sums:
        if N < 3000:
            continue
        c = by.get((CUR, P, S))
        f6 = by.get(("f61e719", P, S))
        m1 = 51.3 * (N / 4000) ** 3.92
        m2 = m1 if N <= 2e4 else 51.3 * (2e4 / 4000) ** 3.92 * (N / 2e4) ** 5.2
        ex = big.get((P, S))
        w("| %s | %d | %d | %d | %s | %s | %s | %s | %s | %.2f |" % (
            P, S, N, c["labels"], fmt_s(c["seconds_best"]), fmt_s(f6["seconds_best"]) if f6 else "-",
            fmt_s(ex) if ex else "-", fmt_s(m1), fmt_s(m2), c["seconds_best"] / m2))
    w("")

    # --- sampling verification
    w("### Sampling check (P = %s, S = %d, N = 2994): full search vs stride-16 samples\n" % (V["P"], V["S"]))
    w("| version | full (CPU s) | sampled estimate / full (se) | per-r1 time, sampled run / full run | nodes per r1 equal | exact CV of the estimator, k = 4 / 16 / 64 / 256 |")
    w("|---|---:|---|---|---|---|")
    for v in VERS:
        x = V["versions"].get(v)
        if not x:
            continue
        ss = x["sampled"]
        w("| %s | %s | %s | %s | %s | %s |" % (
            v, fmt_s(x["full_search"]),
            "; ".join("o%d: %.2f (%.2f)" % (s["o"], s["est_over_full"], s["se_rel"]) for s in ss),
            "; ".join("%.2f" % s["r1_time_ratio"] for s in ss),
            "; ".join(s["nodes_equal"] for s in ss),
            " / ".join("%.2f" % x["exact_cv"][k] for k in ("k4", "k16", "k64", "k256"))))
    w("")
    if V.get("multi_offset"):
        w("Sums sampled at two or more offsets by the same version (estimate of the search, CPU s +- se):\n")
        w("| version | P S | estimates |")
        w("|---|---|---|")
        for m in V["multi_offset"]:
            if m["S"] == V["S"]:
                continue
            w("| %s | %s %d | %s |" % (m["version"], m["P"], m["S"], "; ".join(
                "k %d, o %d, m %d: %s +- %s" % (i["k"], i["o"], i["m"], fmt_s(i["est"]), fmt_s(i["se"])) for i in m["estimates"])))
        w("")

    # --- ratio model
    model = {"doc": __doc__, "current": CUR, "versions": {}}
    for v in VERS:
        knots = []
        for b in T["bins"]:
            if v not in b["ratio_gm"]:
                continue
            ss = b["sums"]
            Ng = math.exp(sum(math.log(next(r["N"] for r in recs if (r["P"] + " S=%d" % r["S"]) == s)) for s in ss) / len(ss))
            knots.append([round(Ng), round(b["ratio_gm"][v], 4)])
        model["versions"][v] = {"knots_N_ratio": knots, "power_fits": T["ratio_fits"].get(v),
                                "description": T["versions"][v]}
    # matrix-path point (> 256 labels) where measured
    for r in T["ratios_to_current"]:
        if r["N"] > 25000:
            model["versions"][r["version"]].setdefault("over_256_labels", []).append(
                {"P": r["P"], "S": r["S"], "N": r["N"], "ratio": r["ratio"],
                 "paired": r["paired"]})
    with open(os.path.join(HERE, "ratio_model.json"), "w") as f:
        json.dump(model, f, indent=1)

    head = open(os.path.join(HERE, "measure_head.md")).read() if os.path.exists(os.path.join(HERE, "measure_head.md")) else ""
    with open(os.path.join(HERE, "measure.md"), "w") as f:
        f.write(head.rstrip() + "\n\n## Tables (generated by report.py)\n\n" + "\n".join(out) + "\n")
    print("\n".join(out))


if __name__ == "__main__":
    main()
