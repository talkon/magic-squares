#!/usr/bin/env python3
"""Plan r1-sampled runs of the large sums: one shell line per (sum, version).

Strides are powers of two, nearest in log to rho_v * T_cur / target (rho_v = rough
time ratio of version v to the current code, T_cur = rough current time of the sum),
so that each run takes ~target CPU-s (0.7-1.4x). The offset is drawn once per sum in
[0, K) with K the largest stride used for that sum, and each version uses offset mod
its stride: every version's r1 sample then contains the sample of every version with
a larger stride (nested samples, for paired per-r1 comparisons between versions).

usage: plan.py --sums "1656 1166 ..." --target 25 --versions "legacy df352df ..." [--seed X]
       [--min-m M] (raise the stride's sample size to at least M r1 where the time allows)
"""
import argparse
import math
import random

RHO = {"legacy": 30, "df352df": 5.5, "8d07935": 3.5, "7cd9bc5": 2.6, "a72cef3": 2.8,
       "2d2bc6d": 1.15, "d023d32": 1.1, "f61e719": 1.1, "fdb77fc": 1.0}


def load_big(path):
    out = {}
    for line in open(path):
        if line.startswith("#") or not line.strip():
            continue
        e, S, N, sq, t = [x.strip() for x in line.split("|")][:5]
        out[(e, int(S))] = (int(N), float(t) * 0.9)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--big", default="inst/big.txt")
    ap.add_argument("--sums", required=True, help="S values (or P:S) from big.txt")
    ap.add_argument("--target", type=float, required=True)
    ap.add_argument("--versions", default="legacy df352df 8d07935 a72cef3 2d2bc6d f61e719 fdb77fc")
    ap.add_argument("--target-legacy", type=float, default=None)
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--tag", default="big")
    args = ap.parse_args()
    rng = random.Random(args.seed)
    big = load_big(args.big)
    vers = args.versions.split()
    for tok in args.sums.split():
        if ":" in tok:
            e, S = tok.split(":")
            key = (e.replace("_", " "), int(S))
        else:
            keys = [k for k in big if k[1] == int(tok)]
            assert len(keys) == 1, tok
            key = keys[0]
        N, tc = big[key]
        ks = {}
        for v in vers:
            tgt = args.target_legacy if (v == "legacy" and args.target_legacy) else args.target
            want = RHO[v] * tc / tgt
            k = 2 ** max(0, round(math.log2(max(want, 1))))
            ks[v] = k
        K = max(ks.values())
        off = rng.randrange(K)
        for i, v in enumerate(vers):
            k = ks[v]
            est = RHO[v] * tc / k
            print(f"python3 run.py {v} '{key[0]}' {key[1]} --stride {k} --offset {off % k} --tag {args.tag}"
                  f"   # N {N} m~{N // k} est {est:.0f}s")


if __name__ == "__main__":
    main()
