cd /tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/retro/measure
python3 run.py legacy '14 7 5 3' 1656 --stride 16 --offset 4 --tag big_mid   # N 3787 m~236 est 51s
python3 run.py df352df '14 7 5 3' 1656 --stride 8 --offset 4 --tag big_mid   # N 3787 m~473 est 19s
python3 run.py 8d07935 '14 7 5 3' 1656 --stride 4 --offset 0 --tag big_mid   # N 3787 m~946 est 24s
python3 run.py a72cef3 '14 7 5 3' 1656 --stride 4 --offset 0 --tag big_mid   # N 3787 m~946 est 19s
python3 run.py 2d2bc6d '14 7 5 3' 1656 --stride 1 --offset 0 --tag big_mid   # N 3787 m~3787 est 31s
python3 run.py f61e719 '14 7 5 3' 1656 --stride 1 --offset 0 --tag big_mid   # N 3787 m~3787 est 30s
python3 run.py fdb77fc '14 7 5 3' 1656 --stride 1 --offset 0 --tag big_mid   # N 3787 m~3787 est 27s
python3 run.py legacy '13 7 4 2 0 1' 1166 --stride 32 --offset 4 --tag big_mid   # N 4090 m~127 est 35s
python3 run.py df352df '13 7 4 2 0 1' 1166 --stride 8 --offset 4 --tag big_mid   # N 4090 m~511 est 26s
python3 run.py 8d07935 '13 7 4 2 0 1' 1166 --stride 4 --offset 0 --tag big_mid   # N 4090 m~1022 est 33s
python3 run.py a72cef3 '13 7 4 2 0 1' 1166 --stride 4 --offset 0 --tag big_mid   # N 4090 m~1022 est 26s
python3 run.py 2d2bc6d '13 7 4 2 0 1' 1166 --stride 2 --offset 0 --tag big_mid   # N 4090 m~2045 est 22s
python3 run.py f61e719 '13 7 4 2 0 1' 1166 --stride 2 --offset 0 --tag big_mid   # N 4090 m~2045 est 21s
python3 run.py fdb77fc '13 7 4 2 0 1' 1166 --stride 2 --offset 0 --tag big_mid   # N 4090 m~2045 est 19s
python3 run.py legacy '14 7 4 4 1 0 0 1' 3125 --stride 32 --offset 16 --tag big_mid   # N 4957 m~154 est 42s
python3 run.py df352df '14 7 4 4 1 0 0 1' 3125 --stride 8 --offset 0 --tag big_mid   # N 4957 m~619 est 31s
python3 run.py 8d07935 '14 7 4 4 1 0 0 1' 3125 --stride 8 --offset 0 --tag big_mid   # N 4957 m~619 est 20s
python3 run.py a72cef3 '14 7 4 4 1 0 0 1' 3125 --stride 4 --offset 0 --tag big_mid   # N 4957 m~1239 est 31s
python3 run.py 2d2bc6d '14 7 4 4 1 0 0 1' 3125 --stride 2 --offset 0 --tag big_mid   # N 4957 m~2478 est 26s
python3 run.py f61e719 '14 7 4 4 1 0 0 1' 3125 --stride 2 --offset 0 --tag big_mid   # N 4957 m~2478 est 25s
python3 run.py fdb77fc '14 7 4 4 1 0 0 1' 3125 --stride 2 --offset 0 --tag big_mid   # N 4957 m~2478 est 22s
python3 run.py legacy '12 8 4 2 1' 1302 --stride 64 --offset 7 --tag big_6k9k   # N 5995 m~93 est 90s
python3 run.py df352df '12 8 4 2 1' 1302 --stride 32 --offset 7 --tag big_6k9k   # N 5995 m~187 est 33s
python3 run.py 8d07935 '12 8 4 2 1' 1302 --stride 16 --offset 7 --tag big_6k9k   # N 5995 m~374 est 42s
python3 run.py a72cef3 '12 8 4 2 1' 1302 --stride 16 --offset 7 --tag big_6k9k   # N 5995 m~374 est 34s
python3 run.py 2d2bc6d '12 8 4 2 1' 1302 --stride 4 --offset 3 --tag big_6k9k   # N 5995 m~1498 est 55s
python3 run.py f61e719 '12 8 4 2 1' 1302 --stride 4 --offset 3 --tag big_6k9k   # N 5995 m~1498 est 53s
python3 run.py fdb77fc '12 8 4 2 1' 1302 --stride 4 --offset 3 --tag big_6k9k   # N 5995 m~1498 est 48s
python3 run.py legacy '12 6 3 2 1 1' 988 --stride 64 --offset 11 --tag big_6k9k   # N 6671 m~104 est 123s
python3 run.py df352df '12 6 3 2 1 1' 988 --stride 32 --offset 11 --tag big_6k9k   # N 6671 m~208 est 45s
python3 run.py 8d07935 '12 6 3 2 1 1' 988 --stride 32 --offset 11 --tag big_6k9k   # N 6671 m~208 est 29s
python3 run.py a72cef3 '12 6 3 2 1 1' 988 --stride 16 --offset 11 --tag big_6k9k   # N 6671 m~416 est 46s
python3 run.py 2d2bc6d '12 6 3 2 1 1' 988 --stride 8 --offset 3 --tag big_6k9k   # N 6671 m~833 est 38s
python3 run.py f61e719 '12 6 3 2 1 1' 988 --stride 8 --offset 3 --tag big_6k9k   # N 6671 m~833 est 36s
python3 run.py fdb77fc '12 6 3 2 1 1' 988 --stride 8 --offset 3 --tag big_6k9k   # N 6671 m~833 est 33s
python3 run.py legacy '14 7 4 4 1 0 0 1' 3231 --stride 64 --offset 10 --tag big_6k9k   # N 7901 m~123 est 147s
python3 run.py df352df '14 7 4 4 1 0 0 1' 3231 --stride 32 --offset 10 --tag big_6k9k   # N 7901 m~246 est 54s
python3 run.py 8d07935 '14 7 4 4 1 0 0 1' 3231 --stride 32 --offset 10 --tag big_6k9k   # N 7901 m~246 est 34s
python3 run.py a72cef3 '14 7 4 4 1 0 0 1' 3231 --stride 16 --offset 10 --tag big_6k9k   # N 7901 m~493 est 55s
python3 run.py 2d2bc6d '14 7 4 4 1 0 0 1' 3231 --stride 8 --offset 2 --tag big_6k9k   # N 7901 m~987 est 45s
python3 run.py f61e719 '14 7 4 4 1 0 0 1' 3231 --stride 8 --offset 2 --tag big_6k9k   # N 7901 m~987 est 43s
python3 run.py fdb77fc '14 7 4 4 1 0 0 1' 3231 --stride 8 --offset 2 --tag big_6k9k   # N 7901 m~987 est 39s
python3 run.py legacy '12 6 3 2 1 1' 1080 --stride 256 --offset 184 --tag big_6k9k   # N 8891 m~34 est 108s
python3 run.py df352df '12 6 3 2 1 1' 1080 --stride 128 --offset 56 --tag big_6k9k   # N 8891 m~69 est 40s
python3 run.py 8d07935 '12 6 3 2 1 1' 1080 --stride 64 --offset 56 --tag big_6k9k   # N 8891 m~138 est 50s
python3 run.py a72cef3 '12 6 3 2 1 1' 1080 --stride 64 --offset 56 --tag big_6k9k   # N 8891 m~138 est 40s
python3 run.py 2d2bc6d '12 6 3 2 1 1' 1080 --stride 32 --offset 24 --tag big_6k9k   # N 8891 m~277 est 33s
python3 run.py f61e719 '12 6 3 2 1 1' 1080 --stride 32 --offset 24 --tag big_6k9k   # N 8891 m~277 est 32s
python3 run.py fdb77fc '12 6 3 2 1 1' 1080 --stride 32 --offset 24 --tag big_6k9k   # N 8891 m~277 est 29s
echo PLAN_A_DONE
