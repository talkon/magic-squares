cd /tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/retro/measure
while ! grep -q PLAN_B_DONE logs/plan_b.out; do sleep 5; done
python3 run.py legacy '13 7 4 3 1 1' 2200 --stride 1024 --offset 487 --tag big_15k   # N 15199 m~14 est 327s
python3 run.py df352df '13 7 4 3 1 1' 2200 --stride 512 --offset 487 --tag big_15k   # N 15199 m~29 est 120s
python3 run.py 8d07935 '13 7 4 3 1 1' 2200 --stride 512 --offset 487 --tag big_15k   # N 15199 m~29 est 76s
python3 run.py a72cef3 '13 7 4 3 1 1' 2200 --stride 256 --offset 231 --tag big_15k   # N 15199 m~59 est 122s
python3 run.py 2d2bc6d '13 7 4 3 1 1' 2200 --stride 128 --offset 103 --tag big_15k   # N 15199 m~118 est 100s
python3 run.py f61e719 '13 7 4 3 1 1' 2200 --stride 128 --offset 103 --tag big_15k   # N 15199 m~118 est 96s
python3 run.py fdb77fc '13 7 4 3 1 1' 2200 --stride 128 --offset 103 --tag big_15k   # N 15199 m~118 est 87s
python3 run.py legacy '12 9 6 2 1 1' 3500 --stride 512 --offset 133 --tag big_15k   # N 17142 m~33 est 380s
python3 run.py df352df '12 9 6 2 1 1' 3500 --stride 512 --offset 133 --tag big_15k   # N 17142 m~33 est 70s
python3 run.py 8d07935 '12 9 6 2 1 1' 3500 --stride 256 --offset 133 --tag big_15k   # N 17142 m~66 est 89s
python3 run.py a72cef3 '12 9 6 2 1 1' 3500 --stride 256 --offset 133 --tag big_15k   # N 17142 m~66 est 71s
python3 run.py 2d2bc6d '12 9 6 2 1 1' 3500 --stride 64 --offset 5 --tag big_15k   # N 17142 m~267 est 117s
python3 run.py f61e719 '12 9 6 2 1 1' 3500 --stride 64 --offset 5 --tag big_15k   # N 17142 m~267 est 111s
python3 run.py fdb77fc '12 9 6 2 1 1' 3500 --stride 64 --offset 5 --tag big_15k   # N 17142 m~267 est 101s
python3 run.py legacy '13 7 4 3 1 1' 2400 --stride 4096 --offset 3030 --tag big_15k   # N 22992 m~5 est 308s
python3 run.py df352df '13 7 4 3 1 1' 2400 --stride 2048 --offset 982 --tag big_15k   # N 22992 m~11 est 113s
python3 run.py 8d07935 '13 7 4 3 1 1' 2400 --stride 2048 --offset 982 --tag big_15k   # N 22992 m~11 est 72s
python3 run.py a72cef3 '13 7 4 3 1 1' 2400 --stride 1024 --offset 982 --tag big_15k   # N 22992 m~22 est 115s
python3 run.py 2d2bc6d '13 7 4 3 1 1' 2400 --stride 512 --offset 470 --tag big_15k   # N 22992 m~44 est 94s
python3 run.py f61e719 '13 7 4 3 1 1' 2400 --stride 512 --offset 470 --tag big_15k   # N 22992 m~44 est 90s
python3 run.py fdb77fc '13 7 4 3 1 1' 2400 --stride 512 --offset 470 --tag big_15k   # N 22992 m~44 est 82s
echo PLAN_C_DONE
