cd /tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/retro/measure
python3 run.py legacy '12 6 3 2 1 1' 988 --stride 64 --offset 17 --tag verify_off2   # N 6671 m~104 est 123s
python3 run.py df352df '12 6 3 2 1 1' 988 --stride 32 --offset 17 --tag verify_off2   # N 6671 m~208 est 45s
python3 run.py 8d07935 '12 6 3 2 1 1' 988 --stride 32 --offset 17 --tag verify_off2   # N 6671 m~208 est 29s
python3 run.py a72cef3 '12 6 3 2 1 1' 988 --stride 16 --offset 1 --tag verify_off2   # N 6671 m~416 est 46s
python3 run.py 2d2bc6d '12 6 3 2 1 1' 988 --stride 8 --offset 1 --tag verify_off2   # N 6671 m~833 est 38s
python3 run.py f61e719 '12 6 3 2 1 1' 988 --stride 8 --offset 1 --tag verify_off2   # N 6671 m~833 est 36s
python3 run.py fdb77fc '12 6 3 2 1 1' 988 --stride 8 --offset 1 --tag verify_off2   # N 6671 m~833 est 33s
python3 run.py fdb77fc '13 7 4 3 1 1' 2650 --stride 4096 --offset 2199 --tag big_31k
python3 run.py a72cef3 '13 7 4 3 1 1' 2650 --stride 4096 --offset 2199 --tag big_31k
python3 run.py f61e719 '13 7 4 3 1 1' 2650 --stride 4096 --offset 2199 --tag big_31k
python3 run.py df352df '13 7 4 3 1 1' 2650 --stride 4096 --offset 2199 --tag big_31k
python3 run.py 2d2bc6d '13 7 4 3 1 1' 2650 --stride 4096 --offset 2199 --tag big_31k
echo PLAN_D_DONE
