cd /tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/retro/measure
./bench_round.sh bench_legacyfix legacy
python3 run.py legacy '14 7 5 3' 1656 --stride 16 --offset 4 --tag big_mid_legacyfix
python3 run.py legacy '13 7 4 2 0 1' 1166 --stride 32 --offset 4 --tag big_mid_legacyfix
python3 run.py legacy '14 7 4 4 1 0 0 1' 3125 --stride 32 --offset 16 --tag big_mid_legacyfix
python3 run.py legacy '12 8 4 2 1' 1302 --stride 64 --offset 7 --tag big_6k9k_legacyfix
python3 run.py legacy '12 6 3 2 1 1' 988 --stride 64 --offset 11 --tag big_6k9k_legacyfix
python3 run.py legacy '12 6 3 2 1 0 1' 900 --stride 16 --offset 5 --tag verify_k16_legacyfix
python3 run.py legacy '12 6 3 2 1 0 1' 900 --stride 16 --offset 13 --tag verify_k16_legacyfix
python3 run.py legacy '14 7 4 4 1 0 0 1' 3231 --stride 64 --offset 10 --tag big_6k9k_legacyfix
python3 run.py legacy '12 6 3 2 1 1' 988 --stride 64 --offset 17 --tag verify_off2_legacyfix
python3 run.py legacy '13 7 4 3 1 1' 2200 --stride 1024 --offset 487 --tag big_15k_legacyfix
python3 run.py legacy '12 6 3 2 1 1' 1080 --stride 256 --offset 184 --tag big_6k9k_legacyfix
python3 run.py legacy '13 7 4 3 1 1' 2650 --stride 16384 --offset 2199 --tag big_31k_legacyfix
python3 run.py legacy '13 7 4 3 1 1' 2650 --stride 16384 --offset 2199 --tag big_31k_legacyfix
echo RERUN_DONE
