cd /tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/retro/measure
# wait for bench round 1
while ! grep -q ROUND_DONE logs/bench_r1.out; do sleep 5; done
./bench_round.sh bench_r2 fdb77fc f61e719 d023d32 2d2bc6d 7cd9bc5 a72cef3 8d07935 df352df
# sampling verification on the largest bench instance (N 2994): stride 16, two offsets, every version
for o in 5 13; do for v in legacy df352df 8d07935 a72cef3 7cd9bc5 2d2bc6d d023d32 f61e719 fdb77fc; do
  python3 run.py $v '12 6 3 2 1 0 1' 900 --stride 16 --offset $o --tag verify_k16
done; done
./bench_round.sh bench_r3 df352df 8d07935 a72cef3 7cd9bc5 2d2bc6d d023d32 f61e719 fdb77fc
echo PLAN_B_DONE
