cd /tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/retro/measure
python3 run.py legacy '13 7 4 3 1 1' 2200 --stride 1024 --offset 871 --tag big_15k_off2
python3 run.py legacy '12 9 6 2 1 1' 3500 --stride 512 --offset 325 --tag big_15k_off2
echo PLAN_F_DONE
