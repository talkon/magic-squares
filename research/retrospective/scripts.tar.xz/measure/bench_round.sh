#!/bin/bash
# usage: bench_round.sh TAG VERSION... : every 6x6 bench instance (quick, full, prod), full search,
# all given versions back to back per instance (order rotated per instance)
cd "$(dirname "$0")"
tag=$1; shift
vers=("$@")
i=0
grep -v '^#' inst/bench6.txt | while IFS='|' read n e S c h; do
  e=$(echo $e); S=$(echo $S); c=$(echo $c); h=$(echo $h)
  nv=${#vers[@]}
  for j in $(seq 0 $((nv-1))); do
    v=${vers[$(( (i + j) % nv ))]}
    python3 run.py $v "$e" $S --expect $c $h --tag $tag
  done
  i=$((i+1))
done
echo ROUND_DONE $tag
