#!/usr/bin/env python3
"""Patch the legacy arrangement program (src/c/arrangement.c, search.c; unchanged
since 2023-05) for the retro measurements, like patch_new.py, without touching the
recursive search:

* search.c: only a counter of squares, incremented where a square is printed.
* arrangement.c: search_sum runs the root level of search_aux itself (no row or column
  placed: every vector i is tried as the first row r1, exactly as search_aux's root
  iteration does: record the root node, place r1, fill the candidate lists with
  index >= r1, recurse with search_aux), but only for i = off, off + stride, ... (env
  SAMPLE_STRIDE, SAMPLE_OFFSET), recording squares, nodes and rdtsc cycles per r1.
  A square is found exactly once, under its lowest-index vector (min_vec = r1 at
  depth 1), so stride * (sampled sum) is unbiased. With stride 1 the search is
  identical to the original (same nodes, same squares).
  Setup (relabelling + N x N intersection bitsets + slot allocation) and search are
  timed with the thread CPU clock and appended to $SAMPLE_LOG in the format of
  patch_new.py.

(A first version put the sampling test and an rdtsc inside search_aux's loop, at every
node: that made the legacy search 1.75x slower, and its runs were discarded.)
"""
import sys

d = sys.argv[1]
s = open(f"{d}/search.c").read()
hdr = '#include "search.h"\n'
assert s.count(hdr) == 1
s = s.replace(hdr, hdr + "#include <stdint.h>\n/* RETRO PATCH */\nuint64_t retro_squares = 0;\n")
rec = '    printf("solution found\\n");\n'
assert s.count(rec) == 1
s = s.replace(rec, "    retro_squares++;\n" + rec)
open(f"{d}/search.c", "w").write(s)

a = open(f"{d}/arrangement.c").read()
inc = '#include "types.h"\n'
assert a.count(inc) == 1
a = a.replace(inc, inc + r"""#include <x86intrin.h>
/* RETRO PATCH */
extern uint64_t retro_squares;
void record(search_table table, row_table rows, row_table cols, global_t g);
void fill_valids(const global_t g, const row_table *old_vecs, row_table *new_vecs,
                 const search_table table, unsigned char inter_val, size_t new_vec,
                 size_t min_vec);
static double cpu_time(void) {
  struct timespec t;
  clock_gettime(CLOCK_THREAD_CPUTIME_ID, &t);
  return (double)t.tv_sec + 1e-9 * (double)t.tv_nsec;
}
/* the root iteration of search_aux (rows and cols empty), for the first rows
 * r1 = off, off + stride, ...; per-r1 squares, nodes, cycles */
static uint32_t retro_root(global_t g, row_table rows, row_table cols,
                           search_table table, uint32_t stride, uint32_t off,
                           uint32_t *r1s, uint64_t *sqs, uint64_t *nds,
                           uint64_t *cys) {
  record(table, rows, cols, g);
  if (!((rows.num_vecs + rows.num_valid >= VEC_SIZE) &&
        (cols.num_vecs + cols.num_valid >= VEC_SIZE)))
    return 0;
  size_t max_unmatched = bitset_maximum(table.unmatched);
  uint32_t m = 0;
  for (size_t i = off; i < rows.num_valid; i += stride) {
    size_t max_elt = g.vecs[rows.valid[i]][0];
    if (max_elt < max_unmatched)
      break;
    const uint64_t sq0 = retro_squares, nd0 = *table.num_searched,
                   c0 = __rdtsc();
    row_table new_rows = rows;
    row_table new_cols = cols;
    size_t new_vec = rows.valid[i];
    new_rows.vecs[0] = new_vec;
    new_rows.num_vecs++;
    bitset_inplace_xor(table.unmatched, g.bitarrays[new_vec]);
    size_t min_vec = new_vec;
    new_rows.valid = g.row_idx_slots[1];
    new_cols.valid = g.col_idx_slots[1];
    fill_valids(g, &rows, &new_rows, table, ROW, new_vec, min_vec);
    fill_valids(g, &cols, &new_cols, table, COL, new_vec, min_vec);
    search_aux(g, new_rows, new_cols, table);
    bitset_inplace_xor(table.unmatched, g.bitarrays[new_vec]);
    r1s[m] = (uint32_t)i;
    sqs[m] = retro_squares - sq0;
    nds[m] = *table.num_searched - nd0;
    cys[m] = __rdtsc() - c0;
    m++;
  }
  return m;
}
""")

a1 = "  printf(\"sum %d nvecs %ld\\n\", sum, total_vecs);\n"
assert a.count(a1) == 1
a = a.replace(a1, a1 + "  double retro_t0 = cpu_time();\n  retro_squares = 0;\n")
a2 = "  search_aux(g, rows, cols, table);\n"
assert a.count(a2) == 1
a = a.replace(a2, r"""  double retro_t1 = cpu_time();
  const char *retro_es = getenv("SAMPLE_STRIDE"), *retro_eo = getenv("SAMPLE_OFFSET");
  uint32_t retro_stride = retro_es ? (uint32_t)strtoul(retro_es, 0, 10) : 1;
  if (retro_stride < 1)
    retro_stride = 1;
  uint32_t retro_off = retro_eo ? (uint32_t)strtoul(retro_eo, 0, 10) % retro_stride : 0;
  uint32_t retro_cap = (uint32_t)(total_vecs / retro_stride + 2);
  uint32_t *retro_r1 = malloc(retro_cap * sizeof(uint32_t));
  uint64_t *retro_sq = malloc(retro_cap * sizeof(uint64_t));
  uint64_t *retro_nd = malloc(retro_cap * sizeof(uint64_t));
  uint64_t *retro_cy = malloc(retro_cap * sizeof(uint64_t));
  uint32_t retro_m = retro_root(g, rows, cols, table, retro_stride, retro_off,
                                retro_r1, retro_sq, retro_nd, retro_cy);
  double retro_t2 = cpu_time();
  {
    const char *lf = getenv("SAMPLE_LOG");
    FILE *lg = lf ? fopen(lf, "a") : NULL;
    if (lg) {
      uint64_t tot = 0;
      for (uint32_t i = 0; i < retro_m; i++)
        tot += retro_cy[i];
      double scale = tot ? (retro_t2 - retro_t1) / (double)tot : 0;
      size_t L = 0;
      for (size_t i = 0; i < total_vecs; i++)
        for (int j = 0; j < VEC_SIZE; j++)
          if (g.vecs[i][j] + 1 > L)
            L = g.vecs[i][j] + 1;
      fprintf(lg, "# N %zu L %zu stride %u off %u\n", total_vecs, L, retro_stride,
              retro_off);
      for (uint32_t i = 0; i < retro_m; i++)
        fprintf(lg, "%u %llu %llu %.6g\n", retro_r1[i],
                (unsigned long long)retro_sq[i], (unsigned long long)retro_nd[i],
                retro_cy[i] * scale);
      fprintf(lg, "#END setup %.6f search %.6f nodes %llu squares %llu sampled %u\n",
              retro_t1 - retro_t0, retro_t2 - retro_t1,
              (unsigned long long)*table.num_searched,
              (unsigned long long)retro_squares, retro_m);
      fclose(lg);
    }
  }
  free(retro_r1); free(retro_sq); free(retro_nd); free(retro_cy);
""")
open(f"{d}/arrangement.c", "w").write(a)
print("patched legacy", d)
