#!/usr/bin/env python3
"""Check the r1 sampling against full runs, per version.

For a sum searched both in full (per-r1 log) and r1-sampled (separate processes):
1. the sampled run's estimate (stride * sampled search time) vs the full search time;
2. the sampled run's per-r1 times, nodes and squares vs the full run's for the same r1
   (does a subproblem cost the same when run alone? the cross-support switch of
   f61e719+ adapts across r1, so nodes may differ slightly);
3. the exact sampling distribution of the estimator for strides 4, 16, 64, 256 over all
   offsets, computed from the full run's per-r1 times (spread = sampling error).
Also, for sums sampled at two or more offsets by the same version: the estimates side by side.

usage: verify_sampling.py [P S] (default 12 6 3 2 1 0 1 900)
"""
import json
import math
import os
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from analyze import parse_log, load_runs, VERS, succ_diff_var  # noqa: E402


def main():
    P = sys.argv[1:-1] or "12 6 3 2 1 0 1".split()
    S = int(sys.argv[-1]) if len(sys.argv) > 1 else 900
    runs = [r for r in load_runs(os.path.join(HERE, "runs.jsonl")) if r["P"] == P and r["S"] == S]
    out = {"P": " ".join(P), "S": S, "versions": {}}
    print(f"P = {' '.join(P)}, S = {S}")
    print("%-8s %8s %9s | %-34s | %-30s | %s" % ("version", "full s", "sq/nodes", "sampled k/o: est/full, r1-time ratio, nodes equal",
                                              "exact CV of the estimator k=4/16/64/256", "squares in sample (exp.)"))
    for v in VERS:
        rv = [r for r in runs if r["version"] == v]
        full = [r for r in rv if r["stride"] == 1]
        samp = [r for r in rv if r["stride"] > 1]
        if not full:
            continue
        best = min(full, key=lambda r: r["search"])
        fr = parse_log(os.path.join(HERE, "logs", best["log"]))[0]
        t = {x[0]: x[3] for x in fr["r1"]}
        nd = {x[0]: x[2] for x in fr["r1"]}
        sq = {x[0]: x[1] for x in fr["r1"]}
        N = fr["N"]
        tot = sum(t.values())
        cvs = []
        for k in (4, 16, 64, 256):
            ests = [k * sum(t.get(i, 0) for i in range(o, N, k)) for o in range(k)]
            mu = sum(ests) / k
            sd = math.sqrt(sum((e - mu) ** 2 for e in ests) / k)
            cvs.append(sd / tot)
        rec = {"full_search": best["search"], "full_runs": len(full), "N": N, "squares": best["squares"],
               "nodes": best["nodes"], "exact_cv": dict(zip(("k4", "k16", "k64", "k256"), cvs)), "sampled": []}
        ss = []
        for r in samp:
            sr = parse_log(os.path.join(HERE, "logs", r["log"]))[0]
            st = sum(x[3] for x in sr["r1"])
            ft = sum(t[x[0]] for x in sr["r1"])
            neq = sum(1 for x in sr["r1"] if x[2] == nd[x[0]])
            sqs = sum(x[1] for x in sr["r1"])
            sqf = sum(sq[x[0]] for x in sr["r1"])
            est = r["stride"] * sr["search"]
            # standard error of this sample's estimate (successive differences)
            se = math.sqrt(succ_diff_var([x[3] for x in sr["r1"]], r["stride"]))
            rec["sampled"].append({"k": r["stride"], "o": r["offset"], "est_over_full": est / best["search"],
                                   "se_rel": se / best["search"],
                                   "r1_time_ratio": st / ft if ft else None, "nodes_equal": f"{neq}/{len(sr['r1'])}",
                                   "squares": sqs, "squares_full_same_r1": sqf})
            ss.append("k%d/o%d: %.2f (se %.2f), %.2f, %d/%d" % (r["stride"], r["offset"], est / best["search"],
                                                         se / best["search"], st / ft if ft else float('nan'),
                                                         neq, len(sr["r1"])))
        out["versions"][v] = rec
        print("%-8s %8.2f %4d/%-9d| %-34s | %-30s |" % (v, best["search"], best["squares"], best["nodes"],
                                                    "; ".join(ss)[:120], " ".join("%.2f" % c for c in cvs)))
    # sums sampled by one version at several offsets
    allruns = load_runs(os.path.join(HERE, "runs.jsonl"))
    multi = defaultdict(list)
    for r in allruns:
        if r["stride"] > 1:
            multi[(r["version"], tuple(r["P"]), r["S"])].append(r)
    out["multi_offset"] = []
    print("\nsums sampled at several offsets (estimate of the full search, CPU s, +- se):")
    for (v, P2, S2), rs in sorted(multi.items(), key=lambda kv: (kv[0][2], VERS.index(kv[0][0]))):
        sets = {}
        for r in rs:
            sets.setdefault((r["stride"], r["offset"]), r)
        if len(sets) < 2:
            continue
        items = []
        for (k, o), r in sorted(sets.items()):
            sr = parse_log(os.path.join(HERE, "logs", r["log"]))[0]
            se = math.sqrt(succ_diff_var([x[3] for x in sr["r1"]], k))
            items.append({"k": k, "o": o, "est": k * sr["search"], "se": se, "m": len(sr["r1"]), "squares": k * sr["squares"]})
        out["multi_offset"].append({"version": v, "P": " ".join(P2), "S": S2, "estimates": items})
        print("%-8s %-22s %5d: " % (v, " ".join(P2), S2) +
              "; ".join("k%d o%d m%d: %.0f +- %.0f (sq %d)" % (i["k"], i["o"], i["m"], i["est"], i["se"], i["squares"]) for i in items))
    with open(os.path.join(HERE, "verify_sampling.json"), "w") as f:
        json.dump(out, f, indent=1)


if __name__ == "__main__":
    main()
