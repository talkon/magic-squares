#!/usr/bin/env python3
"""Combine runs.jsonl into per-(version, sum) time estimates, fits and ratios.

Writes times.json (one record per version and sum, plus fits) and prints the tables
used in measure.md.

Per (version, sum):
* full runs (stride 1): seconds = min over repeats of setup + search (CPU s), and the
  squares / hash, checked against the bench expectations and across versions;
* sampled runs (stride k > 1, offset o): each r1 set (k, o) is timed once or more
  (min per r1 set over repeats); the sets are pooled into one estimate weighted by
  their sample sizes; seconds = setup + estimated search; se from successive
  differences of the per-r1 times (systematic sample; removes the trend in r1);
* if both exist, the full runs are used.
Squares per sum are version independent: the full count where some version searched
the sum in full (or the existence runs did: inst/big.txt), else the pooled sampled
estimate over all versions' samples.
"""
import json
import math
import os
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
VERS = ["legacy", "df352df", "8d07935", "a72cef3", "7cd9bc5", "2d2bc6d", "d023d32", "f61e719", "fdb77fc"]
MAIN = ["legacy", "df352df", "8d07935", "a72cef3", "2d2bc6d", "f61e719", "fdb77fc"]
CUR = "fdb77fc"
DESC = {
    "legacy": "original arrangement_6 (first search)",
    "df352df": "new arrange.c: forward checking, MRV, label bitsets, AVX-512 filters",
    "8d07935": "+ byte counters, permute filters, vectorized child selection",
    "a72cef3": "+ support filter",
    "7cd9bc5": "+ tie-break by smallest label",
    "2d2bc6d": "+ candidate lists carry their bitsets",
    "d023d32": "+ degeneracy label order",
    "f61e719": "+ cross support (and label order, msearch fixes)",
    "fdb77fc": "+ round-2 micro-optimizations (current)",
}


def parse_log(path):
    recs, cur = [], None
    for line in open(path):
        if line.startswith("# N"):
            a = line.split()
            cur = {"N": int(a[2]), "L": int(a[4]), "stride": int(a[6]), "offset": int(a[8]), "r1": []}
        elif line.startswith("#END"):
            a = line.split()
            cur.update(setup=float(a[2]), search=float(a[4]), nodes=int(a[6]), squares=int(a[8]))
            recs.append(cur)
            cur = None
        elif cur is not None:
            r, sq, nd, t = line.split()
            cur["r1"].append((int(r), int(sq), int(nd), float(t)))
    return recs


def load_runs(path):
    runs = [json.loads(l) for l in open(path) if l.strip()]
    # legacy runs before the fixed patch (the first legacy patch slowed the search
    # 1.75x, see patch_legacy.py) are discarded
    fix = open(os.path.join(HERE, "legacy_fix_time.txt")).read().strip()
    return [r for r in runs if not r.get("tag", "").startswith("test")
            and not (r["version"] == "legacy" and r["time"] < fix)]


def load_big():
    big = {}
    for line in open(os.path.join(HERE, "inst", "big.txt")):
        if line.startswith("#") or not line.strip():
            continue
        f = [x.strip() for x in line.split("|")]
        e, S, N, sq, t = f[:5]
        big[(tuple(e.split()), int(S))] = {"N": int(N), "squares": None if sq == "-" else int(sq),
                                            "t_exist": float(t),
                                            "sq_est_exist": float(f[5]) if len(f) > 5 else None,
                                            "m_exist": int(f[6]) if len(f) > 6 else 0}
    return big


def succ_diff_var(ts, k):
    """variance of k * sum(ts) for a systematic sample (one unit per stratum of k)"""
    m = len(ts)
    if m < 2:
        return float("nan")
    d2 = sum((ts[i + 1] - ts[i]) ** 2 for i in range(m - 1))
    return k * k * m * d2 / (2 * (m - 1))


def srs_var(ts, k, N):
    m = len(ts)
    if m < 2:
        return float("nan")
    mu = sum(ts) / m
    s2 = sum((x - mu) ** 2 for x in ts) / (m - 1)
    f = m / N
    return N * N * s2 / m * (1 - f)


def estimate(runs):
    """runs of one (version, sum) -> estimate dict"""
    full = [r for r in runs if r["stride"] == 1]
    out = {"N": runs[0]["N"], "L": runs[0]["L"]}
    if full:
        best = min(full, key=lambda r: r["est_seconds"])
        secs = sorted(r["est_seconds"] for r in full)
        out.update(seconds=best["est_seconds"], se=0.0, rel_se=0.0, full=True, repeats=len(full),
                   seconds_all=secs, setup=best["setup"], nodes=best["nodes"], squares=best["squares"],
                   squares_sampled=best["squares"], hash=best["hash"],
                   checks=sorted(set(r.get("check", "-") for r in full)), stride=1, m=best["m"],
                   strides=[1], log=best["log"])
        return out
    # sampled: group by r1 set
    sets = defaultdict(list)
    for r in runs:
        sets[(r["stride"], r["offset"])].append(r)
    parts = []
    for (k, o), rs in sets.items():
        best = min(rs, key=lambda r: r["search"])
        rec = parse_log(os.path.join(HERE, "logs", best["log"]))[0]
        ts = [x[3] for x in rec["r1"]]
        parts.append({"k": k, "o": o, "m": len(ts), "search": best["search"], "setup": best["setup"],
                      "est": k * best["search"], "var_sd": succ_diff_var(ts, k), "var_srs": srs_var(ts, k, rec["N"]),
                      "squares": best["squares"], "nodes": best["nodes"], "log": best["log"], "repeats": len(rs)})
    M = sum(p["m"] for p in parts)
    est = sum(p["m"] * p["est"] for p in parts) / M
    var = sum((p["m"] / M) ** 2 * p["var_sd"] for p in parts)
    var_srs = sum((p["m"] / M) ** 2 * p["var_srs"] for p in parts)
    sq = sum(p["m"] * p["k"] * p["squares"] for p in parts) / M
    nodes = sum(p["m"] * p["k"] * p["nodes"] for p in parts) / M
    setup = min(p["setup"] for p in parts)
    out.update(seconds=setup + est, se=math.sqrt(var), se_srs=math.sqrt(var_srs),
               rel_se=math.sqrt(var) / est if est else float("nan"), full=False,
               setup=setup, nodes=nodes, squares=sq, squares_sampled=sum(p["squares"] for p in parts),
               stride=min(p["k"] for p in parts), strides=sorted(set(p["k"] for p in parts)), m=M,
               parts=parts, repeats=sum(p["repeats"] for p in parts))
    return out


def paired_ratio(ea, eb):
    """time ratio a / b on the r1 positions both sampled (nested samples): (ratio, rel se, n)"""
    def r1map(e):
        d = {}
        if e["full"]:
            rec = parse_log(os.path.join(HERE, "logs", e["log"]))[0]
            for x in rec["r1"]:
                d[x[0]] = x[3]
        else:
            for p in e["parts"]:
                rec = parse_log(os.path.join(HERE, "logs", p["log"]))[0]
                for x in rec["r1"]:
                    d[x[0]] = x[3]
        return d
    a, b = r1map(ea), r1map(eb)
    common = sorted(set(a) & set(b))
    if len(common) < 5:
        return None
    sa = sum(a[i] for i in common)
    sb = sum(b[i] for i in common)
    if sb <= 0:
        return None
    R = sa / sb
    n = len(common)
    res = [a[i] - R * b[i] for i in common]
    # successive differences of the residuals (systematic sample)
    d2 = sum((res[j + 1] - res[j]) ** 2 for j in range(n - 1))
    var = n * d2 / (2 * (n - 1)) / sb ** 2
    return R, math.sqrt(var) / R, n


def fit_power(pts):
    """least squares ln t = ln a + b ln(N/4000), weights 1; returns a, b, resid sd, n"""
    if len(pts) < 2:
        return None
    xs = [math.log(N / 4000) for N, t in pts]
    ys = [math.log(t) for N, t in pts]
    n = len(xs)
    mx, my = sum(xs) / n, sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    if sxx <= 0:
        return None
    b = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sxx
    a = my - b * mx
    res = [y - a - b * x for x, y in zip(xs, ys)]
    sd = math.sqrt(sum(r * r for r in res) / max(n - 2, 1))
    se_b = sd / math.sqrt(sxx) if n > 2 else float("nan")
    return {"a": math.exp(a), "b": b, "resid_sd": sd, "n": n, "se_b": se_b}


def main():
    runs = load_runs(os.path.join(HERE, "runs.jsonl"))
    big = load_big()
    groups = defaultdict(list)
    for r in runs:
        groups[(r["version"], tuple(r["P"]), r["S"])].append(r)
    E = {k: estimate(v) for k, v in groups.items()}
    sums = sorted(set((P, S) for _, P, S in E), key=lambda ps: max(E[(v, *ps)]["N"] for v in VERS if (v, *ps) in E))

    # version-independent squares and N (raw: legacy's count, else big.txt, else max)
    sq_best, N_raw, sq_src = {}, {}, {}
    hash_issues = []
    for P, S in sums:
        fulls = [(v, E[(v, P, S)]) for v in VERS if (v, P, S) in E and E[(v, P, S)]["full"]]
        Ns = [E[(v, P, S)]["N"] for v in VERS if (v, P, S) in E]
        N_raw[(P, S)] = E[("legacy", P, S)]["N"] if ("legacy", P, S) in E else big.get((P, S), {}).get("N", max(Ns))
        if fulls:
            counts = set(e["squares"] for v, e in fulls)
            hashes = set(e["hash"] for v, e in fulls)
            if len(counts) > 1 or len(hashes) > 1:
                hash_issues.append((P, S, [(v, e["squares"], e["hash"]) for v, e in fulls]))
            sq_best[(P, S)] = fulls[0][1]["squares"]
            sq_src[(P, S)] = "full (%s)" % ",".join(v for v, e in fulls)
        elif big.get((P, S), {}).get("squares") is not None:
            sq_best[(P, S)] = big[(P, S)]["squares"]
            sq_src[(P, S)] = "full (existence/verify msearch)"
        else:
            num = den = 0.0
            for v in VERS:
                e = E.get((v, P, S))
                if e and not e["full"]:
                    for p in e["parts"]:
                        num += p["m"] * p["k"] * p["squares"]
                        den += p["m"]
            b = big.get((P, S), {})
            if b.get("sq_est_exist") is not None:
                num += b["m_exist"] * b["sq_est_exist"]
                den += b["m_exist"]
            sq_best[(P, S)] = num / den if den else float("nan")
            sq_src[(P, S)] = "pooled samples (%d r1, incl. %d of the existence runs)" % (den, b.get("m_exist", 0))

    # records
    recs = []
    for (v, P, S), e in sorted(E.items(), key=lambda kv: (VERS.index(kv[0][0]), N_raw[(kv[0][1], kv[0][2])])):
        r = {"version": v, "P": " ".join(P), "S": S, "N": N_raw[(P, S)], "N_searched": e["N"], "labels": e["L"],
             "seconds": round(e["seconds"], 6), "se": round(e["se"], 6), "full": e["full"],
             "sampled_stride": None if e["full"] else e["strides"], "r1_sampled": e["m"],
             "squares": e["squares_sampled"] if e["full"] else round(e["squares"], 2),
             "squares_in_sample": e["squares_sampled"],
             "squares_best": sq_best[(P, S)], "squares_source": sq_src[(P, S)],
             "nodes": int(e["nodes"]), "setup": e["setup"], "repeats": e["repeats"]}
        if e["full"]:
            r["hash"] = e["hash"]
            r["check"] = e["checks"]
            bq = big.get((P, S), {}).get("squares")
            if r["check"] == ["-"] and bq is not None:
                r["check"] = ["ok" if bq == e["squares"] else "FAIL"] 
                r["check_against"] = "existence/verify msearch count %d" % bq
            r["seconds_repeats"] = e["seconds_all"]
        else:
            r["parts"] = [{k: p[k] for k in ("k", "o", "m", "search", "squares", "nodes", "repeats", "log")} for p in e["parts"]]
            r["rel_se"] = e["rel_se"]
        sqb = sq_best[(P, S)]
        r["seconds_per_square"] = e["seconds"] / sqb if sqb and sqb > 0 else None
        recs.append(r)

    # ratios to the current code, per sum: direct (estimates) and paired (common r1)
    ratios = []
    for P, S in sums:
        c = E.get((CUR, P, S))
        if not c:
            continue
        for v in VERS:
            e = E.get((v, P, S))
            if not e or v == CUR:
                continue
            direct = e["seconds"] / c["seconds"]
            rse = math.hypot(e["rel_se"], c["rel_se"])
            pr = None
            if not (e["full"] and c["full"]):
                pr = paired_ratio(e, c)
            ratios.append({"version": v, "P": " ".join(P), "S": S, "N": N_raw[(P, S)], "ratio": direct, "rel_se": rse,
                           "paired": None if pr is None else {"ratio": pr[0], "rel_se": pr[1], "n_r1": pr[2]}})

    # best ratio per (version, sum): the paired ratio where it has the smaller standard
    # error (sampled sums), else the direct one; seconds_best = best ratio * current time
    TB = {}
    for r in ratios:
        p = r["paired"]
        use_p = p is not None and p["rel_se"] < r["rel_se"]
        r["best"] = p["ratio"] if use_p else r["ratio"]
        r["best_rel_se"] = p["rel_se"] if use_p else r["rel_se"]
        r["best_kind"] = "paired" if use_p else "direct"
        Pt = tuple(r["P"].split())
        TB[(r["version"], Pt, r["S"])] = r["best"] * E[(CUR, Pt, r["S"])]["seconds"]
    for k, e in E.items():
        if k not in TB:
            TB[k] = e["seconds"]
    for rec in recs:
        k = (rec["version"], tuple(rec["P"].split()), rec["S"])
        rec["seconds_best"] = TB[k]
        sqb = rec["squares_best"]
        rec["seconds_per_square_best"] = TB[k] / sqb if sqb and sqb > 0 else None

    # fits
    fits = {}
    for v in VERS:
        # (the N = 31,743 sum has 279 labels, > 256: matrix path in every version; reported separately)
        pts_all = [(N_raw[(P, S)], TB[(v, P, S)]) for P, S in sums if (v, P, S) in E and N_raw[(P, S)] < 25000]
        if not pts_all:
            continue
        f = {}
        f["N>=1000"] = fit_power([p for p in pts_all if p[0] >= 1000])
        f["N<3000"] = fit_power([p for p in pts_all if 400 <= p[0] < 3000 and p[0] >= 1000])
        f["N>=3000"] = fit_power([p for p in pts_all if p[0] >= 3000])
        f["N 3000-10000"] = fit_power([p for p in pts_all if 3000 <= p[0] < 10000])
        f["N>=10000"] = fit_power([p for p in pts_all if p[0] >= 10000])
        f["N>=6000"] = fit_power([p for p in pts_all if p[0] >= 6000])
        fits[v] = f
    ratio_fits = {}
    for v in VERS:
        pts = [(r["N"], r["best"]) for r in ratios if r["version"] == v and r["N"] >= 1000 and r["N"] < 25000]
        if len(pts) >= 2:
            ratio_fits[v] = {"N>=1000": fit_power(pts),
                             "N>=3000": fit_power([p for p in pts if p[0] >= 3000])}

    # per N bin: geometric-mean ratio to current, and cost per semi-magic square
    # (sum of seconds / sum of squares over the sums of the bin measured by all main versions)
    BINS = [(400, 1000), (1000, 2000), (2000, 3100), (3100, 5500), (5500, 10000), (10000, 25000), (25000, 40000)]
    bins = []
    for lo, hi in BINS:
        ss = [(P, S) for P, S in sums if lo <= N_raw[(P, S)] < hi and all((v, P, S) in E for v in MAIN)]
        if not ss:
            continue
        b = {"N_lo": lo, "N_hi": hi, "sums": [" ".join(P) + " S=%d" % S for P, S in ss],
             "squares": sum(sq_best[ps] for ps in ss), "ratio_gm": {}, "seconds_per_square": {}, "seconds_total": {}}
        for v in VERS:
            if not all((v, P, S) in E for P, S in ss):
                continue
            tot = sum(TB[(v, P, S)] for P, S in ss)
            b["seconds_total"][v] = tot
            b["seconds_per_square"][v] = tot / b["squares"] if b["squares"] > 0 else None
            lr = [math.log(TB[(v, P, S)] / TB[(CUR, P, S)]) for P, S in ss]
            b["ratio_gm"][v] = math.exp(sum(lr) / len(lr))
            b.setdefault("ratio_range", {})[v] = [math.exp(min(lr)), math.exp(max(lr))]
            b.setdefault("N_gm", math.exp(sum(math.log(N_raw[ps]) for ps in ss) / len(ss)))
        bins.append(b)

    out = {"description": __doc__, "bins": bins, "versions": DESC, "current": CUR,
           "time_model_form": "t(N) = a (N/4000)^b, CPU seconds per sum (setup + search; thread CPU time, this machine); fits use seconds_best",
           "ratio_fit_note": "ratio fits use the best per-sum ratio (paired where its se is smaller), sums with N < 25000 (carry path); the N = 31743 sum (279 labels, matrix path) is reported separately",
           "records": recs, "ratios_to_current": ratios, "fits": fits, "ratio_fits": ratio_fits,
           "hash_issues": hash_issues}
    with open(os.path.join(HERE, "times.json"), "w") as f:
        json.dump(out, f, indent=1)

    # ---- printout
    print("sums:", len(sums), " runs:", len(runs), " CPU in runs: %.0f s" % sum(r["search"] + r["setup"] for r in runs))
    if hash_issues:
        print("HASH/COUNT DISAGREEMENTS:", hash_issues)
    checks = [(r["version"], r["P"], r["S"], r["check"]) for r in recs if r.get("check") and r["check"] != ["ok"]]
    print("check != ok:", checks)
    hdr = "%-26s %6s %4s" % ("P S", "N", "sq") + "".join("%10s" % v[:8] for v in VERS)
    print(hdr)
    for P, S in sums:
        line = "%-26s %6d %4s" % (" ".join(P) + " " + str(S), N_raw[(P, S)],
                                  ("%.0f" % sq_best[(P, S)]) if sq_best[(P, S)] == sq_best[(P, S)] else "?")
        for v in VERS:
            e = E.get((v, P, S))
            if not e:
                line += "%10s" % "-"
            else:
                s = e["seconds"]
                tag = "" if e["full"] else "~"
                line += "%10s" % (("%.3g" % s) + tag)
        print(line)
    print("\nratio to current (direct; paired on common r1 in [])")
    for P, S in sums:
        line = "%-26s %6d " % (" ".join(P) + " " + str(S), N_raw[(P, S)])
        for v in VERS:
            rr = [r for r in ratios if r["version"] == v and r["P"] == " ".join(P) and r["S"] == S]
            if not rr:
                line += "%14s" % "-"
            else:
                r = rr[0]
                s = "%.2f" % r["ratio"]
                if r["paired"]:
                    s += "[%.2f]" % r["paired"]["ratio"]
                if r["best_kind"] == "paired":
                    s += "*"
                line += "%14s" % s
        print(line)
    print("\nby N bin: geometric-mean ratio to current | CPU s per semi-magic square (sums measured by all main versions)")
    for b in bins:
        print("N %5d-%5d (%d sums, %.0f squares): " % (b["N_lo"], b["N_hi"], len(b["sums"]), b["squares"]) +
              " ".join("%s %.2f|%s" % (v[:7], b["ratio_gm"][v], ("%.3g" % b["seconds_per_square"][v]) if b["seconds_per_square"].get(v) else "-")
                       for v in VERS if v in b["ratio_gm"]))
    print("\nfits t = a (N/4000)^b")
    for v in VERS:
        if v not in fits:
            continue
        s = "%-8s" % v
        for k, f in fits[v].items():
            if f:
                s += "  %s: a=%.3g b=%.2f sd=%.2f n=%d" % (k, f["a"], f["b"], f["resid_sd"], f["n"])
        print(s)
    print("\nratio fits r = c (N/4000)^d")
    for v, f in ratio_fits.items():
        s = "%-8s" % v
        for k, g in f.items():
            if g:
                s += "  %s: c=%.3g d=%.2f sd=%.2f n=%d" % (k, g["a"], g["b"], g["resid_sd"], g["n"])
        print(s)


if __name__ == "__main__":
    main()
