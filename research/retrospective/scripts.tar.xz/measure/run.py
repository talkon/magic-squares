#!/usr/bin/env python3
"""Run one version of the arrangement search on one (P, S), optionally r1-sampled,
and append a record to runs.jsonl.

usage: run.py VERSION "e1 e2 ..." S [--stride K] [--offset O] [--tag T] [--expect COUNT HASH]

VERSION is legacy (bin/arrangement_6_legacy on a vector file written by the repo's
bin/enumerate) or a commit (bin/bench_<commit>). All binaries are patched copies
(patch_new.py / patch_legacy.py): thread-CPU-time clocks, r1 sampling via
SAMPLE_STRIDE / SAMPLE_OFFSET, per-r1 records in SAMPLE_LOG.

Record: version, P, S, N (vectors searched), L, stride, offset, m (r1 sampled),
squares (in the sample), nodes (in the sample), setup, search (CPU s of the sampled
search), est_search = stride * search (Horvitz-Thompson; = search when stride 1),
est_seconds = setup + est_search, est_squares = stride * squares, hash (full runs),
check (vs expectation), log (per-r1 file), load (1-min load average at the start).
"""
import argparse
import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = "/home/user/magic-squares"
sys.path.insert(0, os.path.join(REPO, "bench"))
from validate_legacy import parse_legacy, square_hash, MASK  # noqa: E402


def parse_log(path):
    recs = []
    cur = None
    for line in open(path):
        if line.startswith("# N"):
            a = line.split()
            cur = {"N": int(a[2]), "L": int(a[4]), "stride": int(a[6]), "offset": int(a[8]), "r1": []}
        elif line.startswith("#END"):
            a = line.split()
            cur.update(setup=float(a[2]), search=float(a[4]), nodes=int(a[6]), squares=int(a[8]), m=int(a[10]))
            recs.append(cur)
            cur = None
        elif cur is not None:
            r, sq, nd, t = line.split()
            cur["r1"].append((int(r), int(sq), int(nd), float(t)))
    return recs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("version")
    ap.add_argument("exps")
    ap.add_argument("S", type=int)
    ap.add_argument("--stride", type=int, default=1)
    ap.add_argument("--offset", type=int, default=0)
    ap.add_argument("--tag", default="")
    ap.add_argument("--expect", nargs=2, default=None)
    ap.add_argument("--out", default=os.path.join(HERE, "runs.jsonl"))
    args = ap.parse_args()

    exps = args.exps.split()
    key = "_".join(exps) + f"_{args.S}"
    os.makedirs(os.path.join(HERE, "logs"), exist_ok=True)
    stamp = time.strftime("%H%M%S") + f"_{os.getpid()}"
    log = os.path.join(HERE, "logs", f"{args.version}_{key}_k{args.stride}_o{args.offset}_{stamp}.log")
    env = dict(os.environ, SAMPLE_STRIDE=str(args.stride), SAMPLE_OFFSET=str(args.offset), SAMPLE_LOG=log)
    load = os.getloadavg()[0]
    t0 = time.time()
    count = h = None
    if args.version == "legacy":
        vfile = os.path.join(HERE, "vec", f"e_6_{key}.txt")
        if not os.path.exists(vfile):
            subprocess.run([os.path.join(REPO, "bin", "enumerate"), "--vec-size", "6", "--min-sum", str(args.S),
                            "--max-sum", str(args.S), "--file", vfile + ".tmp", *exps],
                           check=True, stderr=subprocess.DEVNULL)
            os.rename(vfile + ".tmp", vfile)
        afile = os.path.join(HERE, "logs", f"out_legacy_{key}_{stamp}.txt")
        with open(afile, "w") as out:
            subprocess.run([os.path.join(HERE, "bin", "arrangement_6_legacy"), "--file", vfile, "--sum", str(args.S)],
                           check=True, stdout=out, env=env)
        count, h = 0, 0
        for rows, cols in parse_legacy(afile, 6):
            count += 1
            h = (h + square_hash(rows, cols)) & MASK
        h = f"{h:016x}"
        os.remove(afile)
    else:
        inst = os.path.join(HERE, "logs", f"inst_{key}_{stamp}.txt")
        with open(inst, "w") as f:
            f.write(f"6 | {' '.join(exps)} | {args.S} | - | -\n")
        r = subprocess.run([os.path.join(HERE, "bin", f"bench_{args.version}"), "--update", inst],
                           check=True, capture_output=True, text=True, env=env)
        os.remove(inst)
        for line in r.stdout.splitlines():
            if line.strip() and not line.startswith("#"):
                f = [x.strip() for x in line.split("|")]
                count, h = int(f[3]), f[4]
    wall = time.time() - t0
    recs = parse_log(log)
    assert len(recs) == 1, (log, len(recs))
    rec = recs[0]
    assert rec["squares"] == count, (rec["squares"], count)
    k = rec["stride"]
    out = {
        "version": args.version, "P": exps, "S": args.S, "N": rec["N"], "L": rec["L"],
        "stride": k, "offset": rec["offset"], "m": rec["m"], "squares": rec["squares"],
        "nodes": rec["nodes"], "setup": rec["setup"], "search": rec["search"],
        "est_search": k * rec["search"], "est_seconds": rec["setup"] + k * rec["search"],
        "est_squares": k * rec["squares"], "est_nodes": k * rec["nodes"],
        "hash": h if k == 1 else None, "tag": args.tag, "log": os.path.basename(log),
        "load": load, "wall": wall, "time": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    if args.expect and k == 1:
        ec, eh = args.expect
        out["check"] = "ok" if (ec in ("-", str(count)) and eh in ("-", h)) else "FAIL"
    with open(args.out, "a") as f:
        f.write(json.dumps(out) + "\n")
    print(f"{args.version:8s} {' '.join(exps):18s} S={args.S:5d} N={rec['N']:6d} k={k:5d} m={rec['m']:5d} "
          f"sq={rec['squares']:4d} search={rec['search']:9.3f} est={out['est_seconds']:10.1f} "
          f"setup={rec['setup']:.3f} {out.get('check', '')} load={load:.1f}", flush=True)


if __name__ == "__main__":
    main()
