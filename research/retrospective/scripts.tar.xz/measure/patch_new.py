#!/usr/bin/env python3
"""Patch a new-pipeline src/c tree (df352df .. fdb77fc) for the retro measurements.

1. wall_time() in arrange.c returns the thread CPU time (the machine is shared,
   so wall time would include time spent descheduled).
2. The root loop of SEARCH_ROOT (one subproblem per first row r1) runs only
   r1 = off, off + stride, ... (env SAMPLE_STRIDE, SAMPLE_OFFSET; default 1, 0),
   the same patch as existence/model/sample/src, and records per r1 the squares,
   nodes and rdtsc cycles in memory (no I/O in the loop).
3. After the search, search_vectors appends to $SAMPLE_LOG (if set):
     # N <count> L <labels> stride <k> off <o>
     <r1> <squares> <nodes> <cpu seconds (cycles scaled to the search's CPU time)>
     #END setup <s> search <s> nodes <n> squares <q> sampled <m>
usage: patch_new.py <dir containing arrange.c and arrange_core.h>
"""
import re
import sys

d = sys.argv[1]
ac = open(f"{d}/arrange.c").read()
old_wt = """static double wall_time(void) {
  struct timeval t;
  gettimeofday(&t, NULL);
  return (double)t.tv_sec + 1e-6 * (double)t.tv_usec;
}"""
assert ac.count(old_wt) == 1, "wall_time anchor"
new_wt = r"""#include <time.h>
#include <x86intrin.h>
/* RETRO PATCH: thread CPU time instead of wall time */
static double wall_time(void) {
  struct timespec t;
  clock_gettime(CLOCK_THREAD_CPUTIME_ID, &t);
  return (double)t.tv_sec + 1e-9 * (double)t.tv_nsec;
}
/* RETRO PATCH: r1 sampling and per-r1 records */
static uint32_t retro_stride = 1, retro_off = 0, retro_m = 0, retro_cap = 0,
                retro_count = 0;
static uint32_t *retro_r1;
static uint64_t *retro_sq, *retro_nd, *retro_cy;
static void retro_begin(uint32_t count) {
  const char *es = getenv("SAMPLE_STRIDE"), *eo = getenv("SAMPLE_OFFSET");
  retro_stride = es ? (uint32_t)strtoul(es, 0, 10) : 1;
  if (retro_stride < 1)
    retro_stride = 1;
  retro_off = eo ? (uint32_t)strtoul(eo, 0, 10) % retro_stride : 0;
  retro_count = count;
  retro_m = 0;
  retro_cap = count / retro_stride + 2;
  free(retro_r1); free(retro_sq); free(retro_nd); free(retro_cy);
  retro_r1 = malloc(retro_cap * sizeof(uint32_t));
  retro_sq = malloc(retro_cap * sizeof(uint64_t));
  retro_nd = malloc(retro_cap * sizeof(uint64_t));
  retro_cy = malloc(retro_cap * sizeof(uint64_t));
}
static inline void retro_rec(uint32_t r1, uint64_t sq, uint64_t nd, uint64_t cy) {
  if (retro_m < retro_cap) {
    retro_r1[retro_m] = r1; retro_sq[retro_m] = sq; retro_nd[retro_m] = nd;
    retro_cy[retro_m] = cy; retro_m++;
  }
}
static void retro_dump(double setup, double search, uint64_t nodes,
                       uint64_t squares, int L) {
  const char *lf = getenv("SAMPLE_LOG");
  if (!lf)
    return;
  FILE *lg = fopen(lf, "a");
  if (!lg)
    return;
  uint64_t tot = 0;
  for (uint32_t i = 0; i < retro_m; i++)
    tot += retro_cy[i];
  double scale = tot ? search / (double)tot : 0;
  fprintf(lg, "# N %u L %d stride %u off %u\n", retro_count, L, retro_stride,
          retro_off);
  for (uint32_t i = 0; i < retro_m; i++)
    fprintf(lg, "%u %llu %llu %.6g\n", retro_r1[i],
            (unsigned long long)retro_sq[i], (unsigned long long)retro_nd[i],
            retro_cy[i] * scale);
  fprintf(lg, "#END setup %.6f search %.6f nodes %llu squares %llu sampled %u\n",
          setup, search, (unsigned long long)nodes,
          (unsigned long long)squares, retro_m);
  fclose(lg);
}"""
ac = ac.replace(old_wt, new_wt)
anchor = "  st.seconds = wall_time() - t1;\n"
assert ac.count(anchor) == 1, "st.seconds anchor"
ac = ac.replace(anchor, anchor + "  retro_dump(st.setup_seconds, st.seconds, st.nodes, st.squares, st.num_labels);\n")
open(f"{d}/arrange.c", "w").write(ac)

core = open(f"{d}/arrange_core.h").read()
m = re.search(r"  for \(uint32_t r1 = 0; r1 < count && !s->stop; r1\+\+\)\n    (TRY_CHILD\([^;]*\));\n", core)
assert m, "root loop anchor"
assert core.count("for (uint32_t r1 = 0; r1 < count && !s->stop; r1++)") == 1
new_loop = f"""  /* RETRO PATCH: r1 = off, off + stride, ... with per-r1 records */
  retro_begin(count);
  for (uint32_t r1 = retro_off; r1 < count && !s->stop; r1 += retro_stride) {{
    const uint64_t sq0 = s->squares, nd0 = s->nodes, c0 = __rdtsc();
    {m.group(1)};
    retro_rec(r1, s->squares - sq0, s->nodes - nd0, __rdtsc() - c0);
  }}
"""
core = core[:m.start()] + new_loop + core[m.end():]
open(f"{d}/arrange_core.h", "w").write(core)
print("patched", d)
