"""Retrospective forecast, new version: the integrated build (e49934c + fixes, cx/integrated) against fdb77fc.

Reuses retro/forecast (retro_lib: Ratios, t_current, curve arithmetic) and the existence study's
frontier_rev.py exactly as retro.py does; adds the integrated build as a version with
R_new(N) = (best-mode CPU of the integrated build) / (fdb77fc plain CPU).

Mode policy (msearch defaults): plain below N = 5,000 (--diag-first-min-n), d-first at N >= 5,000.
d-first writes no semi-magic squares, so a d-first sum also runs a plain calibration stream
(--calib-r1-stride k) costing a share s of the sum's CPU: t = t_dfirst / (1 - s) at N >= 5,000.

usage: python3 forecast_new.py [tag=_x] [analytic_rev_args='["MULT=2.0"]']   -> results_new<tag>.json (this directory)
"""
import sys, os, json, math, io, contextlib, runpy
RETRO = '/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad/retro/forecast'
sys.path.insert(0, RETRO)
from retro_lib import *            # CFG, Ratios, t_current, E_at, C_at, marginal, YR
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))

# ------------------------------------------------------------------ measurements (integrated perf verifier, research/ideas.md
# "Measurements on the integrated binary"): process CPU-s per sum, paired, per-r1 min of 2; d-first d-sampled
MEAS = [  # P / S, N, labels, base plain, new plain, new d-first
    ("10 6 4 2 1 1 / 838", 1986, 104, 1.01, 1.01, 1.65, 1.007, 1.6),
    ("12 6 3 2 1 0 1 / 900", 2994, 121, 5.9, 5.8, 5.9, 0.984, 0.97),
    ("13 7 4 3 1 1 / 1900", 4111, 137, 35.5, 23.5, 29.4, 0.663, 0.83),
    ("12 6 3 2 1 1 / 988", 6671, 159, 260, 231, 149, 0.892, 0.575),
    ("13 7 4 3 1 1 / 2000", 7593, 168, 511, 441, 251, 0.863, 0.491),
    ("12 6 3 2 1 1 / 1200", 11697, 199, 2023, 1575, 870, 0.778, 0.430),
    ("13 7 4 3 1 1 / 2200", 15199, 211, 11316, 8223, 3432, 0.727, 0.303),
    ("11 6 4 3 2 1 / 2174", 16424, 220, 11503, 8685, 4056, 0.755, 0.353),
    ("14 7 4 4 1 0 0 1 / 3648", 20538, 252, 14460, 12623, 5407, 0.873, 0.374),
    ("9 6 4 3 1 1 1 1 / 2700", 20896, 259, 53077, 13835, 4457, 0.261, 0.084),
    ("13 7 4 3 1 1 / 2400", 22992, 245, 47400, 40389, 11785, 0.852, 0.249),
    ("13 7 4 3 1 1 / 2500", 26585, 260, 205729, 54280, 23366, 0.264, 0.114),
    ("13 7 4 3 1 1 / 2650", 31743, 279, 467238, 121918, 39917, 0.261, 0.085),
]
NMIN_DFIRST = 5000
BINS = [(1000, 2000), (2000, 3100), (3100, 5500), (5500, 10000), (10000, 25000)]   # part 1's bins (400-1000: no sum)
BENCH_R = (0.271 / 0.270 * 3.270 / 3.393 * 13.97 / 13.76) ** (1 / 3)               # bench quick/full/prod, native, N < 2.3k


def ratios(mode):
    """per-sum ratio to fdb77fc: 'best' = the msearch policy (plain < 5000, d-first >= 5000), 'plain', 'dfirst'"""
    out = []
    for name, N, L, tb, tp, td, rp, rd in MEAS:
        r = {'plain': rp, 'dfirst': rd, 'best': rp if N < NMIN_DFIRST else rd}[mode]
        out.append((N, L, r))
    return out


def fit_power(pts):
    x = np.log([p[0] / 4000.0 for p in pts]); y = np.log([p[1] for p in pts])
    A = np.vstack([np.ones_like(x), x]).T
    c, res, *_ = np.linalg.lstsq(A, y, rcond=None)
    r = y - A @ c
    sd = math.sqrt((r ** 2).sum() / max(len(x) - 2, 1))
    se_b = sd / math.sqrt(((x - x.mean()) ** 2).sum())
    return dict(a=float(math.exp(c[0])), b=float(c[1]), resid_sd=sd, se_b=se_b, n=len(x))


def build_ratio(mode, knot4k=None):
    """part 1's construction: per-bin geometric-mean knots (<= 256 labels), power-fit slope (N >= 3000)
    beyond the last knot, one ratio for > 256 labels (geometric mean of the measured sums)"""
    rr = ratios(mode)
    low = [(N, r) for N, L, r in rr if L <= 256]
    hi = [(N, r) for N, L, r in rr if L > 256]
    knots = [(758.0, BENCH_R)]
    for lo, hi_ in BINS:
        s = [(N, r) for N, r in low if lo <= N < hi_]
        if not s: continue
        Ng = math.exp(np.mean([math.log(n) for n, _ in s])); Rg = math.exp(np.mean([math.log(r) for _, r in s]))
        if knot4k is not None and lo == 3100: Rg = knot4k
        knots.append((Ng, Rg))
    pf = fit_power([p for p in low if p[0] >= 3000])
    R256 = math.exp(np.mean([math.log(r) for _, r in hi]))
    N256 = math.exp(np.mean([math.log(n) for n, _ in hi]))
    return dict(knots=knots, fit=pf, R256=R256, N256=N256, low=low, hi=hi)


class NewRatio:
    """R_new(N) = (1 - f256(N)) R_low(N) + f256(N) R_256(N), times 1 / (1 - s) at N >= 5000 (calibration stream)"""
    def __init__(self, rm, f256, s=0.10, beyond='fit', cap=1e5, r256='flat', mode='best'):
        self.rm, self.f256, self.s, self.beyond, self.cap, self.r256, self.mode = rm, f256, s, beyond, cap, r256, mode
        k = np.array(rm['knots'], float); self.xk, self.yk = np.log(k[:, 0]), np.log(k[:, 1])

    def R_low(self, N):
        lN = np.log(np.maximum(np.asarray(N, float), 1.0))
        y = np.interp(lN, self.xk, self.yk)
        if self.beyond == 'fit':
            lc = np.minimum(lN, math.log(self.cap))
            y = np.where(lN > self.xk[-1], self.yk[-1] + self.rm['fit']['b'] * (lc - self.xk[-1]), y)
        return np.exp(y)

    def R_256(self, N):
        N = np.asarray(N, float)
        if self.r256 == 'flat':
            return np.full_like(N, self.rm['R256'])
        # 'trend': the measured > 256 ratio at its N, continued with the <= 256 power-fit slope (both ways), capped
        lc = np.log(np.minimum(np.maximum(N, 1.0), self.cap))
        return self.rm['R256'] * np.exp(self.rm['fit']['b'] * (lc - math.log(self.rm['N256'])))

    def __call__(self, N):
        N = np.asarray(N, float)
        f = self.f256(N)
        r = (1 - f) * self.R_low(N) + f * self.R_256(N)
        if self.mode != 'plain':
            r = np.where(N >= NMIN_DFIRST, r / (1.0 - self.s), r)
        return r


def main():
    cfg = load_cfg(sys.argv[1:])
    RT = Ratios(cfg)
    # f256(N): E-weighted share of sums with > 256 labels, from the model lens (as retro.py)
    lens = np.load(f"{RETRO}/cache/lens_fe89dcba28.npz", allow_pickle=True)
    e, N, L = lens['e'], lens['N'].astype(float), lens['L'].astype(float)
    edges = np.linspace(np.log(300), np.log(3e6), 61)
    lb = np.clip(np.digitize(np.log(N), edges) - 1, 0, len(edges) - 2)
    big = (L * cfg['label_scale'] > 256)
    fw = np.bincount(lb, weights=e * big, minlength=len(edges) - 1) / np.maximum(np.bincount(lb, weights=e, minlength=len(edges) - 1), 1e-300)
    fN = 0.5 * (edges[:-1] + edges[1:])
    del lens, e, N, L, big, lb
    def f256(Nq):
        return np.interp(np.log(np.maximum(np.asarray(Nq, float), 1)), fN, fw)

    # analytic frontier (as retro.py)
    p = cfg['analytic_rev_script']; buf = io.StringIO(); argv0 = sys.argv
    sys.argv = [p] + [str(a) for a in (cfg.get('analytic_rev_args') or [])]
    try:
        with contextlib.redirect_stdout(buf):
            G = runpy.run_path(p, run_name='__main__')
    finally:
        sys.argv = argv0
    w_, Em_, ns_, Nseg, PART, MU = G['w'], G['Em'], G['ns'], G['N'], G['PART'], G['VAR']['MULT']
    Eseg = w_ * Em_
    t0 = t_current(cfg, Nseg) * ns_ * w_
    Cs = [1, 10, 100, 1000, 10000]; Es = [0.03, 0.1, 0.3, 0.5, 1.0, 2.0]

    def summ(R, label, scale=1.0):
        t = t0 * R(Nseg) * scale
        o = np.argsort(-(Eseg / t), kind='stable')
        cT = np.cumsum(t[o]) / YR; cE = np.cumsum(Eseg[o])
        d = dict(label=label, E={C: float(E_at(cT, cE, C, MU)) for C in Cs}, C={E: float(C_at(cT, cE, E, MU)) for E in Es},
                 marg_E1=marginal(cT, cE, 1.0, MU), E_max=float(cE[-1] * MU))
        d['marg_C'] = {C: marginal(cT, cE, d['E'][C], MU) for C in Cs}
        d['C_F'] = {F: float(C_at(cT, cE, 1.0 / F, MU)) for F in (0.3125, 0.4, 0.5, 2 / 3, 1.0, 1.5, 2.0, 3.2)}
        wh = {}
        for C in Cs:
            j = min(int(np.searchsorted(cT, C / MU)), len(o) - 1); sel = o[:j + 1]; es = Eseg[sel]
            wh[C] = dict(N=float(np.exp((es * np.log(Nseg[sel])).sum() / es.sum())), N_margin=float(Nseg[o[j]]),
                         share256_E=float((es * f256(Nseg[sel])).sum() / es.sum()), share256_t=float((t[sel] * f256(Nseg[sel])).sum() / t[sel].sum()))
        d['where'] = wh
        for E in (0.5, 1.0, 2.0):
            j = min(int(np.searchsorted(cE, E / MU)), len(o) - 1); sel = o[:j + 1]; es = Eseg[sel]
            wh[f'E={E}'] = dict(N=float(np.exp((es * np.log(Nseg[sel])).sum() / es.sum())), N_margin=float(Nseg[o[j]]),
                                share256_E=float((es * f256(Nseg[sel])).sum() / es.sum()), share256_t=float((t[sel] * f256(Nseg[sel])).sum() / t[sel].sum()))
        # cost per expected magic square by N band (base assignments, x MULT, without the P*p part, as frontier_rev.py)
        band = {}
        for lo, hi in ((0, 2000), (2000, 4000), (4000, 8000), (8000, 16000), (16000, 32000), (32000, 64000)):
            m = (Nseg >= lo) & (Nseg < hi) & (PART == 'main')
            Eb = MU * Eseg[m].sum(); Tb = MU * t[m].sum() / YR
            band[f'{lo}-{hi}'] = dict(E=float(Eb), cpu_yr=float(Tb), cpu_per_E=float(Tb / max(Eb, 1e-300)))
        d['bands'] = band
        return d

    res = dict(meas=MEAS, models={}, runs={})
    one = lambda N: np.ones_like(np.asarray(N, float))
    res['runs']['fdb77fc'] = summ(one, 'fdb77fc (current)')
    res['runs']['legacy'] = summ(lambda N: RT.R('legacy', N, f256=f256), 'legacy')
    rm_best = build_ratio('best'); rm_plain = build_ratio('plain'); rm_df = build_ratio('dfirst')
    rm_best_4k = build_ratio('best', knot4k=0.80)
    res['models'] = dict(best=rm_best, plain=rm_plain, dfirst=rm_df, best_4k080=rm_best_4k)
    V = [
        ('new', 'integrated, best mode (central: calib s = 10%, > 256 flat)', NewRatio(rm_best, f256, s=0.10)),
        ('new_s0', 'calibration stream s = 0', NewRatio(rm_best, f256, s=0.0)),
        ('new_s5', 's = 5%', NewRatio(rm_best, f256, s=0.05)),
        ('new_s20', 's = 20%', NewRatio(rm_best, f256, s=0.20)),
        ('new_plain', 'integrated, plain only (no d-first)', NewRatio(rm_plain, f256, s=0.0, mode='plain')),
        ('new_flat', 'R_low flat beyond the last knot (16.8k)', NewRatio(rm_best, f256, s=0.10, beyond='flat')),
        ('new_trend', '> 256 labels: d-first gain keeps its N slope (to 1e5)', NewRatio(rm_best, f256, s=0.10, r256='trend')),
        ('new_4k', '3.1-5.5k knot 0.80 instead of 0.663', NewRatio(rm_best_4k, f256, s=0.10)),
    ]
    for key, label, R in V:
        res['runs'][key] = summ(R, label)
    # optimistic: above N = 32k the new code keeps its own measured slope (best mode, 3.53) instead of the existence
    # model's matrix-path slope 5.2 (cx/profile: the 5.2 is fdb77fc's matrix path), flat ratio beyond 1e5 as retro
    Rc = V[0][2]
    def R_own(N):
        N = np.asarray(N, float)
        return np.where(N <= 32000, Rc(N), Rc(32000.0) * (np.minimum(N, 1e5) / 32000.0) ** (3.53 - 5.2))
    V.append(('new_own', "above 32k the new code's own slope 3.53 (not the matrix path's 5.2), to 1e5", R_own))
    res['runs']['new_own'] = summ(R_own, V[-1][1])
    # the verifier's own power fits as the ratio: t_best / t_base = (23.0/24.8) (N/4000)^(3.53-4.49), capped at 1e5, flat below 4000
    def R_pf(N):
        N = np.asarray(N, float)
        lo = np.exp(np.interp(np.log(np.maximum(N, 1)), np.log([758, 1986, 2994, 4000]), np.log([BENCH_R, 1.007, 0.984, 23.0 / 24.8])))
        hi = (23.0 / 24.8) * (np.minimum(np.maximum(N, 4000.0), 1e5) / 4000.0) ** (3.53 - 4.49)
        return np.where(N < 4000, lo, np.where(N >= NMIN_DFIRST, hi / 0.9, hi))
    res['runs']['new_pf'] = summ(R_pf, "verifier's time fits: R = 0.93 (N/4000)^-0.96 above 4k (to 1e5)")
    # time level x0.58 (part 1's measured level), for fdb77fc and new
    lvl = cfg['t_scale_alt']
    res['runs']['fdb77fc_lvl'] = summ(one, 'fdb77fc, time level x0.58', lvl)
    res['runs']['new_lvl'] = summ(V[0][2], 'new, time level x0.58', lvl)
    # model-error corners of the analytic factors are a separate frontier_rev run (see run_corners)
    # R_new at selected N
    Nq = np.array([1000, 2000, 3000, 4000, 5000, 7000, 10000, 15000, 20000, 25000, 32000, 45000, 64000, 1e5])
    res['R_table'] = {key: dict(zip([f'{int(n)}' for n in Nq], map(float, R(Nq)))) for key, _, R in V}
    res['R_table']['new_pf'] = dict(zip([f'{int(n)}' for n in Nq], map(float, R_pf(Nq))))
    res['f256'] = dict(zip([f'{int(n)}' for n in Nq], map(float, f256(Nq))))
    res['analytic_rev_args'] = cfg.get('analytic_rev_args') or []
    json.dump(res, open(HERE + '/results_new%s.json' % cfg.get('tag', ''), 'w'), indent=1, default=float)
    print_tables(res)


def fmt(x):
    if x == float('inf') or x != x: return '-'
    if x >= 100: return f'{x:,.0f}' if x < 1e5 else f'{x:.2g}'.replace('e+0', 'e').replace('e+', 'e')
    if x >= 10: return f'{x:.1f}' if x < 30 else f'{x:.0f}'
    return f'{x:.3g}'


def print_tables(res):
    R = res['runs']; cur = R['fdb77fc']; leg = R['legacy']
    Cs = ['1', '10', '100', '1000', '10000']
    def g(d, k, kk): return d[k][kk] if kk in d[k] else d[k][float(kk)]
    print('R_new(N):', json.dumps(res['R_table']['new']))
    print('f256:', json.dumps(res['f256']))
    for k in ('best', 'plain', 'dfirst'):
        m = res['models'][k]; print(k, 'knots', [(round(a), round(b, 3)) for a, b in m['knots']], 'fit', {a: round(b, 3) for a, b in m['fit'].items()}, 'R256 %.4f at N %.0f' % (m['R256'], m['N256']))
    print()
    for key, d in R.items():
        E = [d['E'][int(c)] if int(c) in d['E'] else d['E'][c] for c in Cs]
        print(f"{key:12s} E " + ' '.join('%.3f' % x for x in E) + '  C(E=.5,1,2) ' + ' / '.join(fmt(d['C'][e]) for e in (0.5, 1.0, 2.0)) +
              '  marg E1 %s' % fmt(d['marg_E1']))
    print()
    for key, d in R.items():
        print(f"{key:12s} E/E_cur " + ' '.join('%.2f' % (d['E'][c] / cur['E'][c]) for c in d['E']) +
              '   C_cur/C ' + ' '.join('%.2f' % (cur['C'][e] / d['C'][e]) for e in d['C']) +
              '   C_leg/C ' + ' '.join('%.1f' % (leg['C'][e] / d['C'][e]) for e in d['C']))
    print()
    for key in ('fdb77fc', 'new', 'new_plain'):
        d = R[key]; print(key, 'where', {c: (round(v['N']), round(v['N_margin'])) for c, v in d['where'].items()})
        print(key, 'bands', {b: (round(v['E'], 3), '%.3g' % v['cpu_per_E']) for b, v in d['bands'].items()})


if __name__ == '__main__':
    main()
