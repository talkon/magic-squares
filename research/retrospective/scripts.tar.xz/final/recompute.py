#!/usr/bin/env python3
"""Independent recomputation of a few retro.md table entries (reviewer's check).

* Ratios: recomputed here from times.json per-sum records (seconds_best of each version over
  fdb77fc's), N >= 1000 only, sums with <= 256 labels; two ratio models:
  (a) power fit c (N/4000)^d on N >= 1000 (flat below 1000 at the fit's value at 1000),
  (b) running geometric mean in ln N (my own knots: bins 1-2k, 2-3.1k, 3.1-5.5k, 5.5-10k, 10-25k).
  The > 256-label regime is ignored (T8 says it matters only at E >= 1).
* E(C): frontier_rev.py executed as is (segments w, Em, ns, N, PART; its own t_meas() time
  model; MULT); per version the segments are re-sorted by E / (R_v t).
"""
import json, math, runpy, sys, io, contextlib
import numpy as np

SP = "/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad"
T = json.load(open(SP + "/retro/measure/times.json"))
recs = T["records"]
by = {}
for r in recs:
    by.setdefault((r["P"], r["S"]), {})[r["version"]] = r
vers = ["legacy", "df352df", "8d07935", "a72cef3", "2d2bc6d", "f61e719"]
pts = {v: [] for v in vers}
for k, d in by.items():
    if "fdb77fc" not in d: continue
    c = d["fdb77fc"]
    if c["labels"] > 256: continue
    for v in vers:
        if v in d:
            pts[v].append((c["N"], d[v]["seconds_best"] / c["seconds_best"]))

fits = {}
for v in vers:
    a = np.array(sorted(pts[v]))
    for lo in (1000, 3000):
        m = a[:, 0] >= lo
        x = np.log(a[m, 0] / 4000); y = np.log(a[m, 1])
        b, c0 = np.polyfit(x, y, 1)
        fits[(v, lo)] = (math.exp(c0), b, float(np.std(y - (c0 + b * x))), int(m.sum()))
print("ratio fits R = c (N/4000)^d [c, d, sd, n]:")
for v in vers:
    print("  %-8s N>=1000: %.2f %+.3f %.3f %d   N>=3000: %.2f %+.3f %.3f %d" % ((v,) + fits[(v, 1000)] + fits[(v, 3000)]))

bins = [(1000, 2000), (2000, 3100), (3100, 5500), (5500, 10000), (10000, 25000)]
knots = {}
for v in vers:
    a = np.array(sorted(pts[v]))
    kn = []
    for lo, hi in bins:
        m = (a[:, 0] >= lo) & (a[:, 0] < hi)
        if m.sum():
            kn.append((math.exp(np.log(a[m, 0]).mean()), math.exp(np.log(a[m, 1]).mean())))
    knots[v] = np.array(kn)
    print("  knots %-8s " % v + "  ".join("%.0f:%.2f" % tuple(k) for k in kn))


def R_fit(v, N):
    c, d = fits[(v, 1000)][:2]
    return c * (np.maximum(N, 1000) / 4000) ** d


def R_knots(v, N):
    k = knots[v]
    return np.exp(np.interp(np.log(N), np.log(k[:, 0]), np.log(k[:, 1])))


buf = io.StringIO()
argv0 = sys.argv
sys.argv = ["frontier_rev.py"]
with contextlib.redirect_stdout(buf):
    G = runpy.run_path(SP + "/existence/synth/rev/frontier_rev.py", run_name="__main__")
sys.argv = argv0
w, Em, ns, N, PART, MU = G["w"], G["Em"], G["ns"], G["N"], G["PART"], G["VAR"]["MULT"]
t_cur = G["t_meas"]()
E = w * Em
T0 = w * ns * t_cur / 3600.0 / 8766


def curve(Rv):
    t = T0 * Rv
    o = np.argsort(-(E / t))
    return np.cumsum(t[o]) * MU, np.cumsum(E[o]) * MU


def Eat(c, C):
    return float(np.interp(C, c[0], c[1]))


def Cat(c, e):
    return float(np.interp(e, c[1], c[0])) if e <= c[1][-1] else float("inf")


cur = curve(np.ones_like(N))
print("\ncurrent: E(1,10,100,1e3,1e4) =", " ".join("%.3f" % Eat(cur, C) for C in (1, 10, 100, 1e3, 1e4)),
      " C(E=1) = %.0f  C(E=0.5) = %.1f  C(E=2) = %.3g" % (Cat(cur, 1), Cat(cur, 0.5), Cat(cur, 2)))
for name, Rf in (("power fit N>=1000", R_fit), ("own knots", R_knots)):
    print("\n== ratio model:", name)
    for v in vers:
        c = curve(Rf(v, N))
        print("  %-8s E(1)=%.4f (x%.2f)  E(10)=%.3f (x%.2f)  E(100)=%.3f (x%.2f)  C(E=1)=%.0f  C(E=.5)=%.0f  "
              "C_v/C_cur at E=0.03/0.1/0.3/1: %s" % (
                  v, Eat(c, 1), Eat(cur, 1) / Eat(c, 1), Eat(c, 10), Eat(cur, 10) / Eat(c, 10), Eat(c, 100),
                  Eat(cur, 100) / Eat(c, 100), Cat(c, 1), Cat(c, 0.5),
                  " / ".join("%.1f" % (Cat(c, e) / Cat(cur, e)) for e in (0.03, 0.1, 0.3, 1.0))))
# marginal CPU per expected square at E = 1 (central)
for v in ("legacy",):
    c = curve(R_knots(v, N))
    lo, hi = np.interp([0.98, 1.02], c[1], c[0])
    print("\nlegacy marginal CPU-yr per square at E=1: %.0f" % ((hi - lo) / 0.04))
lo, hi = np.interp([0.98, 1.02], cur[1], cur[0])
print("current marginal CPU-yr per square at E=1: %.0f" % ((hi - lo) / 0.04))
# where is the yield at E(1 CPU-yr) for legacy / current (E-weighted N)
for v, Rv in (("legacy", R_knots("legacy", N)), ("fdb77fc", np.ones_like(N))):
    t = T0 * Rv; o = np.argsort(-(E / t)); cT = np.cumsum(t[o]) * MU
    for C in (1, 100):
        j = np.searchsorted(cT, C); sel = o[:j + 1]
        print("  %s at %g CPU-yr: E-weighted N %.0f, marginal N %.0f, share of E from N<1000: %.3f" % (
            v, C, math.exp((E[sel] * np.log(N[sel])).sum() / E[sel].sum()), N[o[j]],
            E[sel][N[sel] < 1000].sum() / E[sel].sum()))

# extra checks: a further 17.6x on the current code at 1 CPU-yr; legacy at 1 CPU-yr = current at 1/R
print("\nE_cur(17.6)/E_cur(1) = %.2f ; E_cur(1)/E_cur(1/17.6) = %.2f" % (Eat(cur, 17.6) / Eat(cur, 1), Eat(cur, 1) / Eat(cur, 1 / 17.6)))
for v, c in (("legacy", curve(R_knots("legacy", N))), ("fdb77fc", cur)):
    out = []
    for C in (1, 100):
        e0 = Eat(c, C); lo, hi = np.interp([e0 * 0.98, e0 * 1.02], c[1], c[0])
        out.append("%.0f" % ((hi - lo) / (0.04 * e0)))
    print("marginal CPU-yr per square at 1 / 100 CPU-yr, %s: %s" % (v, " / ".join(out)))
