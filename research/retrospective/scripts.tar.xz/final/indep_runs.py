#!/usr/bin/env python3
"""Independent timing check for the retro review (binaries rebuilt from git archives;
byte-identical to retro/measure/bin). Child CPU time from wait4 rusage (user+sys);
for patched runs also the search time and per-r1 records from SAMPLE_LOG.
Appends JSON lines to runs/indep.jsonl."""
import json, os, subprocess, sys, time

R = os.path.dirname(os.path.abspath(__file__))
REPO = "/home/user/magic-squares"
B = R + "/bin"
OUT = R + "/runs/indep.jsonl"


def vecfile(exps, S):
    f = f"{R}/runs/e_6_{'_'.join(exps)}_{S}.txt"
    if not os.path.exists(f):
        subprocess.run([REPO + "/bin/enumerate", "--vec-size", "6", "--min-sum", str(S), "--max-sum", str(S),
                        "--file", f, *exps], check=True, stderr=subprocess.DEVNULL)
    return f


def run(tag, binary, exps, S, stride=1, offset=0):
    exps = exps.split()
    log = f"{R}/runs/{tag}_{'_'.join(exps)}_{S}_k{stride}_o{offset}_{int(time.time())}.log"
    env = dict(os.environ, SAMPLE_STRIDE=str(stride), SAMPLE_OFFSET=str(offset), SAMPLE_LOG=log)
    if binary.startswith("arrangement"):
        cmd = [B + "/" + binary, "--file", vecfile(exps, S), "--sum", str(S)]
    else:
        inst = f"{R}/runs/inst_{os.getpid()}.txt"
        open(inst, "w").write(f"6 | {' '.join(exps)} | {S} | - | -\n")
        cmd = [B + "/" + binary, inst]
    load = os.getloadavg()[0]
    t0 = time.time()
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, env=env)
    out = p.stdout.read()
    _, status, ru = os.wait4(p.pid, 0)
    cpu = ru.ru_utime + ru.ru_stime
    nsol = out.count(b"solution found")
    rec = dict(tag=tag, binary=binary, P=" ".join(exps), S=S, stride=stride, offset=offset, cpu=cpu,
               wall=time.time() - t0, load=load, legacy_solutions=nsol)
    if os.path.exists(log):
        lines = open(log).read().split("\n")
        end = [l for l in lines if l.startswith("#END")][0].split()
        rec.update(setup=float(end[2]), search=float(end[4]), nodes=int(end[6]), squares=int(end[8]), m=int(end[10]),
                   est=float(end[2]) + stride * float(end[4]), log=os.path.basename(log))
    else:
        rec["bench_out"] = out.decode()[-400:]
    with open(OUT, "a") as f:
        f.write(json.dumps(rec) + "\n")
    print(json.dumps(rec), flush=True)


if __name__ == "__main__":
    P900 = "12 6 3 2 1 0 1"
    run("A", "bench_fdb77fc", P900, 900)
    run("A", "arrangement_6_unpatched", P900, 900)
    run("A", "bench_df352df", P900, 900)
    run("A", "bench_a72cef3", P900, 900)
    run("A", "bench_fdb77fc", P900, 900)
    P3125 = "14 7 4 4 1 0 0 1"
    run("B", "bench_fdb77fc", P3125, 3125)
    run("B", "arrangement_6_patched", P3125, 3125, 8, 3)
    run("B", "bench_fdb77fc", P3125, 3125)
    P1080 = "12 6 3 2 1 1"
    run("C", "bench_fdb77fc_patched", P1080, 1080, 16, 77)
    run("C", "arrangement_6_patched", P1080, 1080, 128, 77)
    run("C", "bench_fdb77fc_patched", P1080, 1080, 16, 77)
