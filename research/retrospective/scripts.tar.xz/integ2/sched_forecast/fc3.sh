#!/bin/bash
# forecasts (final): stream A or B
S=/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad
D=$S/integ3; W=/home/user/magic-squares/.claude/worktrees/wf_98f7ea1f-a90-1; B=$S/integ2/base
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
H1="8766 0.1"; H10="87660 0.1"; H100="876600 0.01"
run() { # name prog state truth hours sample
  t0=$(date +%s)
  nice -n 10 python3 $2 --state $3 forecast --shipped --hours $5 --sample $6 --seed 1 --draws 400 --truth $4 \
    > $D/fc/$1.out 2>&1
  echo "$1 rc=$? $(( $(date +%s) - t0 )) s"
}
E3="$D/fc_variant.py engine3 $W/scripts"
if [ "$1" = A ]; then
  run after_measured_1 $W/scripts/scheduler.py $D/state_after measured $H1
  run after_measured_10 $W/scripts/scheduler.py $D/state_after measured $H10
  run after_measured_100 $W/scripts/scheduler.py $D/state_after measured $H100
  run after_engine3_measured_1 "$E3" $D/state_after measured $H1
  run after_engine3_measured_10 "$E3" $D/state_after measured $H10
else
  run before_anchored_100 $B/scripts/scheduler.py $D/state_before anchored $H100
  run after_anchored_1 $W/scripts/scheduler.py $D/state_after2 anchored $H1
  run after_anchored_10 $W/scripts/scheduler.py $D/state_after2 anchored $H10
  run after_anchored_100 $W/scripts/scheduler.py $D/state_after2 anchored $H100
  run after_engine3_measured_100 "$E3" $D/state_after2 measured $H100
fi
echo "FC3$1DONE"
