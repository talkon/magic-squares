"""scheduler.py forecast with a variant of the shipped calibration:
  engine3: ENGINE = 3 (engine 3's laws, the after-calibration priors)
  refit:   GLM_PRIORS = the calibration search's full refit posterior (sq, S, P means and sds,
           calib_post of research/calibration-target/archive/results/glm_update.json.xz)
usage: fc_variant.py VARIANT SCRIPTS_DIR scheduler-args..."""
import json, lzma, math, sys
var, scripts = sys.argv[1], sys.argv[2]
sys.path.insert(0, scripts)
import scheduler
if var == "engine3":
    scheduler.ENGINE = 3
elif var == "refit":
    d = json.load(lzma.open(scripts + "/../research/calibration-target/archive/results/glm_update.json.xz"))
    cp = d["calib_post"]
    assert list(cp["effects"]) == list(scheduler.EFFECTS)
    for k in ("sq", "S", "P"):
        scheduler.GLM_PRIORS[k] = (list(cp["beta"][k]), [math.sqrt(cp["cov"][k][i][i]) for i in range(len(scheduler.EFFECTS))])
else:
    raise SystemExit("variant?")
sys.argv = ["scheduler.py"] + sys.argv[3:]
scheduler.main()
