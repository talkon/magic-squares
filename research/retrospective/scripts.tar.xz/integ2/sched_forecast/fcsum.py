import glob, os, re, sys
for f in sorted(glob.glob(sys.argv[1] + "/*.out")):
    t = open(f).read()
    rows = re.findall(r"^\s+([0-9.]+)\s+[0-9.e+]+\s+([0-9.]+)\s+\d+\s+\d+\s+\d+", t, re.M)
    band = re.search(r"5% ([0-9.]+), median ([0-9.]+), mean ([0-9.]+), 95% ([0-9.]+)", t)
    disc = re.search(r"selection discount.*E = ([0-9.]+)", t)
    mode = re.search(r"mode .*?: (\d+)% of E in (\d+)% of the CPU", t)
    wo = re.findall(r"^\s+([0-9.]+)\s+([0-9.]+)\s+([0-9.]+)\s+([0-9.]+)$", t, re.M)
    print(os.path.basename(f)[:-4], " ".join(f"{c}:{e}" for c, e in rows),
          "| band 5-95%", band.group(1) + "-" + band.group(4) if band else "-", "median", band.group(2) if band else "-",
          "| x0.8", disc.group(1) if disc else "-", "| dfirst", mode.groups() if mode else "-",
          "| with/without", [w[3] for w in wo])
