"""Retrospective forecast for msearch engine 4 (integ/round2): the integrated build's ratios
(forecast_new.py) with the d-first column times engine 4 / engine 3 per sum, measured paired by
the round-2 perf verifier (189b49f vs the integrated binary, identical d samples, whole-sum CPU,
min of 2; integ2/perf/an/df2_rows.json), and for the one unmeasured d-first sum (13 7 4 3 1 1 /
2500, N 26,585) the fitted law e^(-0.103 - 0.204 ln(N/4000)). Sums below N = 5,000 run plain
(as forecast_new.py), so their engine-4 factor does not enter.
usage: python3 forecast_e4.py [tag=_e4] [analytic_rev_args=...]   -> ../../integ/forecast/results_new_e4.json (copied here)"""
import math, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'integ', 'forecast'))
import forecast_new as fn
E4 = {6671: 0.814, 7593: 0.780, 11697: 0.676, 15199: 0.701, 16424: 0.730, 20538: 0.589,
      20896: 0.558, 22992: 0.662, 31743: 0.652}
law = lambda N: math.exp(-0.103 - 0.204 * math.log(N / 4000))
new = []
for name, N, L, tb, tp, td, rp, rd in fn.MEAS:
    f = E4.get(N, law(N)) if N >= fn.NMIN_DFIRST else 1.0
    new.append((name, N, L, tb, tp, td * f, rp, rd * f))
fn.MEAS[:] = new
if not any(a.startswith('tag=') for a in sys.argv[1:]):
    sys.argv.append('tag=_e4')
fn.main()
