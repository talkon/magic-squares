"""The existence study's analytic model (existence/analytic/gmodel.py, revised factors of
existence/synth/rev/frontier_rev.py) evaluated on the cells of the scheduler's pool and on the first
search's sums, so that the strategies can be scored with the analytic E as the truth.

* per P: gmodel.eval_P (log E_magic per sum, log N on a geometric S grid, exact S_min), ~0.03 s per P;
* pool cells (the model lens's S grid, x = ln(S/S_min) step 0.004 up to 3.3 S_min): analytic log E and
  log N interpolated linearly in S, times the revised factors fac(N, k, x) and the cell width dS;
* the first search: E integrated over each P's searched sums S_min..min(max_S, 8 S_min) (as the
  existence study's analytic/legacy.py), with the same factors.

Cached in cache/an_*.npz, keyed by the factor settings (VAR of frontier_rev.py) and the pool cache.
"""
import os, sys, json, math, hashlib, multiprocessing
import numpy as np

SP = '/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad'
AN = SP + '/existence/analytic'
HERE = SP + '/retro/forecast'
GRID_DX = 0.004        # the model lens's x grid step (epop.XG)


def _init():
    os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
    if AN not in sys.path: sys.path.insert(0, AN)
    import gmodel, maxent
    return gmodel, maxent


def _profile(args):
    P, fmax, npts = args
    gmodel, maxent = _init()
    try:
        o = gmodel.eval_P(tuple(P), 6, 1e12, fmax=fmax, npts=npts)
    except Exception:
        o = None
    maxent._div_cache.clear()
    if o is None: return None
    return (np.array(o['S'], float), np.array(o['lEm_lin'], float), np.array(o['lN'], float), float(o['smin']))


def profiles(Ps, fmaxs, npts, nproc=3):
    with multiprocessing.Pool(nproc) as pool:
        return pool.map(_profile, [(P, f, npts) for P, f in zip(Ps, fmaxs)], chunksize=16)


def _interp(Sq, S, y, smin):
    """y (log scale) at Sq: linear in S, linear extrapolation beyond the last point, -inf below S_min"""
    out = np.interp(Sq, S, y)
    hi = Sq > S[-1]
    if hi.any() and len(S) >= 2:
        sl = (y[-1] - y[-2]) / (S[-1] - S[-2])
        out[hi] = y[-1] + sl * (Sq[hi] - S[-1])
    return np.where(Sq < smin, -np.inf, out)


def _k(P): return sum(1 for a in P if a > 0)


def pool_an(pool, fac, VAR, log=print, nproc=3):
    """analytic E per pool cell (e_an), the analytic N (N_an), and coverage diagnostics"""
    key = hashlib.md5(json.dumps([sorted(VAR.items()), len(pool['e']), float(pool['e'].sum()), 'v1']).encode()).hexdigest()[:10]
    path = f'{HERE}/cache/an_pool_{key}.npz'
    if os.path.exists(path): return dict(np.load(path))
    Ps = [tuple(map(int, p.split())) for p in pool['P']]
    pid = pool['pid']; dS = pool['dS'].astype(float)
    S_cell = dS / GRID_DX
    starts = np.r_[0, np.nonzero(np.diff(pid))[0] + 1, len(pid)]
    smax = np.zeros(len(Ps)); smin_l = np.full(len(Ps), np.inf)
    for a, b in zip(starts[:-1], starts[1:]):
        smax[pid[a]] = S_cell[a:b].max(); smin_l[pid[a]] = S_cell[a:b].min()
    # fmax relative to the analytic S_min (~ the lens's s0): cover the cells with a margin
    s0_est = np.array([6 * math.exp(sum(a * math.log(p) for a, p in zip(P, (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47))) / 6) for P in Ps])
    fmax = np.clip(smax / s0_est * 1.05, 1.5, 6.0)
    log(f'  analytic profiles for {len(Ps)} pool P ...')
    prof = profiles(Ps, fmax, 48, nproc)
    e_an = np.zeros(len(pid)); N_an = np.zeros(len(pid)); beyond = 0.0
    for a, b in zip(starts[:-1], starts[1:]):
        i = pid[a]; pr = prof[i]
        if pr is None: continue
        S, lEm, lN, s0 = pr
        Sq = S_cell[a:b]
        lm = _interp(Sq, S, lEm, s0); ln_ = _interp(Sq, S, lN, s0)
        Nq = np.exp(np.where(np.isfinite(ln_), ln_, 0.0))
        x = np.log(np.maximum(Sq, s0) / s0)
        e = np.exp(lm) * dS[a:b] * fac(Nq, _k(Ps[i]), x)
        e_an[a:b] = np.where(np.isfinite(e), e, 0.0); N_an[a:b] = Nq
        beyond += e_an[a:b][Sq > S[-1]].sum()
    out = dict(e_an=e_an, N_an=N_an, beyond_share=np.array(beyond / max(e_an.sum(), 1e-300)),
               failed=np.array(sum(1 for p in prof if p is None)))
    np.savez(path, **out)
    return out


def legacy_an(leg_rows, fac, VAR, log=print, nproc=3, cap=8.0):
    """analytic E of the first search's sums, per P: S_min .. min(max_S, cap S_min)"""
    key = hashlib.md5(json.dumps([sorted(VAR.items()), len(leg_rows), cap, 'v1']).encode()).hexdigest()[:10]
    path = f'{HERE}/cache/an_legacy_{key}.npz'
    if os.path.exists(path): return dict(np.load(path))
    Ps = [tuple(r['P']) for r in leg_rows]
    s0_est = np.array([6 * math.exp(sum(a * math.log(p) for a, p in zip(P, (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47))) / 6) for P in Ps])
    maxS = np.array([r['maxS'] if r['maxS'] < 10 ** 9 else 1e12 for r in leg_rows], float)
    fmax = np.clip(maxS / s0_est * 1.02, 1.01, cap)
    log(f'  analytic profiles for {len(Ps)} first-search P ...')
    prof = profiles(Ps, fmax, 60, nproc)
    E = np.zeros(len(Ps)); Emax = np.zeros(len(Ps)); Nw = np.zeros(len(Ps))
    for i, pr in enumerate(prof):
        if pr is None: continue
        S, lEm, lN, s0 = pr
        keep = S <= min(maxS[i], cap * s0) + 0.5
        S, lEm, lN = S[keep], lEm[keep], lN[keep]
        if len(S) < 2: continue
        lm = np.where(np.isfinite(lEm), lEm, -1e9)
        h = np.diff(S); dv = np.diff(lm); ea, eb = np.exp(lm[:-1]), np.exp(lm[1:])
        with np.errstate(divide='ignore', invalid='ignore'):
            seg = np.where(np.abs(dv) < 1e-9, h * ea, h * (eb - ea) / dv)
        seg = np.where(np.isfinite(seg), seg, 0.0)
        Nm = np.exp(0.5 * (lN[:-1] + lN[1:])); x = np.log(0.5 * (S[:-1] + S[1:]) / s0)
        seg = seg * fac(Nm, _k(Ps[i]), x)
        E[i] = seg.sum(); Emax[i] = S[-1] / s0
        Nw[i] = math.exp((seg * np.log(Nm)).sum() / seg.sum()) if seg.sum() > 0 else 0.0
    out = dict(E=E, fmax=Emax, Nw=Nw, failed=np.array(sum(1 for p in prof if p is None)))
    np.savez(path, **out)
    return out
