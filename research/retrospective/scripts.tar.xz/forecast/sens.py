"""Sensitivity of the retro forecasts: re-run retro.py with one setting changed at a time and tabulate.
usage: python3 sens.py [--run] [names...]
  --run: run the variants whose results are missing (or the named ones), 2 at a time, then summarize;
  without --run: summarize what exists. Writes sens.json and sens.md; tables.py folds sens.md into retro.md."""
import os, sys, json, subprocess, math
HERE = os.path.dirname(os.path.abspath(__file__))
VS = '["legacy","df352df","8d07935","a72cef3","2d2bc6d","f61e719","fdb77fc"]'
VARIANTS = [
    ('labels x1.0 (label model as is)', 'labels1', ['label_scale=1.0', 'do_strategy=false']),
    ('no > 256-label regime (all sums on the <= 256-label ratios)', 'nosplit', ['label_split=false', 'do_strategy=false']),
    ('legacy > 256-label ratio x0.5 (5.2)', 'leg256lo', ['R256_override={"legacy": 5.21}', 'do_strategy=false']),
    ('legacy > 256-label ratio x1.5 (15.6)', 'leg256hi', ['R256_override={"legacy": 15.6}', 'do_strategy=false']),
    ('ratios flat beyond the last measured N (~18k)', 'flat', ['beyond="flat"', 'do_strategy=false']),
    ('time: no steepening above 2x10^4 (slope 3.92 throughout)', 'a392', ['t_a2=0']),
    ("time: part 1's fit for the current code, 26 s (N/4000)^4.15", 'tfit', ['t_scale=0.507', 't_a=4.15']),
    ('analytic: review factors at their low corner', 'anlow', ['analytic_rev_args=["K7=0.7","NTR=1","PAIR=0.75","SQ12=1","X01=0.86"]']),
    ('analytic: review factors at their high corner', 'anhigh', ['analytic_rev_args=["K7=1","NTR=1.7","PAIR=1","SQ12=1.53","X01=0.97"]']),
    ('analytic: extra assignments m = 2.0 instead of 2.7', 'm20', ['analytic_rev_args=["MULT=2.0"]']),
]


def g(d, k):
    for kk in (k, str(k), str(float(k))):
        if kk in d: return d[kk]
    raise KeyError(k)


def summarize(res):
    A = res['analytic']['all']; L, C = A['legacy'], A['fdb77fc']
    o = dict(E1_leg=g(L['E'], 1), E1_cur=g(C['E'], 1), E100_leg=g(L['E'], 100), E100_cur=g(C['E'], 100),
             g1=g(C['E'], 1) / g(L['E'], 1), g100=g(C['E'], 100) / g(L['E'], 100),
             C1_leg=g(L['C'], 1.0), C1_cur=g(C['C'], 1.0),
             r01=g(L['C'], 0.1) / g(C['C'], 0.1), r1=g(L['C'], 1.0) / g(C['C'], 1.0))
    s = res.get('strategy_an', {})
    if 'legacy' in s and 'fdb77fc' in s:
        o.update(first_over_sched_leg=s['legacy']['C_first'] / s['legacy']['scheduler']['C_for_E_first'],
                 front_over_sched_E1_cur=g(s['fdb77fc']['frontier_all']['E'], 1) / g(s['fdb77fc']['scheduler']['E'], 1))
    return o


def run(names):
    todo = []
    for label, name, args in VARIANTS:
        d = f'{HERE}/sens/{name}'
        if not os.path.exists(d + '/results.json') or name in names:
            os.makedirs(d, exist_ok=True)
            todo.append((name, ['python3', HERE + '/retro.py', f'out="{d}"', f'versions={VS}', 'nproc=1', 'do_lens=false'] + args, d))
    procs = []
    while todo or procs:
        while todo and len(procs) < 2:
            name, cmd, d = todo.pop(0)
            procs.append((name, subprocess.Popen(cmd, stdout=open(d + '/run.log', 'w'), stderr=subprocess.STDOUT, cwd=HERE)))
        name, p = procs.pop(0); p.wait(); print(name, 'exit', p.returncode, flush=True)


def main(names):
    out = {}
    out['base'] = dict(label='base (as in T1-T5)', **summarize(json.load(open(HERE + '/results.json'))))
    for label, name, args in VARIANTS:
        f = f'{HERE}/sens/{name}/results.json'
        if os.path.exists(f):
            r = json.load(open(f))
            if 'all' in r.get('analytic', {}):
                out[name] = dict(label=label, **summarize(r))
    json.dump(out, open(HERE + '/sens.json', 'w'), indent=1)
    f = lambda x: (f'{x:.3f}' if x < 0.1 else f'{x:.2f}') if x < 1 else (f'{x:.1f}' if x < 100 else (f'{float(f"{x:.2g}"):,.0f}' if x < 1e6 else f'{x:.1e}'))
    L = ['### T8. Sensitivity (analytic model; one setting changed at a time)\n',
         '| variant | E(1 CPU-yr) legacy / current (ratio) | E(100) legacy / current (ratio) | CPU-yr for E = 1: legacy / current | C_legacy / C_current at E = 0.1 / 1 | first search -> scheduler, CPU factor at the first search\'s E (legacy code) | ideal frontier / scheduler, E(1 CPU-yr), current code |',
         '|---|---|---|---|---|---|---|']
    for k, o in out.items():
        L.append(f"| {o['label']} | {f(o['E1_leg'])} / {f(o['E1_cur'])} ({o['g1']:.2f}) | {f(o['E100_leg'])} / {f(o['E100_cur'])} ({o['g100']:.2f}) | "
                 f"{f(o['C1_leg'])} / {f(o['C1_cur'])} | {o['r01']:.1f} / {o['r1']:.1f} | "
                 + (f"{o['first_over_sched_leg']:.1f} | {o['front_over_sched_E1_cur']:.1f} |" if 'first_over_sched_leg' in o else '- | - |'))
    open(HERE + '/sens.md', 'w').write('\n'.join(L) + '\n')
    print('\n'.join(L))


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--run' in a:
        a.remove('--run'); run(a)
    main(a)
