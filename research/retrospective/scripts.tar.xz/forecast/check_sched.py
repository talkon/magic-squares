"""Check of the scheduler-strategy simulation: with the scheduler's own predictions as the truth
(its model as fitted, current code), the PAV block order should reproduce research/forecast.md's
base frontier (E ~ 0.015 at 1 CPU-yr, ~0.020 at 10, E_max ~ 0.022 for sums to ~1.8 S_min)."""
import sys, numpy as np
from retro_lib import *
from retro_lib import _mod
cfg = load_cfg(sys.argv[1:])
epop, mlib = _mod()
pool = pool_cells(cfg)
pN = pool['N'].astype(float)
pts = mlib.sum_time(pN) * pool['dS']
ep = pool['dpred'] * pts
bid, dens = pav_blocks(pool['pid'], pool['dpred'], pts)
cT, cE = block_curve(ep, pts, bid, dens)
print('scheduler model as truth: E(100 h, 1000 h, 1, 10, 100 CPU-yr) =', ' '.join('%.4f' % E_at(cT, cE, C) for C in (100 / 8766, 1000 / 8766, 1, 10, 100)), 'E_max %.4f' % cE[-1])
