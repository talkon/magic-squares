"""Data-driven expected magic squares of the first search: its squares per P (stats) x the lens's
P(magic | square) averaged over the P's searched sums with the model's S-profile of squares
(same as existence/model/searched.py, legacy part; rho 2.6, unclamped traversals)."""
import sys, json, numpy as np
from retro_lib import *
from retro_lib import _mod, _lens_eval
cfg = load_cfg(sys.argv[1:])
epop, mlib = _mod()
leg = json.load(open(SP + '/forecast/state/legacy.json'))
out = {}
for cp in (False, True):
    E = 0.0; n = 0
    for r in leg:
        P = mlib.norm(r['P'])
        if not P or r['sols'] == 0: continue
        S, N, sq, e, dS, L, s0 = _lens_eval(P, None, cfg)
        hi = r['maxS'] if r['maxS'] < 10 ** 9 else S[-1]
        m = S <= hi
        pm = mlib.pmagic(mlib.trav(P, S, s0, 's', clampP=cp), mlib.trav(P, S, s0, 'p', clampP=cp), 2.6)
        w = (sq * dS)[m]
        if w.sum() <= 0: continue
        E += r['sols'] * (w * pm[m]).sum() / w.sum(); n += r['sols']
    out['clamped' if cp else 'unclamped'] = E
    print('trav', 'clamped' if cp else 'unclamped', 'squares', n, 'E_magic %.5f' % E)
json.dump(out, open(HERE + '/legacy_E.json', 'w'))
