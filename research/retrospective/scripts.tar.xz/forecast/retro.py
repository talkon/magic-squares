"""Retro forecasts per code version and per search strategy.

usage: python3 retro.py [cfg.json] [key=value ...]     (keys: retro_lib.CFG)
writes results.json, tables.md and retro.md (= retro_head.md + tables.md) in this directory
(or in out=<dir>).  The first run builds the model-lens cell caches (~2-3 min, ~1 GB RAM) and the
analytic pool cache (~3 min on 3 processes); later runs take ~4 min.

Models
* primary: the existence study's analytic model, revised (existence/synth/rev/frontier_rev.py, executed
  here with cfg analytic_rev_args): ideal greedy order over all sums with S <= 2 S_min, all exponent
  assignments by E_all(C) = MULT E(C / MULT) plus the P*p sums;
* secondary check: the model lens (existence/model), monotone P, H_corr mid.
Time per sum for version v: R_v(N) x t_current(N) (retro_lib.Ratios, retro_lib.t_current).
"""
import sys, os, json, math, time, io, contextlib, runpy
from retro_lib import *          # sets the BLAS thread variables before numpy is imported
from retro_lib import _mod
import numpy as np
import an_cells

cfg = load_cfg(sys.argv[1:])
OUT = cfg.get('out', HERE)
os.makedirs(OUT, exist_ok=True)
RT = Ratios(cfg)
if cfg.get('versions'): VERSIONS = [v for v in VERSIONS if v in cfg['versions']]
Cs, Es = cfg['C_list'], cfg['E_list']
res = dict(cfg={k: v for k, v in cfg.items()}, versions={}, analytic={}, strategy={}, strategy_an={}, checks={})
T0 = time.time()
def log(*a): print(f'[{time.time() - T0:5.0f}s]', *a, flush=True)


def summ(cT, cE, m, Nsel=None, esel=None, order=None):
    """E(C), C(E), marginal costs and where the frontier is, for a cumulative curve (all-orders factor m)"""
    d = dict(E={C: float(E_at(cT, cE, C, m)) for C in Cs}, C={E: float(C_at(cT, cE, E, m)) for E in Es},
             marg_E1=marginal(cT, cE, 1.0, m), E_max=float(cE[-1] * m))
    d['marg_C'] = {C: marginal(cT, cE, d['E'][C], m) for C in Cs}
    if order is not None:
        wh = {}
        for C in Cs:
            j = min(int(np.searchsorted(cT, C / m)), len(order) - 1); sel = order[:j + 1]
            es = esel[sel]
            wh[C] = dict(N=float(np.exp((es * np.log(Nsel[sel])).sum() / max(es.sum(), 1e-300))), N_margin=float(Nsel[order[j]]))
        d['where'] = wh
    return d


# ------------------------------------------------------------------ speed ratios at fixed N (measured)
for v in VERSIONS:
    r = {}
    for n in (2000, 10000, 30000):
        r[f'R_cur_{n}'] = float(RT.R_low(v, n))
        r[f'speedup_vs_legacy_{n}'] = float(RT.R_low('legacy', n) / RT.R_low(v, n))
    r['R_cur_over256'] = RT.R256[v]
    r['speedup_vs_legacy_over256'] = RT.R256['legacy'] / RT.R256[v]
    res['versions'][v] = dict(ratios=r)

# ------------------------------------------------------------------ model-lens cells (also give the > 256-label share f(N))
lens = lens_cells(cfg, log)
e, N, L = lens['e'], lens['N'].astype(float), lens['L'].astype(float)
t0 = t_current(cfg, N, lens['sq']) * lens['dS'] if cfg['do_lens'] else None
log('lens cells', len(e), 'total E %.4g' % e.sum())
edges = np.linspace(np.log(300), np.log(3e6), 61)
lb = np.clip(np.digitize(np.log(N), edges) - 1, 0, len(edges) - 2)
big = (L * cfg['label_scale'] > 256)
fw = np.bincount(lb, weights=e * big, minlength=len(edges) - 1) / np.maximum(np.bincount(lb, weights=e, minlength=len(edges) - 1), 1e-300)
fN = 0.5 * (edges[:-1] + edges[1:])
def f256(Nq):
    return np.interp(np.log(np.maximum(np.asarray(Nq, float), 1)), fN, fw)
res['checks']['f256'] = {f'{math.exp(a):.0f}': float(b) for a, b in zip(fN[::3], fw[::3])}
if not cfg['do_lens']:
    del lens, e, N, L, big, lb

# ------------------------------------------------------------------ analytic model (primary): ideal frontier per version
def run_rev():
    p = cfg['analytic_rev_script']
    buf = io.StringIO(); argv0 = sys.argv
    sys.argv = [p] + [str(a) for a in (cfg.get('analytic_rev_args') or [])]
    try:
        with contextlib.redirect_stdout(buf):
            g = runpy.run_path(p, run_name='__main__')
    finally:
        sys.argv = argv0
    return g, buf.getvalue()


G, rev_out = run_rev()
w_, Em_, ns_, Nseg, PART, MU = G['w'], G['Em'], G['ns'], G['N'], G['PART'], G['VAR']['MULT']
Eseg = w_ * Em_
res['analytic'] = dict(source=dict(file=cfg['analytic_rev_script'], mtime=time.ctime(os.path.getmtime(cfg['analytic_rev_script'])),
                                   VAR=G['VAR'], args=cfg.get('analytic_rev_args') or []),
                       rev_stdout=rev_out, all={}, univ={}, alt_level={})
cur_an = {}
for label, mask, m in (('all', np.ones(len(Eseg), bool), MU), ('univ', PART == 'main', 1.0)):
    t0s = t_current(cfg, Nseg[mask]) * ns_[mask] * w_[mask]
    Ek, Nk = Eseg[mask], Nseg[mask]
    for v in VERSIONS:
        t = t0s * RT.R(v, Nk, f256=f256)
        o = np.argsort(-(Ek / t), kind='stable')
        cT = np.cumsum(t[o]) / YR; cE = np.cumsum(Ek[o])
        res['analytic'][label][v] = summ(cT, cE, m, Nk, Ek, o)
        cur_an.setdefault(v, {})[label] = (cT, cE, m)
    for v in VERSIONS:
        d = res['analytic'][label][v]; c = res['analytic'][label]['fdb77fc']; l = res['analytic'][label]['legacy']
        d['E_over_legacy'] = {C: d['E'][C] / l['E'][C] for C in Cs}
        d['cpu_legacy_over_v'] = {E: l['C'][E] / d['C'][E] for E in Es}
        d['cpu_v_over_current'] = {E: d['C'][E] / c['C'][E] for E in Es}
    log(f'analytic {label}: current E(C) ' + ' '.join('%.3f' % res['analytic'][label]['fdb77fc']['E'][C] for C in Cs) +
        '; legacy ' + ' '.join('%.3f' % res['analytic'][label]['legacy']['E'][C] for C in Cs))
# the second time level for the current code (and every version with it)
t0s = t_current(dict(cfg, t_scale=cfg['t_scale'] * cfg['t_scale_alt']), Nseg) * ns_ * w_
for v in VERSIONS:
    t = t0s * RT.R(v, Nseg, f256=f256)
    cT, cE = curve(Eseg, t)
    res['analytic']['alt_level'][v] = summ(cT, cE, MU)
log('analytic, time level x%.2f: current E(C) ' % cfg['t_scale_alt'] + ' '.join('%.3f' % res['analytic']['alt_level']['fdb77fc']['E'][C] for C in Cs))

# ------------------------------------------------------------------ model lens (secondary check): ideal frontier per version
cur_curves = {}
for v in (VERSIONS if cfg['do_lens'] else []):
    R = RT.R(v, N, L)
    t = t0 * R
    o = np.argsort(-(e / t), kind='stable')
    cT = np.cumsum(t[o]) / YR; cE = np.cumsum(e[o])
    m = cfg['m_all']
    d = dict(
        E_mono={C: float(E_at(cT, cE, C)) for C in Cs},
        E_all={C: float(E_at(cT, cE, C, m)) for C in Cs},
        C_mono={E: float(C_at(cT, cE, E)) for E in Es},
        C_all={E: float(C_at(cT, cE, E, m)) for E in Es},
        marg_E1_mono=marginal(cT, cE, 1.0), marg_E1_all=marginal(cT, cE, 1.0, m),
    )
    wh = {}
    for E in (0.03, 0.1, 0.3, 1.0):
        j = np.searchsorted(cE, E)
        if j < len(o):
            sel = o[:j + 1]
            wh[E] = dict(N=float(np.exp((e[sel] * np.log(N[sel])).sum() / e[sel].sum())), N_margin=float(N[o[j]]),
                         R_margin=float(R[o[j]]), share_over256=float((e[sel] * big[sel]).sum() / e[sel].sum()))
    d['where'] = wh
    res['versions'][v]['lens'] = d
    cur_curves[v] = (cT, cE)
    log(f'lens {v}: E(1,10,100,1e3,1e4) = ' + ' '.join('%.4f' % d['E_mono'][C] for C in Cs) + '  C(E=1) mono %.3g all %.3g' % (d['C_mono'][1.0], d['C_all'][1.0]))
for v in (VERSIONS if cfg['do_lens'] else []):
    d = res['versions'][v]['lens']; c = res['versions']['fdb77fc']['lens']; l = res['versions']['legacy']['lens']
    d['cpu_ratio_vs_current'] = {E: d['C_mono'][E] / c['C_mono'][E] for E in Es}
    d['cpu_ratio_legacy_over_v'] = {E: l['C_mono'][E] / d['C_mono'][E] for E in Es}
    d['central_E1'] = cfg['central_E1_cpu_yr'] * math.sqrt(d['C_mono'][1.0] / c['C_mono'][1.0] * d['C_all'][1.0] / c['C_all'][1.0])


# ------------------------------------------------------------------ strategies
def strategies():
    pool = pool_cells(cfg, log)
    leg = legacy_cells(cfg, log)
    epop, mlib = _mod()
    pe, pN, pL = pool['e'], pool['N'].astype(float), pool['L'].astype(float)
    pt0 = t_current(cfg, pN, pool['sq']) * pool['dS']
    pts = mlib.sum_time(pN) * pool['dS']          # the scheduler's own time model (current code)
    le, lN, lL = leg['e'], leg['N'].astype(float), leg['L'].astype(float)
    lt0 = t_current(cfg, lN, leg['sq']) * leg['dS']
    npl = len(leg['P'])
    # check: legacy time predicted by R_legacy x t_current vs the first search's actual per-P times
    lt_leg = lt0 * RT.R('legacy', lN, lL)
    pred_P = np.bincount(leg['pid'], weights=lt_leg, minlength=npl)
    act = leg['t_legacy']
    ok = (~leg['exh']) & (leg['xmax'] <= 1.2) & (act > 1)
    res['checks']['legacy_time'] = dict(
        actual_total_cpu_s=float(act.sum()), predicted_total_cpu_s=float(pred_P.sum()),
        nonexh_P=int(ok.sum()), nonexh_actual=float(act[ok].sum()), nonexh_pred=float(pred_P[ok].sum()),
        per_P_median_ratio=float(np.median(pred_P[ok] / act[ok])), per_P_sd_log=float(np.std(np.log(pred_P[ok] / act[ok]))),
        E_model=float(le.sum()), E_model_P_with_squares=float(np.bincount(leg['pid'], weights=le, minlength=npl)[leg['sols'] > 0].sum()),
        squares_model=float((leg['sq'] * leg['dS']).sum()), squares_actual=int(leg['sols'].sum()))
    log('legacy check', res['checks']['legacy_time'])

    # analytic truth on the pool's cells and the first search's sums
    A_pool = an_cells.pool_an(pool, G['fac'], G['VAR'], log, cfg['nproc'])
    rows = []
    for r in json.load(open(SP + '/forecast/state/legacy.json')):
        P = mlib.norm(r['P'])
        if P: rows.append(dict(P=list(P), maxS=r['maxS']))
    assert [' '.join(map(str, r['P'])) for r in rows] == list(leg['P'])
    A_leg = an_cells.legacy_an(rows, G['fac'], G['VAR'], log, cfg['nproc'])
    ae = A_pool['e_an']; aN = np.where(A_pool['N_an'] > 0, A_pool['N_an'], pN * 1.05) / 1.05   # as frontier_rev: N / 1.05 for the time
    at0 = t_current(cfg, aN) * pool['dS']
    E_first_an = float(A_leg['E'].sum())
    Psq = leg['sols'] > 0
    res['checks']['analytic_cells'] = dict(pool_E_an=float(ae.sum()), pool_E_lens=float(pe.sum()), pool_failed=int(A_pool['failed']),
                                           pool_beyond_grid_share=float(A_pool['beyond_share']), first_E_an=E_first_an,
                                           first_E_an_P_with_squares=float(A_leg['E'][Psq].sum()), first_failed=int(A_leg['failed']),
                                           first_E_lens=float(le.sum()))
    log('analytic cells', res['checks']['analytic_cells'])

    E_first = float(le.sum())
    for v in VERSIONS:
        R_l = RT.R(v, lN, lL)
        # first search: its actual CPU, rescaled per P by the version's time-weighted ratio to legacy
        num = np.bincount(leg['pid'], weights=lt0 * R_l, minlength=npl); den = np.bincount(leg['pid'], weights=lt_leg, minlength=npl)
        C_first = float((act * np.where(den > 0, num / np.maximum(den, 1e-300), 1.0 / RT.R_low('legacy', 1000) * RT.R_low(v, 1000))).sum() / YR)
        C_first_model = float((lt0 * R_l).sum() / YR)
        m = cfg['m_all']
        # ---- model lens as the truth
        st = None
        if cfg['do_lens']:
            R_p = RT.R(v, pN, pL)
            tp = pt0 * R_p
            bid, dens = pav_blocks(pool['pid'], pool['dpred'] / R_p, pts * R_p)
            sT, sE = block_curve(pe, tp, bid, dens)
            bid2, dens2 = pav_blocks(pool['pid'], pe / tp, tp)
            kT, kE = block_curve(pe, tp, bid2, dens2)
            iT, iE = curve(pe, tp)
            fT, fE = cur_curves[v]
            st = dict(C_first=C_first, C_first_model=C_first_model, E_first_model=E_first, E_first_data=cfg['legacy_E_data'])
            for name, (cT, cE, mm) in dict(scheduler=(sT, sE, 1), pool_prefix_ideal=(kT, kE, 1), pool_ideal=(iT, iE, 1),
                                           frontier_mono=(fT, fE, 1), frontier_all=(fT, fE, m)).items():
                st[name] = dict(E_at_C_first=float(E_at(cT, cE, C_first, mm)), C_for_E_first=float(C_at(cT, cE, E_first, mm)),
                                C_for_E_data=float(C_at(cT, cE, cfg['legacy_E_data'], mm)),
                                E={C: float(E_at(cT, cE, C, mm)) for C in Cs}, C={E: float(C_at(cT, cE, E, mm)) for E in Es},
                                E_max=float(cE[-1] * mm))
        res['strategy'][v] = st
        # ---- analytic model as the truth (same scheduler decisions: they use only the scheduler's own model)
        R_a = RT.R(v, aN, pL)
        ta = at0 * R_a
        bid, dens = pav_blocks(pool['pid'], pool['dpred'] / R_a, pts * R_a)
        sT, sE = block_curve(ae, ta, bid, dens)
        bid2, dens2 = pav_blocks(pool['pid'], ae / ta, ta)
        kT, kE = block_curve(ae, ta, bid2, dens2)
        iT, iE = curve(ae, ta)
        sa = dict(C_first=C_first, E_first_model=E_first_an, E_first_data=cfg['legacy_E_data'], E_first_floor=cfg['legacy_E_floor'])
        for name, (cT, cE, mm) in dict(scheduler=(sT, sE, 1), pool_prefix_ideal=(kT, kE, 1), pool_ideal=(iT, iE, 1),
                                       frontier_univ=cur_an[v]['univ'], frontier_all=cur_an[v]['all']).items():
            sa[name] = dict(E_at_C_first=float(E_at(cT, cE, C_first, mm)), C_for_E_first=float(C_at(cT, cE, E_first_an, mm)),
                            C_for_E_data=float(C_at(cT, cE, cfg['legacy_E_data'], mm)),
                            E={C: float(E_at(cT, cE, C, mm)) for C in Cs}, C={E: float(C_at(cT, cE, E, mm)) for E in Es},
                            E_max=float(cE[-1] * mm))
        res['strategy_an'][v] = sa
        log(f'strategy {v}: C_first {C_first:.3g} CPU-yr; analytic: E_first {E_first_an:.4f}, sched E(1,10,100) ' +
            ' '.join('%.4f' % sa['scheduler']['E'][C] for C in Cs[:3]) + ', pool-ideal ' + ' '.join('%.4f' % sa['pool_ideal']['E'][C] for C in Cs[:3]) +
            ', frontier ' + ' '.join('%.4f' % sa['frontier_all']['E'][C] for C in Cs[:3]) +
            (f'; lens: sched E(1) {st["scheduler"]["E"][1]:.4f}' if st else ''))


if cfg["do_strategy"]:
    strategies()

json.dump(res, open(OUT + '/results.json', 'w'), indent=1, default=float)
log('wrote results.json')
import tables
tables.write(res, OUT)
log('done')
