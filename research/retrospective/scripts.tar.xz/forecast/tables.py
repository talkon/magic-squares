"""Generated tables for retro.md (from retro.py's results; `python3 tables.py [dir]` rebuilds from results.json).
Writes tables.md and retro.md (= retro_head.md + tables.md [+ sens.md])."""
import json, math, os, sys

ADDS = {
    'legacy': 'code of the first search (`arrangement_6`)',
    'df352df': 'new arrange.c: forward checking, MRV, label bitsets, AVX-512',
    '8d07935': '+ byte counters, permute filters, vectorized child choice',
    'a72cef3': '+ support filter',
    '7cd9bc5': '+ tie-break by smallest label*',
    '2d2bc6d': '+ candidate lists carry their bitsets',
    'd023d32': '+ degeneracy label order*',
    'f61e719': '+ cross support, label order, msearch fixes',
    'fdb77fc': '+ round-2 micro-optimizations (current)',
}
ALL = ['legacy', 'df352df', '8d07935', 'a72cef3', '7cd9bc5', '2d2bc6d', 'd023d32', 'f61e719', 'fdb77fc']
MAIN = ['legacy', 'df352df', '8d07935', 'a72cef3', '2d2bc6d', 'f61e719', 'fdb77fc']


def g(d, k):
    for kk in (k, str(k), str(float(k)) if not isinstance(k, str) else k, str(int(float(k))) if not isinstance(k, str) and float(k) == int(float(k)) else k):
        if kk in d: return d[kk]
    raise KeyError(k)


def fe(x):
    if x is None or (isinstance(x, float) and math.isnan(x)): return '-'
    if x >= 10: return f'{x:,.0f}'
    if x >= 0.1: return f'{x:.2f}'
    if x >= 0.01: return f'{x:.3f}'
    return f'{x:.4f}'


def fc(x):
    if x is None or x == float('inf') or (isinstance(x, float) and math.isnan(x)): return 'never'
    if x >= 1e6: return f'{x:.1e}'.replace('e+0', 'e').replace('e+', 'e')
    if x >= 1e4: return f'{float(f"{x:.2g}"):,.0f}'
    if x >= 100: return f'{float(f"{x:.2g}"):,.0f}'
    if x >= 10: return f'{x:.0f}'
    if x >= 1: return f'{x:.1f}'
    return f'{x:.2g}'


def fr(x): return f'{x:.1f}' if x >= 10 else f'{x:.2f}'


def write(res, out):
    L = []
    V = res['versions']; cfg = res['cfg']
    A = res['analytic']; AA, AU, AL = A['all'], A['univ'], A['alt_level']
    MU = A['source']['VAR']['MULT']
    vs = [v for v in ALL if v in AA]
    ms = [v for v in MAIN if v in AA]
    m = cfg['m_all']
    L.append('## Generated tables\n')
    L.append('Produced by `retro.py`; every setting is in `results.json`. E is the expected number of magic squares found, '
             'C the CPU in single-core CPU-years. Unless marked, E is the existence study\'s analytic model as revised '
             f'(`synth/rev/frontier_rev.py`, VAR {A["source"]["VAR"]}): ideal order of all sums with S <= 2 S_min, '
             f'all exponent assignments by E_all(C) = {MU} E(C/{MU}) plus the P*p sums. '
             'The time per sum is R_v(N) x the existence time model (scheduler model to N = 4,000, 51.3 s (N/4000)^3.92 above, slope 5.2 above 2x10^4).\n')

    # ---------------- T1
    L.append('### T1. Key table\n')
    L.append('| version | what it adds | speed-up vs legacy at N = 2k / 10k / 30k (>256 labels) | E(1 CPU-yr) (x legacy) | E(10) (x legacy) | E(100) (x legacy) | CPU-yr for E = 1 at F = 2 / **1** / 0.5 | marginal CPU-yr per magic square at E = 1 |')
    L.append('|---|---|---|---|---|---|---|---|')
    for v in vs:
        r = V[v]['ratios']; d = AA[v]
        row = [v, ADDS[v], f"{fr(r['speedup_vs_legacy_2000'])} / {fr(r['speedup_vs_legacy_10000'])} / {fr(r['speedup_vs_legacy_30000'])} ({fr(r['speedup_vs_legacy_over256'])})"]
        for C in (1, 10, 100):
            row.append(f"{fe(g(d['E'], C))} (x{g(d['E_over_legacy'], C):.2f})")
        row.append(f"{fc(g(d['C'], 0.5))} / **{fc(g(d['C'], 1.0))}** / {fc(g(d['C'], 2.0))}")
        row.append(fc(d['marg_E1']))
        L.append('| ' + ' | '.join(row) + ' |')
    L.append('\n* Speed-ups: measured time ratios (part 1) at sums with <= 256 distinct numbers; beyond the last measured N (~18-23k) '
             'they follow each version\'s power-fit slope. In parentheses: the one measured sum with > 256 labels (N = 31.7k), '
             'where every version falls back to N x N matrices; legacy\'s value there rests on 2 sampled first rows.')
    L.append('* E has the model factor F (x/÷2 at 68%): E(C) at F is F x the central value. The "x legacy" ratios do not depend on F. '
             'CPU-yr for E = 1 at F is the central curve\'s C(E = 1/F).')
    L.append('* *7cd9bc5 and d023d32 were measured on bench sums only (N <= 2.3k); above that they are a72cef3 and 2d2bc6d times their bench ratio.\n')

    # ---------------- T2
    L.append('### T2. F-independent: E gain at a fixed budget, and CPU saved at a fixed E\n')
    L.append('Left: E_v(C) / E_legacy(C) (a constant factor on E cancels). Right: C_legacy(E) / C_v(E), the factor by which the CPU '
             'needed to reach a given E shrank. It depends on the magic-density model only through the N of the sums the frontier '
             'uses at that E.\n')
    L.append('| version | E_v / E_legacy at C = 1 | 10 | 100 | 1,000 | 10^4 CPU-yr | C_legacy / C_v at E = 0.03 | 0.1 | 0.3 | 1 | 2 |')
    L.append('|---|---|---|---|---|---|---|---|---|---|---|')
    for v in vs:
        d = AA[v]
        L.append(f'| {v} | ' + ' | '.join(f"{g(d['E_over_legacy'], C):.2f}" for C in (1, 10, 100, 1000, 10000)) + ' | ' +
                 ' | '.join(fr(g(d['cpu_legacy_over_v'], E)) for E in (0.03, 0.1, 0.3, 1.0, 2.0)) + ' |')
    cw = AA['fdb77fc'].get('where', {}); lw = AA['legacy'].get('where', {})
    if cw:
        L.append('\nWhere the frontier is (E-weighted N of the sums taken, base assignments): current code ' +
                 ', '.join(f"{fc(g(cw, C)['N'])} at {C:g} CPU-yr" for C in (1, 10, 100, 1000)) + '; legacy ' +
                 ', '.join(f"{fc(g(lw, C)['N'])} at {C:g}" for C in (1, 10, 100, 1000)) + '.\n')

    # ---------------- T3 steps
    L.append('### T3. What each step bought\n')
    L.append('| step | CPU factor at fixed E = 0.03 / 0.1 / 0.3 / 1 | E gain at C = 1 / 10 / 100 / 1,000 CPU-yr | lens check: CPU factor at E = 0.03 / 0.1 / 0.3 (mono) |')
    L.append('|---|---|---|---|')
    def steprow(a_, b_, bold=False):
        xa, xb = AA[a_], AA[b_]
        la, lb_ = V[a_].get('lens'), V[b_].get('lens')
        f = '.1f' if bold else '.2f'
        row = [f'{a_} -> {b_}' if not bold else f'**{a_} -> {b_}**',
               ' / '.join(format(g(xa['C'], E) / g(xb['C'], E), f) for E in (0.03, 0.1, 0.3, 1.0)),
               ' / '.join(f"{g(xb['E'], C) / g(xa['E'], C):.2f}" for C in (1, 10, 100, 1000)),
               ' / '.join(format(g(la['C_mono'], E) / g(lb_['C_mono'], E), f) for E in (0.03, 0.1, 0.3)) if la else '-']
        L.append('| ' + ' | '.join(row) + ' |')
    for a_, b_ in zip(ms[:-1], ms[1:]): steprow(a_, b_)
    steprow(ms[0], ms[-1], True)
    L.append('')

    # ---------------- T4 time level
    L.append('### T4. The level of the current code\'s time model\n')
    L.append(f"Primary: the existence study's model (msearch wall time, fitted before round 2). Alternative: x{cfg['t_scale_alt']:.2f}, "
             "part 1's median ratio of the current code's measured CPU time to that model on its 11 sums at N = 3.8k-31.7k "
             "(range x0.38-1.03; own fit 26 s (N/4000)^4.15). The level applies to every version alike (the ratios R_v stay), "
             f"so it is the same as a budget x{1 / cfg['t_scale_alt']:.2f}.\n")
    L.append('| version | time level | E(1 CPU-yr) | E(10) | E(100) | E(1,000) | CPU-yr for E = 1 at F = 2 / 1 / 0.5 |')
    L.append('|---|---|---|---|---|---|---|')
    for v in ('legacy', 'fdb77fc'):
        for lab, d in (('existence model (used)', AA[v]), (f"x{cfg['t_scale_alt']:.2f} (part 1)", AL[v])):
            L.append(f'| {v} | {lab} | ' + ' | '.join(fe(g(d['E'], C)) for C in (1, 10, 100, 1000)) +
                     f" | {fc(g(d['C'], 0.5))} / {fc(g(d['C'], 1.0))} / {fc(g(d['C'], 2.0))} |")
    L.append('')

    # ---------------- T5 strategy (analytic truth)
    S = res.get('strategy_an') or {}
    if 'legacy' in S and 'fdb77fc' in S:
        s0 = S['legacy']
        L.append('### T5. Search strategy at fixed code (analytic model as the truth)\n')
        L.append(f"First search: its own 1,136 P, each swept from S_min to its max_S; {s0['C_first']:.2f} CPU-yr with the legacy code (actual). "
                 f"Its E: {s0['E_first_model']:.4f} from the analytic model on its sums; from its data {cfg['legacy_E_floor']} "
                 f"(model-free lower bound, SP counts) to {s0['E_first_data']} (squares x P(magic | square)). "
                 "For another code version its CPU is the actual per-P CPU times that version's time-weighted ratio to legacy over the P's sums. "
                 "The scheduler's decisions use only its own fitted model (`model_6.json`, 10,075 P of `gen_candidates`, sums to 3.3 S_min, "
                 "taken per P in S order in blocks of non-increasing predicted density); they are scored with the analytic E and the true time.\n")
        names = [('first search (hand-picked P, each swept from S_min)', None),
                 ('scheduler as fitted (its model and pool)', 'scheduler'),
                 ('same pool, true E/t, S in order per P', 'pool_prefix_ideal'),
                 ('ideal frontier, analytic universe (sorted exponents; x1)', 'frontier_univ'),
                 (f'ideal frontier, all exponent assignments (x{MU} + P*p)', 'frontier_all')]
        for v in ('legacy', 'fdb77fc'):
            s = S[v]; Ef = s['E_first_model']
            L.append(f"**Code: {v}** (the first search's sums cost {fc(s['C_first'])} CPU-yr with it)\n")
            L.append(f"| strategy | CPU-yr to reach E = {fe(Ef)} | E after {fc(s['C_first'])} CPU-yr | E(1 CPU-yr) | E(10) | E(100) | E(10^4) | E available |")
            L.append('|---|---|---|---|---|---|---|---|')
            for lab, k in names:
                if k is None:
                    L.append(f"| {lab} | {fc(s['C_first'])} | {fe(Ef)} | - | - | - | - | - |")
                else:
                    d = s[k]
                    L.append(f"| {lab} | {fc(d['C_for_E_first'])} | {fe(d['E_at_C_first'])} | " + ' | '.join(fe(g(d['E'], C)) for C in (1, 10, 100, 10000)) +
                             f" | {fe(d['E_max'])} |")
            L.append('')
        # decomposition
        c = S['fdb77fc']; l = S['legacy']
        chain = [('legacy code, first search\'s strategy', l['C_first']),
                 ('current code, same sums', c['C_first']),
                 ('+ scheduler as fitted', c['scheduler']['C_for_E_first']),
                 ('+ ideal order, analytic universe', c['frontier_univ']['C_for_E_first']),
                 ('+ all exponent assignments', c['frontier_all']['C_for_E_first'])]
        L.append(f"**Reaching the first search's E ({fe(c['E_first_model'])}), code x strategy:**\n")
        L.append('| code, strategy | CPU-yr | factor |')
        L.append('|---|---|---|')
        prev = None
        for lab, x in chain:
            L.append(f"| {lab} | {fc(x)} | {'' if prev is None else 'x%.1f' % (prev / x)} |")
            prev = x
        L.append(f"| total | | x{chain[0][1] / chain[-1][1]:.0f} |\n")

    # ---------------- T6 lens
    if 'lens' in V['legacy']:
        lens_tables(L, res, vs, m)
    _tail(L, res, cfg, AA, out)


def lens_tables(L, res, vs, m):
    V = res['versions']; cfg = res['cfg']
    L.append('### T6. Secondary check: the model lens\n')
    L.append(f'Model lens (existence/model, H_corr mid; P with non-increasing exponents "mono", all orders by E_all(C) = {m} E_mono(C/{m}), optimistic). '
             '"central": the lens\'s realistic all-orders cost of E = 1 for the current code '
             f'({cfg["central_E1_cpu_yr"]:,.0f} CPU-yr) scaled by each version\'s CPU ratio.\n')
    L.append('| version | E(1 CPU-yr) mono / all | E(10) | E(100) | E_v / E_legacy at 1 / 100 CPU-yr (mono) | CPU-yr for E = 1: mono / all / central | C_legacy / C_v at E = 0.03 / 0.1 / 0.3 / 1 (mono) |')
    L.append('|---|---|---|---|---|---|---|')
    ll = V['legacy']['lens']
    for v in vs:
        d = V[v]['lens']
        L.append(f"| {v} | " + ' | '.join(f"{fe(g(d['E_mono'], C))} / {fe(g(d['E_all'], C))}" for C in (1, 10, 100)) +
                 f" | {g(d['E_mono'], 1) / g(ll['E_mono'], 1):.2f} / {g(d['E_mono'], 100) / g(ll['E_mono'], 100):.2f}" +
                 f" | {fc(g(d['C_mono'], 1.0))} / {fc(g(d['C_all'], 1.0))} / {fc(d['central_E1'])} | " +
                 ' / '.join(fr(g(ll['C_mono'], E) / g(d['C_mono'], E)) for E in (0.03, 0.1, 0.3, 1.0)) + ' |')
    Sl = res.get('strategy') or {}
    if 'fdb77fc' in Sl:
        L.append('\nStrategy with the lens as the truth (first search: lens E of its sums '
                 f"{fe(Sl['legacy']['E_first_model'])}):\n")
        L.append('| code | strategy | CPU-yr to reach the first search\'s E | E(1 CPU-yr) | E(10) | E(100) | E available |')
        L.append('|---|---|---|---|---|---|---|')
        for v in ('legacy', 'fdb77fc'):
            s = Sl[v]
            L.append(f"| {v} | first search | {fc(s['C_first'])} | - | - | - | - |")
            for lab, k in (('scheduler as fitted', 'scheduler'), ('same pool, true E/t', 'pool_prefix_ideal'),
                           ('ideal, monotone P', 'frontier_mono'), (f'ideal, all orders (x{m})', 'frontier_all')):
                d = s[k]
                L.append(f"| {v} | {lab} | {fc(d['C_for_E_first'])} | " + ' | '.join(fe(g(d['E'], C)) for C in (1, 10, 100)) + f" | {fe(d['E_max'])} |")
    L.append('')


def _tail(L, res, cfg, AA, out):
    # ---------------- checks
    ck = res.get('checks', {})
    L.append('### T7. Checks\n')
    lt = ck.get('legacy_time')
    if lt:
        L.append(f"* First search, time model: R_legacy(N) x t_current(N) over its sums (to 3.3 S_min) predicts {lt['predicted_total_cpu_s'] / 3.15576e7:.2f} CPU-yr "
                 f"against {lt['actual_total_cpu_s'] / 3.15576e7:.2f} actual. On the {lt['nonexh_P']} P whose sweeps stayed below 3.3 S_min: "
                 f"{lt['nonexh_pred'] / 3.15576e7:.2f} vs {lt['nonexh_actual'] / 3.15576e7:.2f} CPU-yr, per-P median ratio {lt['per_P_median_ratio']:.2f}, sd(ln) {lt['per_P_sd_log']:.2f}.")
        L.append(f"* First search, squares: the model lens predicts {lt['squares_model']:,.0f} semi-magic squares in its sums against {lt['squares_actual']:,} found.")
    ac = ck.get('analytic_cells')
    if ac:
        L.append(f"* Analytic E of the first search's sums: {ac['first_E_an']:.4f} ({ac['first_E_an_P_with_squares']:.4f} in the P that gave squares); "
                 f"lens: {ac['first_E_lens']:.4f}; data: {cfg['legacy_E_floor']}-{cfg['legacy_E_data']}. "
                 f"Scheduler pool: analytic E {ac['pool_E_an']:.3f} vs lens {ac['pool_E_lens']:.3f} (sums to 3.3 S_min); "
                 f"{ac['pool_failed']} pool P failed to evaluate, {100 * ac['pool_beyond_grid_share']:.2f}% of the pool's analytic E is extrapolated beyond the profile grid.")
    cur = AA['fdb77fc']
    L.append(f"* The current code's analytic curve reproduces existence.md section 6 (0.156 / 0.338 / 0.641 / 1.09 / 1.61): "
             + ' / '.join(f"{g(cur['E'], C):.3g}" for C in (1, 10, 100, 1000, 10000)) + '.')
    f2 = ck.get('f256')
    if f2:
        L.append('* E-weighted share of the lens sums with more than 256 labels (label model x %.2f), used for the analytic segments: ' % cfg['label_scale'] +
                 ', '.join(f'N {k}: {v:.2f}' for k, v in f2.items() if 3000 <= float(k) <= 60000) + '.')
    L.append('')
    txt = '\n'.join(L) + '\n'
    open(os.path.join(out, 'tables.md'), 'w').write(txt)
    head = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'retro_head.md')
    sens = os.path.join(out, 'sens.md')
    if os.path.exists(head):
        body = open(head).read().rstrip() + '\n\n' + txt
        if os.path.exists(sens): body += '\n' + open(sens).read()
        open(os.path.join(out, 'retro.md'), 'w').write(body)


if __name__ == '__main__':
    d = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.abspath(__file__))
    write(json.load(open(os.path.join(d, 'results.json'))), d)
