"""Retro forecasts, part 2: expected magic squares E(C) per code version and per search strategy.

Everything that is a modelling choice is in CFG (override with a JSON file or key=value on the
command line of retro.py), so the whole computation can be re-run when the existence study's
parameters change.

Inputs
* measured speed ratios R_v(N) = t_v / t_current per code version (retro/measure/ratio_model.json);
* the existence study's "model lens" (existence/model): per-(P, S) expected magic squares e
  (H model x h(N) = A (N/1e4)^B for N >= 3000, 0.8 below; rho 2.6, unclamped traversals) on its
  monotone population, and its time model for the current code
  t(N) = scheduler model (N <= 4000), t4000 (N/4000)^a, slope a2 above n2, floor 1 s per square;
* optionally the existence synthesis's analytic segments (existence/analytic/frontier_segs.json,
  existence/synth/rev/frontier_rev.py), which carry their own all-assignment multiplier.

Time for version v: t_v(N, L) = R_v(N, L) x t_current(N); R_v from the per-N-bin knots
(piecewise linear in ln N), continued beyond the last knot with the N >= 3000 power-fit slope
(or flat), and replaced by the measured "more than 256 labels" ratio where the sum has > 256
distinct numbers (label model x label_scale; for segment models without labels, a blend by
the fraction f(N) of sums with > 256 labels, taken from the model-lens cells).
"""
import os, sys, json, math, hashlib, time
for _v in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ.setdefault(_v, '1')      # before numpy: the analytic model's worker processes use one thread each
import numpy as np

SP = '/tmp/claude-0/-home-user-magic-squares/f8940ae0-7961-577c-be6c-6db2a2de5f8e/scratchpad'
MD = SP + '/existence/model'
HERE = SP + '/retro/forecast'
REPO = '/home/user/magic-squares'
YR = 8766.0 * 3600.0          # CPU-seconds per CPU-year

CFG = dict(
    # model lens (existence/model): population and the large-N correction h(N) = hA (N/1e4)^hB
    lens_pop=MD + '/sample/pop_Hc_mid_30000.json', hA=0.64, hB=-0.27, h_small=0.8,
    # time model of the current code (existence/model/model.md section 9, "steep")
    t4000=0.0,           # 0: the scheduler model's sum_time(4000) (= 51.3 s)
    t_a=3.92, t_a2=5.2, t_n2=2.0e4, t_floor=1.0,
    t_scale=1.0,         # multiply the current code's time model (e.g. 1/1.7: part 1's measured level)
    # all exponent orders: E_all(C) = m E_mono(C / m)  (model lens, optimistic: same E/t distribution)
    m_all=4.5,
    # the existence study's "realistic" all-orders cost of E = 1 for the current code, scaled per version
    central_E1_cpu_yr=3000.0,
    # speed ratios
    ratio_model=SP + '/retro/measure/ratio_model.json',
    beyond='fit',        # beyond the last knot: 'fit' (power-fit slope, N >= 3000 fit) or 'flat'
    beyond_cap=1.0e5,    # ... up to this N, flat afterwards
    label_split=True,    # use the > 256 labels ratio where labels > 256
    label_scale=1.13,    # actual labels / label model (existence.md 3.3: model low by 5-18%)
    over256_8d07935='interp',   # not measured: log-interpolate between df352df and a72cef3
    # strategies
    sched_pool=dict(tau_min=800, tau_max=12000, max_big_primes=2),
    legacy_cpu_s=35796954.7,    # stats/stats_short.txt, total time of the first search
    legacy_E_data=0.0041,       # its 758,949 squares x the lens's P(magic | square) (legacy_E.py; README's estimate: 0.0037)
    # budgets
    C_list=[1, 10, 100, 1000, 10000], E_list=[0.01, 0.03, 0.1, 0.3, 0.5, 1.0, 2.0],
    legacy_E_floor=0.0037,      # existence.md 6: model-free lower bound from the first search's SP counts
    # analytic (existence synthesis): the primary model. frontier_rev.py is executed (with these arguments,
    # e.g. ["SQ12=1", "NTR=1"]) and its segments, factors fac(N, k, x) and multiplier MULT are used
    analytic_rev_script=SP + '/existence/synth/rev/frontier_rev.py', analytic_rev_args=[],
    analytic_published=None, analytic_published_mult=2.6,   # the pre-review segments (existence/analytic/frontier_segs.json), optional
    t_scale_alt=0.58,    # second time level for the current code: part 1's median fdb77fc / model on its 11 sums at N >= 3,786
    nproc=3,             # worker processes for the analytic profiles
    # run control
    versions=None,       # None: all; else a list (must include 'legacy' and 'fdb77fc')
    do_strategy=True, do_analytic=True,
    do_lens=True,        # False: skip the model lens's frontier and lens-truth strategies (the lens cells still give f(N))
    R256_override={},    # e.g. {"legacy": 5.2}: replace a measured > 256-label ratio
)

VERSIONS = ['legacy', 'df352df', '8d07935', 'a72cef3', '7cd9bc5', '2d2bc6d', 'd023d32', 'f61e719', 'fdb77fc']
MAIN = ['legacy', 'df352df', '8d07935', 'a72cef3', '2d2bc6d', 'f61e719', 'fdb77fc']


def load_cfg(argv):
    cfg = dict(CFG)
    for a in argv:
        if a.endswith('.json') and os.path.exists(a):
            cfg.update(json.load(open(a)))
        elif '=' in a:
            k, v = a.split('=', 1)
            try: cfg[k] = json.loads(v)
            except Exception: cfg[k] = v
    return cfg


def _mod():
    if MD not in sys.path: sys.path.insert(0, MD)
    import epop, mlib
    return epop, mlib


# ---------------------------------------------------------------- speed ratios
class Ratios:
    def __init__(self, cfg):
        d = json.load(open(cfg['ratio_model']))
        self.cfg = cfg; self.v = d['versions']; self.cur = d['current']
        self.R256 = {}
        for name, o in self.v.items():
            ov = o.get('over_256_labels') or []
            if ov: self.R256[name] = float(ov[0]['ratio'])
        self.R256['fdb77fc'] = 1.0
        # 8d07935: not measured above 256 labels; log-interpolate by its position at the last knot
        k = lambda n: dict((int(a), b) for a, b in self.v[n]['knots_N_ratio'])
        kd, k8, ka = k('df352df'), k('8d07935'), k('a72cef3')
        Nl = max(kd)
        pos = (math.log(kd[Nl]) - math.log(k8[Nl])) / (math.log(kd[Nl]) - math.log(ka[Nl]))
        self.R256['8d07935'] = math.exp(math.log(self.R256['df352df']) - pos * (math.log(self.R256['df352df']) - math.log(self.R256['a72cef3'])))
        # bench-only versions: proxies (7cd9bc5 ~ a72cef3, d023d32 ~ 2d2bc6d), scaled by their ratio on the bench knots
        self.proxy = {}
        for name, base in (('7cd9bc5', 'a72cef3'), ('d023d32', '2d2bc6d')):
            kn, kb = k(name), k(base)
            common = [n for n in kn if n in kb]
            f = math.exp(np.mean([math.log(kn[n] / kb[n]) for n in common]))
            self.proxy[name] = (base, f)
            self.R256[name] = self.R256[base] * f
        self.R256.update(cfg.get('R256_override') or {})

    def knots(self, name):
        if name in self.proxy:
            base, f = self.proxy[name]
            return self.knots(base)[0], self.knots(base)[1] * f
        a = np.array(self.v[name]['knots_N_ratio'], float)
        return np.log(a[:, 0]), np.log(a[:, 1])

    def slope(self, name):
        if name in self.proxy: return self.slope(self.proxy[name][0])
        pf = self.v[name].get('power_fits') or {}
        f = pf.get('N>=3000') or pf.get('N>=1000')
        return f['b'] if f else 0.0

    def R_low(self, name, N):
        """ratio for sums with <= 256 labels"""
        lN = np.log(np.maximum(np.asarray(N, float), 1.0))
        xk, yk = self.knots(name)
        y = np.interp(lN, xk, yk)
        if self.cfg['beyond'] == 'fit':
            lc = np.minimum(lN, math.log(self.cfg['beyond_cap']))
            y = np.where(lN > xk[-1], yk[-1] + self.slope(name) * (lc - xk[-1]), y)
        return np.exp(y)

    def R(self, name, N, L=None, f256=None):
        r = self.R_low(name, N)
        if not self.cfg['label_split']: return r
        if L is not None:
            return np.where(np.asarray(L) * self.cfg['label_scale'] > 256, self.R256[name], r)
        if f256 is not None:
            f = f256(N)
            return (1 - f) * r + f * self.R256[name]
        return r


# ---------------------------------------------------------------- time model of the current code
def t_current(cfg, N, sq=None):
    """CPU-s per sum for the current code (existence model), with the floor of t_floor s per square"""
    epop, mlib = _mod()
    N = np.asarray(N, float)
    t4000 = cfg['t4000'] or float(mlib.sum_time(4000.0))
    t = np.where(N <= 4000, mlib.sum_time(np.minimum(N, 4000.0)), t4000 * (np.maximum(N, 1) / 4000.0) ** cfg['t_a'])
    if cfg['t_a2']:
        n2 = cfg['t_n2']
        t = np.where(N > n2, t4000 * (n2 / 4000.0) ** cfg['t_a'] * (N / n2) ** cfg['t_a2'], t)
    if sq is not None and cfg['t_floor']:
        t = np.maximum(t, cfg['t_floor'] * np.asarray(sq, float))
    return t * cfg['t_scale']


# ---------------------------------------------------------------- model-lens cells
def _lens_eval(P, smin, cfg):
    """grid of sums of P: S, N, squares per sum, e (expected magic per grid cell), dS, labels, x"""
    epop, mlib = _mod()
    import hmodel as hm
    from lmodel import labels
    LCW = json.load(open(MD + '/lcal.json'))['cw']
    S, N, s0 = epop.profile(P, smin)
    o = dict(epop.DEF, sqmodel='H', hfac=1.0)
    sq, pm = epop.per_sum(P, S, N, s0, o)
    hf = np.where(N < 3000, cfg['h_small'], cfg['hA'] * (np.maximum(N, 1) / 1e4) ** cfg['hB'])
    sq = sq * hf
    dS = S * np.gradient(epop.XG)
    e = sq * pm * dS
    xp = np.log(S / 6) - mlib.lnP(P) / 6
    Lp = labels(P, S, LCW * np.sqrt(np.maximum(xp, 1e-6)))
    L = hm.Lhat(Lp, N, np.log(S / s0))
    return S, N, sq, e, dS, L, s0


def _key(cfg, extra):
    h = hashlib.md5(json.dumps([cfg['lens_pop'], cfg['hA'], cfg['hB'], cfg['h_small'], extra], sort_keys=True).encode()).hexdigest()[:10]
    return h


def lens_cells(cfg, log=print):
    """all cells with e > 0 of the model lens's monotone population (cached)"""
    path = f"{HERE}/cache/lens_{_key(cfg, 'v1')}.npz"
    if os.path.exists(path):
        return dict(np.load(path, allow_pickle=True))
    os.makedirs(HERE + '/cache', exist_ok=True)
    epop, mlib = _mod()
    rows = json.load(open(cfg['lens_pop']))['rows']
    cols = {k: [] for k in ('pid', 'e', 'N', 'sq', 'dS', 'L', 'xi')}
    Ps, smins = [], []
    t0 = time.time()
    for i, r in enumerate(rows):
        P = tuple(r['P'])
        S, N, sq, e, dS, L, s0 = _lens_eval(P, r['smin'], cfg)
        m = e > 0
        if not m.any(): continue
        pid = len(Ps); Ps.append(' '.join(map(str, P))); smins.append(s0)
        cols['pid'].append(np.full(m.sum(), pid, np.int32)); cols['e'].append(e[m]); cols['N'].append(N[m].astype(np.float32))
        cols['sq'].append(sq[m].astype(np.float32)); cols['dS'].append(dS[m].astype(np.float32)); cols['L'].append(L[m].astype(np.float32))
        cols['xi'].append(np.nonzero(m)[0].astype(np.int16))
        if i % 20000 == 0: log(f'  lens cells: {i}/{len(rows)} P, {time.time() - t0:.0f} s')
    out = {k: np.concatenate(v) for k, v in cols.items()}
    out['P'] = np.array(Ps); out['smin'] = np.array(smins)
    np.savez(path, **out)
    return out


def pool_cells(cfg, log=print):
    """the scheduler's candidate pool (scripts/scheduler.py gen_candidates): every cell in S order,
    with the true (model-lens) e and the scheduler's own predicted magic squares per CPU-s"""
    path = f"{HERE}/cache/pool_{_key(cfg, ['v1', cfg['sched_pool']])}.npz"
    if os.path.exists(path):
        return dict(np.load(path, allow_pickle=True))
    epop, mlib = _mod()
    sys.path.insert(0, REPO + '/scripts')
    import scheduler as sch
    sp = cfg['sched_pool']
    cands = sch.gen_candidates(6, sp['tau_min'], sp['tau_max'], sp['max_big_primes'])
    M = mlib.M
    cols = {k: [] for k in ('pid', 'e', 'N', 'sq', 'dS', 'L', 'dpred')}
    Ps = []
    for P in cands:
        P = mlib.norm(P)
        S, N, sq, e, dS, L, s0 = _lens_eval(P, None, cfg)
        ok = N >= 12
        if not ok.any(): continue
        # scheduler's prediction (model_6.json as used by the forecast; clamped as the scheduler does)
        sq_s = mlib.sq_model(P, S, N, s0)
        ts = mlib.sum_time(N)
        rate = np.minimum(sq_s / ts, M.get('rate_cap', 1e300))
        pm_s = mlib.pmagic(mlib.trav(P, S, s0, 's', clampP=True), mlib.trav(P, S, s0, 'p', clampP=True), M['rho'])
        dpred = np.where(ok, rate * pm_s, 0.0)
        pid = len(Ps); Ps.append(' '.join(map(str, P)))
        n = ok.sum()
        cols['pid'].append(np.full(n, pid, np.int32)); cols['e'].append(e[ok]); cols['N'].append(N[ok].astype(np.float32))
        cols['sq'].append(sq[ok].astype(np.float32)); cols['dS'].append(dS[ok].astype(np.float32)); cols['L'].append(L[ok].astype(np.float32))
        cols['dpred'].append(dpred[ok])
    out = {k: np.concatenate(v) for k, v in cols.items()}
    out['P'] = np.array(Ps)
    np.savez(path, **out)
    log(f'  pool: {len(Ps)} P, {len(out["e"])} cells')
    return out


def legacy_cells(cfg, log=print):
    """the first search's cells: every grid sum of each of its P up to the P's max_S
    (exhaustive P: the whole grid, x <= 1.2), with the actual legacy CPU time per P"""
    path = f"{HERE}/cache/legacy_{_key(cfg, 'v1')}.npz"
    if os.path.exists(path):
        return dict(np.load(path, allow_pickle=True))
    epop, mlib = _mod()
    leg = json.load(open(SP + '/forecast/state/legacy.json'))
    cols = {k: [] for k in ('pid', 'e', 'N', 'sq', 'dS', 'L')}
    Ps, tl, sols, exh, xmax, smins = [], [], [], [], [], []
    for r in leg:
        P = mlib.norm(r['P'])
        if not P: continue
        S, N, sq, e, dS, L, s0 = _lens_eval(P, None, cfg)
        hi = r['maxS'] if r['maxS'] < 10 ** 9 else S[-1]
        m = (S <= hi) & (N >= 12)
        pid = len(Ps); Ps.append(' '.join(map(str, P))); tl.append(r['time']); sols.append(r['sols'])
        exh.append(r['maxS'] >= 10 ** 9); xmax.append(math.log(max(hi, s0) / s0)); smins.append(s0)
        n = m.sum()
        cols['pid'].append(np.full(n, pid, np.int32)); cols['e'].append(e[m]); cols['N'].append(N[m].astype(np.float32))
        cols['sq'].append(sq[m].astype(np.float32)); cols['dS'].append(dS[m].astype(np.float32)); cols['L'].append(L[m].astype(np.float32))
    out = {k: np.concatenate(v) for k, v in cols.items()}
    out.update(P=np.array(Ps), t_legacy=np.array(tl), sols=np.array(sols), exh=np.array(exh), xmax=np.array(xmax), smin=np.array(smins))
    np.savez(path, **out)
    return out


# ---------------------------------------------------------------- frontier arithmetic
def curve(e, t, order=None):
    """cumulative (CPU-yr, E) along the order (default: decreasing e/t)"""
    if order is None:
        order = np.argsort(-(e / np.maximum(t, 1e-300)), kind='stable')
    cT = np.cumsum(t[order]) / YR
    cE = np.cumsum(e[order])
    return cT, cE


def E_at(cT, cE, C, m=1.0):
    """E after C CPU-yr; m > 1: all-orders scaling E_all(C) = m E(C/m)"""
    return m * np.interp(np.asarray(C, float) / m, cT, cE)


def C_at(cT, cE, E, m=1.0):
    E = np.asarray(E, float) / m
    return np.where(E <= cE[-1], m * np.interp(E, cE, cT), np.inf)


def marginal(cT, cE, E, m=1.0, w=0.02):
    """CPU-yr per expected magic square at the margin where E is reached"""
    E = E / m
    if E > cE[-1]: return float('inf')
    lo, hi = np.interp([E * (1 - w), min(E * (1 + w), cE[-1])], cE, cT)
    return float((hi - lo) / (min(E * (1 + w), cE[-1]) - E * (1 - w)))


def pav_blocks(pid, d_pred, t_pred):
    """per P (cells in S order, contiguous by pid): pool adjacent cells into blocks of non-increasing
    predicted density (the scheduler's greedy order in the limit of small units). Returns block id per cell
    and the block densities."""
    n = len(pid)
    e_pred = d_pred * t_pred
    bid = np.empty(n, np.int64)
    dens = []
    starts = np.r_[0, np.nonzero(np.diff(pid))[0] + 1, n]
    nb = 0
    for a, b in zip(starts[:-1], starts[1:]):
        # stack of blocks: [start, end, sum_e, sum_t]
        st = []
        for i in range(a, b):
            blk = [i, i + 1, e_pred[i], t_pred[i]]
            while st and st[-1][2] * blk[3] <= blk[2] * st[-1][3]:   # previous density <= new: merge
                p = st.pop(); blk = [p[0], blk[1], p[2] + blk[2], p[3] + blk[3]]
            st.append(blk)
        for s0, s1, se, stt in st:
            bid[s0:s1] = nb; dens.append(se / stt if stt > 0 else 0.0); nb += 1
    return bid, np.array(dens)


def block_curve(e, t, bid, dens):
    """cumulative (CPU-yr, E) taking whole blocks in decreasing predicted density"""
    nb = len(dens)
    Eb = np.bincount(bid, weights=e, minlength=nb); Tb = np.bincount(bid, weights=t, minlength=nb)
    o = np.argsort(-dens, kind='stable')
    return np.cumsum(Tb[o]) / YR, np.cumsum(Eb[o])
