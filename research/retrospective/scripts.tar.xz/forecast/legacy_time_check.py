"""First search: actual per-P CPU vs R_legacy(N) x t_current(N), by the P's time-weighted N.
(t_current below N = 4000 is the scheduler's msearch time model, which includes enumeration.)"""
import sys, numpy as np
from retro_lib import *
cfg = load_cfg(sys.argv[1:]); RT = Ratios(cfg)
leg = legacy_cells(cfg)
N = leg['N'].astype(float); n = len(leg['P'])
t = t_current(cfg, N, leg['sq']) * leg['dS'] * RT.R('legacy', N, leg['L'])
pred = np.bincount(leg['pid'], weights=t, minlength=n)
Nw = np.exp(np.bincount(leg['pid'], weights=t * np.log(N), minlength=n) / np.maximum(pred, 1e-300))
act = leg['t_legacy']
ok = (~leg['exh']) & (leg['xmax'] <= 1.2) & (act > 1)
for lo, hi in ((0, 1000), (1000, 2000), (2000, 3000), (3000, 6000)):
    m = ok & (Nw >= lo) & (Nw < hi)
    if m.sum(): print(f'time-weighted N {lo}-{hi}: {m.sum():4d} P, actual {act[m].sum()/YR:.3f} CPU-yr, predicted {pred[m].sum()/YR:.3f}, ratio {pred[m].sum()/act[m].sum():.2f}, per-P median {np.median(pred[m]/act[m]):.2f}')
m = ~ok & (act > 1)
print(f'exhaustive or long sweeps (> 3.3 S_min; model covers only to 3.3 S_min): {m.sum()} P, actual {act[m].sum()/YR:.3f}, predicted {pred[m].sum()/YR:.3f}')
o = np.argsort(-pred * m)[:8]
for i in o:
    sel = leg['pid'] == i
    print(f"  {leg['P'][i]:22s} exh {bool(leg['exh'][i])} xmax {leg['xmax'][i]:.2f} smin {leg['smin'][i]:.0f} actual {act[i]:9.0f} s predicted {pred[i]:9.0f} s, N max on grid {N[sel].max():.0f}, Nw {Nw[i]:.0f}")
