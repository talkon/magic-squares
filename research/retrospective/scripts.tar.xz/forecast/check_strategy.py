"""Strategy comparison under three "truths": the scheduler's own fitted model (model_6.json), the model lens,
and the analytic model. For the first search's sums (to 3.3 S_min) and for the scheduler's choices (current
code), report E and the CPU at which the scheduler reaches the first search's E.  Writes check_strategy.json."""
import sys, json, numpy as np
from retro_lib import *
from retro_lib import _mod
import an_cells, io, contextlib, runpy
cfg = load_cfg(sys.argv[1:])
epop, mlib = _mod()
M = mlib.M
RT = Ratios(cfg)
pool = pool_cells(cfg); leg = legacy_cells(cfg)
sys.argv = [cfg['analytic_rev_script']]
with contextlib.redirect_stdout(io.StringIO()):
    G = runpy.run_path(cfg['analytic_rev_script'], run_name='__main__')
A_pool = an_cells.pool_an(pool, G['fac'], G['VAR'])
rows = []
for r in json.load(open(SP + '/forecast/state/legacy.json')):
    P = mlib.norm(r['P'])
    if P: rows.append(dict(P=list(P), maxS=r['maxS']))
A_leg = an_cells.legacy_an(rows, G['fac'], G['VAR'])

# scheduler model on the first search's cells (lens grid, S <= min(max_S, 3.3 S_min))
lpid = leg['pid']; lS = leg['dS'].astype(float) / an_cells.GRID_DX; lN = leg['N'].astype(float)
Es = np.zeros(len(lpid))
starts = np.r_[0, np.nonzero(np.diff(lpid))[0] + 1, len(lpid)]
for a, b in zip(starts[:-1], starts[1:]):
    i = lpid[a]; P = tuple(map(int, leg['P'][i].split())); s0 = float(leg['smin'][i])
    S = lS[a:b]; N = lN[a:b]
    sq = mlib.sq_model(P, S, N, s0)
    pm = mlib.pmagic(mlib.trav(P, S, s0, 's', clampP=True), mlib.trav(P, S, s0, 'p', clampP=True), M['rho'])
    Es[a:b] = sq * pm * leg['dS'][a:b]
out = dict(first_search=dict(sched_model=float(Es.sum()), lens=float(leg['e'].sum()), analytic=float(A_leg['E'].sum()),
                             sched_model_sq=float(sum(mlib.sq_model(tuple(map(int, leg['P'][lpid[a]].split())), lS[a:b], lN[a:b], float(leg['smin'][lpid[a]])).dot(leg['dS'][a:b]) for a, b in zip(starts[:-1], starts[1:]))),
                             lens_sq=float((leg['sq'] * leg['dS']).sum()), actual_sq=int(leg['sols'].sum())))
# the scheduler's choices, current code (true time: lens N for lens/sched truth, analytic N/1.05 for analytic truth)
pN = pool['N'].astype(float); pL = pool['L'].astype(float)
pts = mlib.sum_time(pN) * pool['dS']
e_s = pool['dpred'] * pts                              # its own predicted E per cell
v = 'fdb77fc'
R = RT.R(v, pN, pL)
bid, dens = pav_blocks(pool['pid'], pool['dpred'] / R, pts * R)
aN = A_pool['N_an'] / 1.05
ta = t_current(cfg, aN) * pool['dS'] * RT.R(v, aN, pL)
tl = t_current(cfg, pN, pool['sq']) * pool['dS'] * R
res = {}
for name, (e, t) in dict(sched_model=(e_s, pts * R), lens=(pool['e'], tl), analytic=(A_pool['e_an'], ta)).items():
    cT, cE = block_curve(e, t, bid, dens)
    Ef = out['first_search'][name]
    res[name] = dict(E={C: float(E_at(cT, cE, C)) for C in (40 / 8766, 100 / 8766, 1000 / 8766, 1, 10, 100)},
                     C_for_first=float(C_at(cT, cE, Ef)), E_max=float(cE[-1]))
out['scheduler_current_code'] = res
# per-block agreement: analytic / sched-model E on the blocks the scheduler takes in its first 1 CPU-yr (sched-model time)
cT, cE = block_curve(e_s, pts * R, bid, dens)
nb = len(dens); o = np.argsort(-dens, kind='stable')
Tb = np.bincount(bid, weights=pts * R, minlength=nb)[o]; first = o[np.cumsum(Tb) / YR <= 1.0]
m = np.isin(bid, first)
out['first_1yr_blocks'] = dict(sched_model=float(e_s[m].sum()), lens=float(pool['e'][m].sum()), analytic=float(A_pool['e_an'][m].sum()),
                               N_w=float(np.exp((e_s[m] * np.log(pN[m])).sum() / e_s[m].sum())))
json.dump(out, open(HERE + '/check_strategy.json', 'w'), indent=1)
print(json.dumps(out, indent=1))
